﻿<?xml version="1.0" encoding="UTF-8"?>
<!--
******************************************************************************************************************

		Stylesheet SGAD - EN16931 UBL-CII based on Stylesheet for PEPPOL BIS BILLING 3 of SFTI tekniska kansli
		
		title= Stylesheet_SGAD_EN16931-UBL-CII.xsl	
		publisher= "SFTI tekniska kansli"
		Adaptor= "SGAD"
		Creator= SFTI/SL
		created= 2018-XX-XX
		adapted= 2019-04
		conformsTo= UBL-Invoice-2.1.xsd and UBL-CreditNote-2.1.xsd
		description= "Stylesheet for EN16931 UBL-CII base on Stylesheet for PEPPOL BIS BILLING 3, covering Invoice and Credit Note.
		
		The assumption is that is that the stylesheet is applied to messages that are formally correct, i.e. 
		messages that comply with XML schema and schematron rules. However, as this reference stylesheet is 
		likely to be used also in test environments, debug mode is available"
		
		This stylesheet is based on the work of SFTI tekniska kansli. 
		For more information about this adaptation see https://administracionelectronica.gob.es/ctt/face
		For more information about the PEPPOL original version see www.sfti.se or email tekniskt.kansli@skl.se
		
******************************************************************************************************************
-->
<xsl:stylesheet version="2.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:fcn="urn:sfti:se:xsl:functions" xmlns:n1="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2" xmlns:n2="urn:oasis:names:specification:ubl:schema:xsd:CreditNote-2" xmlns:cdl="http://docs.oasis-open.org/codelist/ns/genericode/1.0/" xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2" xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2" xmlns:ccts="urn:oasis:names:specification:ubl:schema:xsd:CoreComponentParameters-2" xmlns:sdt="urn:oasis:names:specification:ubl:schema:xsd:SpecializedDatatypes-2" xmlns:udt="urn:un:unece:uncefact:data:specification:UnqualifiedDataTypesSchemaModule:2" xmlns:qdt="urn:un:unece:uncefact:data:standard:QualifiedDataType:100"
 xmlns:udt2="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100" xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100" xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100" exclude-result-prefixes="n1 n2 cdl cac cbc ccts sdt udt qdt udt2 rsm ram">
	<xsl:include href="CommonTemplates.xsl"/>
	<xsl:output method="html" doctype-public="-//W3C//DTD HTML 4.01 Transitional//EN" doctype-system="http://www.w3.org/TR/html4/loose.dtd" indent="yes"/>
	<xsl:strip-space elements="*"/>
	<xsl:param name="stylesheet_url" select="'NONE'"/>
	<xsl:template name="doc-head">
		<meta charset="utf-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
		<xsl:choose>
			<xsl:when test="$stylesheet_url = 'NONE'">
				<style>* {
    box-sizing: border-box;
}

:root {
  --white: #ffffff;
  --grey: #f3f3f2;
  --Line-color: #979797;
  --font-color: #484848;
}

/* Text styles */

html,
body {
  font-size: 100%; }

body {
  background: #fff;
  color: #222222;
  padding: 0;
  margin: 0;
  font-family: "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;
  font-weight: normal;
  font-style: normal;
  line-height: 1.5;
  position: relative;
  cursor: auto; }

a:hover {
  cursor: pointer; }

img {
  max-width: 100%;
  height: auto; }

h1 {
  font-family: "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;
  font-size: 32px;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  line-height: 36px;
  letter-spacing: normal;
  color: #484848;
}

h2 {
  font-family: "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;
  font-size: 24px;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  line-height: 27px;
  letter-spacing: normal;
  color: #484848;
  margin:0px;
}

h3 {
  font-family: "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;
  font-size: 20px;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  line-height: 22px;
  letter-spacing: normal;
  color: #484848;
  margin:0px;
}

h4 {
  font-family: "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;
  font-size: 18px;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  line-height: 20px;
  letter-spacing: normal;
  color: #484848;
  margin:0px;
}

p,th,td {
  font-family: "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;
  font-size: 16px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: 20px;
  letter-spacing: normal;
  color: #484848;
  margin-top:10px;
  margin-bottom:10px;
}

table {
	/*border: 2px solid black;*/
	width: 100%;
}
table, th, td {border-collapse: collapse;}
tr {vertical-align: top;}
tr:nth-child(even) {background-color: #f3f3f2;}

td{
	vertical-align: top;
	border-bottom:1px solid #979797;
	/*border:2px solid black;*/
}


th {
	border-bottom: 2px solid #979797;
	font-weight:normal;
}

td.UBLLine {
	color:#979797;
	margin: 0em;
}

hr {color:var(--Line-color);}

.left {float: left !important;}

.right {float: right !important;}

.col-1 {width: 8.33%;}
.col-2 {width: 16.66%;}
.col-3 {width: 25%;}
.col-4 {width: 33.33%;}
.col-5 {width: 41.66%;}
.col-6 {width: 50%;}
.col-7 {width: 58.33%;}
.col-8 {width: 66.66%;}
.col-9 {width: 75%;}
.col-10 {width: 83.33%;}
.col-11 {width: 91.66%;}
.col-12 {width: 100%;}

[class*="col-"] {
    float: left;
    padding: 1px;
	margin-top:1px;
	border: solid 0px #979797;
}

.row::after {
    content: "";
    clear: both;
    display: table;
}
#bottomrow {border-bottom:2px solid #979797;}
#wrapper {
padding:16px;
border: 1px solid #979797;
}
#footer {
border-top: 2px solid #979797;
background-color: #f3f3f2;
padding:0px;
margin-top:16px;
}
#header {padding: 0.5vw;}
#headerrow {
padding-top:16px;
border-bottom:1px solid #979797;
}
#tablerow {padding-top:16px;}
.indent {margin-left: 18px; margin-right: 0px; margin-top: 0px; margin-bottom: 0px;}

				</style>
			</xsl:when>
			<xsl:otherwise>
				<link rel="stylesheet" href="{$stylesheet_url}"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<xsl:template match="n1:Invoice | n2:CreditNote">
		<!-- Start HTML -->
		<html>
			<xsl:call-template name="doc-head"/>
			<head>
				<meta name="viewport" content="width=device-width,initial-scale=1"/>
				<title>Visor HTML (UBL), factura europea</title>
			</head>
			<body>
				<div id="wrapper">
					<!-- Start on Header images row -->
					<!--<div class="row">
						<div class="col-4"><img class="left" src="./images/logo_Gob_Espana.jpg"/></div>
						<div class="col-8 right"><img width="60%" class="right" src="./images/logo_FACe.png"/></div>
					</div>
					<- End on Header images row ->
					<br/ -->
					<!-- Start on Invoice Type row-->
					<div class="row" id="bottomrow">
						<div class="col-6">
							<!--<xsl:value-of select="fcn:LabelName('BT-3', 'true')"/>-->
							<xsl:if test="local-name(.)  = 'Invoice'">
								<h2 style="margin-bottom:0px">
									<xsl:if test="$debug='true'">
										<xsl:text>BT-3@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="fcn:DocumentHeader(local-name(.))"/>
								</h2>
								<xsl:if test="cbc:InvoiceTypeCode !='380'">
									<h3 style="margin-top:0px">
										<xsl:value-of select="fcn:DocumentCode(cbc:InvoiceTypeCode)"/>
									</h3>
								</xsl:if>
							</xsl:if>
							<xsl:if test="local-name(.)  = 'CreditNote'">
								<h2 style="margin-bottom:0px">
									<xsl:value-of select="fcn:DocumentHeader(local-name(.))"/>
								</h2>
								<xsl:if test="cbc:CreditNoteTypeCode != '381'">
									<h3 style="margin-top:0px">
										<xsl:value-of select="fcn:DocumentCode(cbc:CreditNoteTypeCode)"/>
									</h3>
								</xsl:if>
							</xsl:if>
							<h1>
								<xsl:choose>
									<xsl:when test="cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name !=''">
										<xsl:if test="$debug='true'">
											<xsl:text>BT-28@ </xsl:text>
										</xsl:if>
										<xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name"/>
									</xsl:when>
									<xsl:otherwise>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-27@ </xsl:text>
										</xsl:if>
										<xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName"/>
									</xsl:otherwise>
								</xsl:choose>
							</h1>
						</div>
						<div class="col-6" id="header">
							<div class="col-6">
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-2', 'false')"/>
									</b>
									<br/>
									<!-- Inserting Invoice Date -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-2@ </xsl:text>
									</xsl:if>						
									<xsl:apply-templates select="fcn:getDate(normalize-space(cbc:IssueDate))"/>
									<br/>
								</p>
								<xsl:if test="cac:PaymentMeans/cbc:PaymentDueDate!='' or cbc:DueDate!=''">
									<p align="left">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-9', 'false')"/>
										</b>
										<br/>
										<!-- Inserting Due Date:  -->
										<xsl:if test="local-name(.) = 'CreditNote'">
											<xsl:variable name="DueDates">
												<xsl:for-each select="cac:PaymentMeans">
													<xsl:if test="cbc:PaymentDueDate !=''">
														<item>
															<xsl:if test="$debug='true'">
																<xsl:text>BT-9@ </xsl:text>
															</xsl:if>
															<xsl:value-of select="cbc:PaymentDueDate"/>
														</item>
													</xsl:if>
												</xsl:for-each>
											</xsl:variable>
											<xsl:value-of select="$DueDates[1]"/>
										</xsl:if>
										<xsl:if test="local-name(.) = 'Invoice'">
											<xsl:if test="$debug='true'">
												<xsl:text>BT-9@ </xsl:text>
											</xsl:if>
											<xsl:apply-templates select="fcn:getDate(normalize-space(cbc:DueDate))"/>
										</xsl:if>
										<br/>
									</p>
								</xsl:if>
								<xsl:if test="cac:InvoicePeriod !=''">
									<p align="left">
										<xsl:if test="cac:InvoicePeriod/cbc:StartDate !=''">
											<xsl:variable name="lbl_bt73">
												<xsl:value-of select="fcn:LabelName('BT-73', 'false')"/>
											</xsl:variable>
											<b>
												<xsl:value-of select="codepoints-to-string(reverse(string-to-codepoints(substring-after(codepoints-to-string(reverse(string-to-codepoints($lbl_bt73))), ' '))))"/>
												<br/>
												<xsl:value-of select="codepoints-to-string(reverse(string-to-codepoints(substring-before(codepoints-to-string(reverse(string-to-codepoints($lbl_bt73))), ' '))))"/>&#160;
											</b>
											<xsl:if test="$debug='true'">
												<xsl:text>BT-73@ </xsl:text>
											</xsl:if>
											<xsl:apply-templates select="fcn:getDate(normalize-space(cac:InvoicePeriod/cbc:StartDate))"/>
										</xsl:if>
										<xsl:if test="cac:InvoicePeriod/cbc:EndDate !='' ">
											<b>&#160;<xsl:value-of select="fcn:LabelName('BT-74', 'false')"/>&#160;</b>
											<!--br/-->
											<xsl:if test="$debug='true'">
												<xsl:text>BT-74@ </xsl:text>
											</xsl:if>
											<xsl:apply-templates select="fcn:getDate(normalize-space(cac:InvoicePeriod/cbc:EndDate))"/>
										</xsl:if>
									</p>
								</xsl:if>
							</div>
							<!--Start of invoice Header Information:-->
							<div class="col-6">
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-1', 'false')"/>
									</b>
									<!-- Inserting Invoice ID -->
									<br/>
									<xsl:if test="$debug='true'">
										<xsl:text>BT-1@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="cbc:ID"/>
									<br/>
								</p>
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-13', 'false')"/>
									</b>
									<br/>
									<!-- Inserting Order reference number  -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-13@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="cac:OrderReference/cbc:ID"/>
									<br/>
								</p>
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-10', 'false')"/>
									</b>
									<br/>
									<!-- Inserting Buyer Reference::  -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-10@ </xsl:text>
									</xsl:if>
									<xsl:for-each select="tokenize(cbc:BuyerReference, '\|')">
										<xsl:value-of select="fcn:BuyerReferenceTypeCode(.)"/>
										<xsl:if test="position() mod 2 = 0" >
											<br/>
										</xsl:if>
									</xsl:for-each>
									<br/>
								</p>
								<xsl:choose>
									<xsl:when test="cac:LegalMonetaryTotal/cbc:PayableAmount &lt; '0'">
										<p align="left" style="color:red">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-115', 'false')"/>
											</b>
											<br/>
											<!-- Inserting Total Payable amount  -->
											<xsl:if test="$debug='true'">
												<xsl:text> BT-115@</xsl:text>
											</xsl:if>
											<xsl:value-of select="fcn:Currency(cac:LegalMonetaryTotal/cbc:PayableAmount)"/>&#160;<xsl:value-of select="cbc:DocumentCurrencyCode"/>
											<xsl:if test="$debug='true'">
												<xsl:text> BT-5@</xsl:text>
											</xsl:if>
											<br/>
										</p>
									</xsl:when>
									<xsl:otherwise>
										<p align="left">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-115', 'false')"/>
											</b>
											<br/>
											<!-- Inserting Total Payable amount  -->
											<xsl:if test="$debug='true'">
												<xsl:text> BT-115@</xsl:text>
											</xsl:if>
											<xsl:value-of select="fcn:Currency(cac:LegalMonetaryTotal/cbc:PayableAmount)"/>&#160;<xsl:value-of select="cbc:DocumentCurrencyCode"/>
											<xsl:if test="$debug='true'">
												<xsl:text> BT-5@</xsl:text>
											</xsl:if>
											<br/>
										</p>
									</xsl:otherwise>
								</xsl:choose>
							</div>
						</div>
						<!--End of invoice Header Information-->
					</div>

					<div class="row indent" id="headerrow">
						<!-- Seller Row starts here-->
						<div class="row">
							<h3>
								<xsl:value-of select="fcn:LabelName('BG-4', 'false')"/>
							</h3>
						</div>
						<div class="row">
							<div class="col-6">
								<!-- Inserting Accounting Supplier Party-->
								<p>
									<xsl:apply-templates select="cac:AccountingSupplierParty"/>
								</p>
							</div>
							<div class="col-6">
								<!-- Inserting contact information -->
								<xsl:if test="cac:AccountingSupplierParty/cac:Party/cac:Contact !=''">
									<p style="margin-bottom: 0px;">
										<b>
											<xsl:value-of select="fcn:LabelName('BG-6', 'false')"/>
										</b>
									</p>
									<xsl:call-template name="SellerContact"/>
								</xsl:if>
								<xsl:if test="cac:OrderReference/cbc:SalesOrderID">
									<p align="left">
										<b><xsl:value-of select="fcn:LabelName('BT-14', 'true')"/></b>
										<!-- Inserting Sales order reference number  -->
										<xsl:if test="$debug='true'">
											<xsl:text>BT-14@ </xsl:text>
										</xsl:if>
										<xsl:value-of select="cac:OrderReference/cbc:SalesOrderID"/>
										<br/>
									</p>
								</xsl:if>
							</div>
						</div>								
					</div>
					<div class="row indent" id="headerrow">
						<!-- Inserting Accounting Customer Party -->
						<div class="row">
							<h3>
								<xsl:value-of select="fcn:LabelName('BG-7', 'false')"/>
							</h3>
						</div>
						<div class="row">
							<div class="col-6">
								<p>
									<xsl:apply-templates select="cac:AccountingCustomerParty"/>
								</p>
							</div>
							<div class="col-6">
								<p>
									<xsl:if test="cac:AccountingCustomerParty/cac:Party/cac:Contact !='' or cbc:AccountingCost !=''">
										<p style="margin-bottom: 0px;">
											<!-- Inserting Contact information-->
											<b>
												<xsl:value-of select="fcn:LabelName('BG-9', 'false')"/>
											</b>
										</p>
										<xsl:call-template name="BuyerContact"/>
									</xsl:if>
									<xsl:if test="cbc:AccountingCost !=''">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-19', 'true')"/>
										</b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-19@ </xsl:text>
										</xsl:if>
										<xsl:value-of select="cbc:AccountingCost"/>
									</xsl:if>
								</p>
							</div>
						</div>
					</div>

					<xsl:if test="cac:PayeeParty !='' or cac:TaxRepresentativeParty !=''">
						<div class="row indent" id="headerrow">
							<div class="col-6">
								<xsl:if test="cac:PayeeParty !=''">
									<!-- Inserting Payee Party -->
									<p>
										<h3>
											<xsl:value-of select="fcn:LabelName('BG-10', 'false')"/>
										</h3>
										<xsl:call-template name="PayeeParty"/>
									</p>
								</xsl:if>
							</div>
							<div class="col-6">
								<xsl:if test="cac:TaxRepresentativeParty !=''">
									<p>
										<h3>
											<xsl:value-of select="fcn:LabelName('BG-11', 'false')"/>
										</h3>
										<br/>
										<xsl:apply-templates select="cac:TaxRepresentativeParty"/>
									</p>
								</xsl:if>
							</div>
						</div>
					</xsl:if>
					<xsl:if test="cac:Delivery!=''">
						<div class="row indent" id="headerrow">
							<div class="col-12">
								<!-- Start on DELIVERY BG-13 & BG-14 information -->
								<xsl:apply-templates select="cac:Delivery" mode="DocumentHeader"/>
								<xsl:if test="normalize-space(cac:Delivery/cbc:ActualDeliveryDate) !=''">
									<p>
										<b>
											<xsl:value-of select="fcn:LabelName('BT-72', 'true')"/>
										</b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-72@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="fcn:getDate(normalize-space(cac:Delivery/cbc:ActualDeliveryDate))"/>
									</p>
								</xsl:if>
								<!-- End on DELIVERY information -->
							</div>
						</div>
					</xsl:if>
					<br/>
					<!--Start Invoiceline-->
					<div class="row" id="tablerow">
						<div class="col-12">
							<h3>
								<xsl:value-of select="fcn:LabelName('BG-25', 'false')"/>
							</h3>
							<table cellpadding="5px">
								<tr class="UBLInvoiceLineHeader">
									<th align="left" valign="top" width="5%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-126', 'false')"/>
										</b>
									</th>
									<th align="left" valign="top" width="10%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-155', 'false')"/>
										</b>
									</th>
									<th align="left" valign="top" width="35%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-153', 'false')"/>
										</b>
									</th>
									<th valign="top" align="left" width="10%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-129', 'false')"/>
										</b>
									</th>
									<th align="left" valign="top" width="10%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-146', 'false')"/>
										</b>
									</th>
									<th align="left" valign="top" width="10%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-151', 'false')"/>
										</b>
									</th>
									<th align="left" valign="top" width="10%">
										<b>
											<xsl:value-of select="fcn:LabelName('BG-28', 'false')"/>
											<br/>
											<xsl:value-of select="fcn:LabelName('BG-27', 'false')"/>
										</b>
									</th>
									<th align="right" valign="top" width="10%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-131', 'false')"/>
										</b>
									</th>
								</tr>
								<xsl:if test="cac:InvoiceLine != ''">
									<xsl:apply-templates select="cac:InvoiceLine"/>
								</xsl:if>
								<xsl:if test="cac:CreditNoteLine != ''">
									<xsl:apply-templates select="cac:CreditNoteLine"/>
								</xsl:if>
							</table>
						</div>
					</div>
					<!--End Invoiceline-->
					<!-- Start sum of invoice line net amount: -->
					<div class="row" id="sum">
						<div class="col-6">
							<p align="left">
								<b>
									<xsl:value-of select="fcn:LabelName('BT-106', 'true')"/>
								</b>
							</p>
						</div>
						<div class="col-6">
							<p align="right">
								<b>
									<xsl:if test="$debug='true'">
										<xsl:text>BT-106@ </xsl:text>
									</xsl:if>
									<xsl:apply-templates select="fcn:Currency(cac:LegalMonetaryTotal/cbc:LineExtensionAmount)"/>&#160;<xsl:apply-templates select="cac:LegalMonetaryTotal/cbc:LineExtensionAmount/@currencyID"/>
								</b>
							</p>
						</div>
					</div>
					<!-- End Sum of invoice line net amount -->
					<!-- Start AllowanceTotal Amount: -->
					<xsl:if test="cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount !='' ">
						<div class="row" id="sum">
							<div class="col-6">
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-107', 'true')"/>
									</b>
								</p>
							</div>
							<div class="col-6">
								<p align="right">
									<b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-107@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="fcn:Currency(cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount)"/>&#160;<xsl:apply-templates select="cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount/@currencyID"/>
									</b>
								</p>
							</div>
						</div>
					</xsl:if>
					<!-- End AllowanceTotal Amount -->
					<!--Start Document Charges-->
					<xsl:if test="cac:AllowanceCharge[cbc:ChargeIndicator ='true']">
						<div class="row" id="tablerow">
							<div class="col-12">
								<h3>
									<xsl:value-of select="fcn:LabelName('BG-21', 'false')"/>
								</h3>
								<table>
									<tr>
										<th align="left" valign="top" colspan="2" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-98', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-97', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-95', 'false')"/>
											</b>
										</th>
										<th align="right" valign="top" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-100', 'false')"/>
											</b>
										</th>
										<th valign="top" align="right" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-92', 'false')"/>
											</b>
										</th>
									</tr>
									<xsl:for-each select="cac:AllowanceCharge">
										<xsl:if test="cbc:ChargeIndicator ='true'">
											<xsl:call-template name="Charge"/>
										</xsl:if>
									</xsl:for-each>
								</table>
							</div>
						</div>
					</xsl:if>
					<!--End Document Charges-->
					<!-- Start ChargeTotal Amount: -->
					<xsl:if test="cac:LegalMonetaryTotal/cbc:ChargeTotalAmount !='' ">
						<div class="row" id="sum">
							<div class="col-6">
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-108', 'true')"/>
									</b>
								</p>
							</div>
							<div class="col-6">
								<p align="right">
									<b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-108@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="fcn:Currency(cac:LegalMonetaryTotal/cbc:ChargeTotalAmount)"/>&#160;<xsl:apply-templates select="cac:LegalMonetaryTotal/cbc:ChargeTotalAmount/@currencyID"/>
									</b>
								</p>
							</div>
						</div>
					</xsl:if>
					<!-- End ChargeTotal Amount -->
					<!-- Start Prepaid Amount: -->
					<xsl:if test="cac:LegalMonetaryTotal/cbc:PrepaidAmount !='' ">
						<div class="row" id="headerrow">
							<div class="col-6">
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-113', 'true')"/>
									</b>
								</p>
							</div>
							<div class="col-6">
								<p align="right">
									<xsl:if test="$debug='true'">
										<xsl:text>BT-113@ </xsl:text>
									</xsl:if>
									<xsl:apply-templates select="fcn:Currency(cac:LegalMonetaryTotal/cbc:PrepaidAmount)"/>&#160;<xsl:apply-templates select="cac:LegalMonetaryTotal/cbc:PrepaidAmount/@currencyID"/>
								</p>
							</div>
						</div>
					</xsl:if>
					<!-- End Prepaid Amount -->
					<!-- Start Rounding Amount: -->
					<xsl:if test="cac:LegalMonetaryTotal/cbc:PayableRoundingAmount !='' ">
						<div class="row" id="headerrow">
							<div class="col-6">
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-114', 'true')"/>
									</b>
								</p>
							</div>
							<div class="col-6">
								<p align="right">
									<xsl:if test="$debug='true'">
										<xsl:text>BT-114@ </xsl:text>
									</xsl:if>
									<xsl:apply-templates select="fcn:Currency(cac:LegalMonetaryTotal/cbc:PayableRoundingAmount)"/>&#160;<xsl:apply-templates select="cac:LegalMonetaryTotal/cbc:PayableRoundingAmount/@currencyID"/>
								</p>
							</div>
						</div>
					</xsl:if>
					<!-- End Rounding Amount -->
					<!-- Start Payable Amount: -->
					<div class="row" id="headerrow">
						<xsl:choose>
							<xsl:when test="cac:LegalMonetaryTotal/cbc:PayableAmount &lt; '0'">
								<div class="col-6">
									<h2 align="left" style="color:red">
										<xsl:value-of select="fcn:LabelName('BT-115', 'true')"/>
									</h2>
								</div>
								<div class="col-6">
									<h2 align="right" style="color:red">
										<xsl:if test="$debug='true'">
											<xsl:text>BT-115@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="fcn:Currency(cac:LegalMonetaryTotal/cbc:PayableAmount)"/>&#160;<xsl:apply-templates select="cac:LegalMonetaryTotal/cbc:PayableAmount/@currencyID"/>
									</h2>
								</div>
							</xsl:when>
							<xsl:otherwise>
								<div class="col-6">
									<h2 align="left">
										<xsl:value-of select="fcn:LabelName('BT-115', 'true')"/>
									</h2>
								</div>
								<div class="col-6">
									<h2 align="right">
										<xsl:if test="$debug='true'">
											<xsl:text>BT-115@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="fcn:Currency(cac:LegalMonetaryTotal/cbc:PayableAmount)"/>&#160;<xsl:apply-templates select="cac:LegalMonetaryTotal/cbc:PayableAmount/@currencyID"/>
									</h2>
								</div>
							</xsl:otherwise>
						</xsl:choose>
					</div>
					<!-- End Payable Amount -->
					<!-- Start document totals: -->
					<!-- Start on PAYMENT TERMS information -->
					<xsl:if test="cac:PaymentTerms !=''">
						<div class="row" id="tablerow">
							<div class="col-12">
								<b>
									<xsl:value-of select="fcn:LabelName('BT-20', 'true')"/>
								</b>
								<p>
									<xsl:apply-templates select="cac:PaymentTerms"/>
								</p>
							</div>
						</div>
					</xsl:if>
					<!-- Start Tax Amount: -->
					<xsl:if test="cbc:TaxCurrencyCode !=''">
						<div class="row">
							<div class="col-12">
								<p>
									<b>
										<xsl:value-of select="fcn:LabelName('BT-6', 'true')"/>
									</b>
									<xsl:if test="$debug='true'">
										<xsl:text>BT-6@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="cbc:TaxCurrencyCode"/>
								</p>
							</div>
						</div>
					</xsl:if>
					<xsl:if test="cac:TaxTotal/cbc:TaxAmount">
						<xsl:if test="cac:TaxTotal/cbc:TaxAmount[@currencyID=../../cbc:DocumentCurrencyCode]">
							<div class="row" id="headerrow">
								<div class="col-6">
									<p>
										<b>
											<xsl:value-of select="fcn:LabelName('BT-110', 'true')"/>
										</b>
									</p>
								</div>
								<div class="col-3">
									<p align="right">
										<xsl:if test="fcn:Currency(cac:TaxTotal/cbc:TaxAmount[@currencyID=../../cbc:TaxCurrencyCode])">
											<xsl:if test="$debug='true'">
												<xsl:text>BT-110@ </xsl:text>
											</xsl:if>
											<xsl:apply-templates select="fcn:Currency(cac:TaxTotal/cbc:TaxAmount[@currencyID=../../cbc:TaxCurrencyCode])"/>&#160;<xsl:apply-templates select="cac:TaxTotal/cbc:TaxAmount[@currencyID=../../cbc:TaxCurrencyCode]/@currencyID"/>
										</xsl:if>
									</p>
								</div>
								<div class="col-3">
									<p align="right">
										<b>
											<xsl:if test="$debug='true'">
												<xsl:text>BT-111@ </xsl:text>
											</xsl:if>
											<xsl:apply-templates select="fcn:Currency(cac:TaxTotal/cbc:TaxAmount[@currencyID=../../cbc:DocumentCurrencyCode])"/>&#160;<xsl:apply-templates select="cac:TaxTotal/cbc:TaxAmount[@currencyID=../../cbc:DocumentCurrencyCode]/@currencyID"/>
										</b>
									</p>
								</div>
							</div>
						</xsl:if>
					</xsl:if>
					<!-- End Tax Amount -->
					<!-- Start TaxExclusive Amount: -->
					<div class="row" id="headerrow">
						<div class="col-6">
							<p align="left">
								<b>
									<xsl:value-of select="fcn:LabelName('BT-109', 'true')"/>
								</b>
							</p>
						</div>
						<div class="col-6">
							<p align="right">
								<xsl:if test="$debug='true'">
									<xsl:text>BT-109@ </xsl:text>
								</xsl:if>
								<xsl:apply-templates select="fcn:Currency(cac:LegalMonetaryTotal/cbc:TaxExclusiveAmount)"/>&#160;<xsl:apply-templates select="cac:LegalMonetaryTotal/cbc:TaxExclusiveAmount/@currencyID"/>
							</p>
						</div>
					</div>
					<!-- End TaxExclusive Amount -->
					<!-- Start TaxInclusive Amount: -->
					<div class="row" id="headerrow">
						<div class="col-6">
							<p align="left">
								<b>
									<xsl:value-of select="fcn:LabelName('BT-112', 'true')"/>
								</b>
							</p>
						</div>
						<div class="col-6">
							<p align="right">
								<b>
									<xsl:if test="$debug='true'">
										<xsl:text>BT-112@ </xsl:text>
									</xsl:if>
									<xsl:apply-templates select="fcn:Currency(cac:LegalMonetaryTotal/cbc:TaxInclusiveAmount)"/>&#160;<xsl:apply-templates select="cac:LegalMonetaryTotal/cbc:TaxInclusiveAmount/@currencyID"/>
								</b>
							</p>
						</div>
					</div>
					<!-- End TaxInclusive Amount -->
					<!-- Start VAT Breakdown: -->
					<div class="row" id="tablerow">
						<div class="col-12">
							<h3>
								<xsl:value-of select="fcn:LabelName('BG-23', 'false')"/>
							</h3>
							<xsl:if test="cbc:TaxPointDate!='' or cac:InvoicePeriod/cbc:DescriptionCode!=''">
								<p>
									<xsl:if test="cbc:TaxPointDate !=''">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-7', 'true')"/>
										</b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-7@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="fcn:getDate(normalize-space(cbc:TaxPointDate))"/>
									</xsl:if>
									<xsl:if test="cac:InvoicePeriod/cbc:DescriptionCode != ''">
										<br/>
										<b>
											<xsl:value-of select="fcn:LabelName('BT-8', 'true')"/>
										</b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-8@ </xsl:text>
										</xsl:if>
										<xsl:value-of select="fcn:UBLDescriptionCode(cac:InvoicePeriod/cbc:DescriptionCode)"/> [<xsl:value-of select="cac:InvoicePeriod/cbc:DescriptionCode"/>]
										<br/>
									</xsl:if>
								</p>
							</xsl:if>
						</div>
					</div>
					<div class="row" id="tablerow">
						<div class="col-12">
							<table>
								<xsl:if test="cac:TaxTotal">
									<tr class="TAXInformationHeader">
										<th align="left" valign="top" colspan="2" width="25%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-118', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2" width="25%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-120', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2" width="25%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-116', 'false')"/>
											</b>
										</th>
										<!--th valign="top" align="right">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-111', 'true')"/>
										</b>
									</th-->
										<th valign="top" align="right" width="25%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-117', 'false')"/>
											</b>
										</th>
									</tr>
									<xsl:apply-templates select="cac:TaxTotal/cac:TaxSubtotal"/>
								</xsl:if>
							</table>
						</div>
					</div>
					<!--End VAT Breakdown -->
					<!-- Start on PAYMENT MEANS information -->
					<div class="row" id="tablerow">
						<div class="col-12">
							<h3>
								<xsl:value-of select="fcn:LabelName('BG-16', 'false')"/>
							</h3>
							<xsl:if test="cac:PaymentMeans/cac:PayeeFinancialAccount !=''">
								<table>
									<tr>
										<th align="left" valign="top">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-81', 'false')"/>
											</b>&#160;&#160;
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-86', 'false')"/>
											</b>
										</th>

										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-84', 'false')"/>
											</b>
										</th>

										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-85', 'false')"/>
											</b>
										</th>
										<th align="right" valign="top">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-83', 'false')"/>
											</b>
										</th>
									</tr>
									<xsl:for-each select="cac:PaymentMeans">
										<xsl:if test="cac:PayeeFinancialAccount !=''">
											<xsl:call-template name="cac:PaymentMeans"/>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="cac:PaymentMeans">
										<xsl:if test="not(cac:PaymentMandate) and not(cac:CardAccount) and not(cac:PayeeFinancialAccount)">
											<xsl:call-template name="cac:PaymentMeans"/>
										</xsl:if>
									</xsl:for-each>
								</table>
							</xsl:if>
							<xsl:if test="cac:PaymentMeans/cac:CardAccount !=''">
								<table>
									<tr>
										<th align="left" valign="top">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-81', 'false')"/>
											</b>&#160;&#160;
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-86-1', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-87', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-88', 'false')"/>
											</b>
										</th>
										<th align="right" valign="top">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-83', 'false')"/>
											</b>
										</th>
									</tr>
									<xsl:for-each select="cac:PaymentMeans">
										<xsl:if test="cac:CardAccount !=''">
											<xsl:call-template name="cac:PaymentMeans"/>
										</xsl:if>
									</xsl:for-each>
								</table>
							</xsl:if>
							<xsl:if test="cac:PaymentMeans/cac:PaymentMandate !=''">
								<table>
									<tr>
										<th align="left" valign="top">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-81', 'false')"/>
											</b>&#160;&#160;
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-91', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-89', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-90', 'false')"/>
											</b>
										</th>
										<th align="right" valign="top">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-83', 'false')"/>
											</b>
										</th>
									</tr>
									<xsl:for-each select="cac:PaymentMeans">
										<xsl:if test="cac:PaymentMandate !=''">
											<xsl:call-template name="cac:PaymentMeans"/>
										</xsl:if>
									</xsl:for-each>

								</table>
							</xsl:if>
						</div>
					</div>
					<!-- End of PAYMENT MEANS information -->
					<!-- Start Allowances and charges on document level: -->
					<!--Start Document allowances-->
					<xsl:if test="cac:AllowanceCharge[cbc:ChargeIndicator ='false']">
						<div class="row" id="tablerow">
							<div class="col-12">
								<h3>
									<xsl:value-of select="fcn:LabelName('BG-20', 'false')"/>
								</h3>
								<table>
									<tr>
										<th align="left" valign="top" colspan="2" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-105', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-104', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-102', 'false')"/>
											</b>
										</th>
										<th align="right" valign="top" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-93', 'false')"/>
											</b>
										</th>
										<th valign="top" align="right" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-99', 'false')"/>
											</b>
										</th>
									</tr>
									<xsl:for-each select="cac:AllowanceCharge">
										<xsl:if test="cbc:ChargeIndicator ='false'">
											<xsl:call-template name="Allowance"/>
										</xsl:if>
									</xsl:for-each>
								</table>
							</div>
						</div>
					</xsl:if>
					<!--End Document allowances-->

					<!-- Start on Aditional Documents -->
					<br/>
					<h3>
						<xsl:value-of select="fcn:LabelName('BG-24', 'false')"/>
					</h3>		
					<div class="row">
						<div class="col-12">
							<div class="col-6">
								<p>
									<xsl:if test='cac:BillingReference/cac:InvoiceDocumentReference'>
										<!-- Start of BG-3 Section -->
										<!--b>
									<xsl:value-of select="fcn:LabelName('BG-3', 'true')"/>
								</b -->
										<b>
											<xsl:value-of select="fcn:LabelName('BT-25', 'true')"/>
										</b>
										<xsl:for-each select="cac:BillingReference/cac:InvoiceDocumentReference">
											<br/>
											<!-- Inserting Preceding invoice number  -->
											<xsl:if test="$debug='true'">
												<xsl:text>BT-25@ </xsl:text>
											</xsl:if>
											<xsl:value-of select="cbc:ID"/>
											<!-- Inserting Preceding Invoice Issue Date  -->
											<xsl:if test="$debug='true'">
												<xsl:text> BT-26@ </xsl:text>
											</xsl:if>
											<xsl:if test="cbc:IssueDate != ''">
												( <xsl:apply-templates select="fcn:getDate(normalize-space(cbc:IssueDate))"/> )
											</xsl:if>
										</xsl:for-each>
										<!-- END of BG-3 Section -->
									</xsl:if>
								</p>
							</div>
							<div class="col-6">	
								<p>
									<xsl:if test="cac:ContractDocumentReference !=''">
										<br/>
										<b>
											<xsl:value-of select="fcn:LabelName('BT-12', 'true')"/>
										</b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-12@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="cac:ContractDocumentReference"/>
									</xsl:if>

									<xsl:if test="cbc:Note[.!='']">
										<br/>
										<b>
											<xsl:value-of select="fcn:LabelName('BT-22', 'true')"/>
										</b>
										<xsl:choose>
											<xsl:when test="string-length(cbc:Note/.)&lt;5">
												<xsl:if test="$debug='true'">
													<xsl:text>BT-21@ </xsl:text>
												</xsl:if>
												<xsl:variable name="descripcion">
													<xsl:value-of select="fcn:InvoiceNoteCode(cbc:Note)"/>
												</xsl:variable>
												<xsl:call-template name="replace">
													<xsl:with-param name="string" select="$descripcion"/>
												</xsl:call-template>
												<xsl:if test="cbc:Note!=$descripcion">
													<xsl:value-of select="concat(' [', cbc:Note, ']')"/>
												</xsl:if>
											</xsl:when>
											<xsl:otherwise>
												<xsl:if test="$debug='true'">
													<xsl:text>BT-22@ </xsl:text>
												</xsl:if>
												<xsl:apply-templates select="cbc:Note"/>
											</xsl:otherwise>
										</xsl:choose>
									</xsl:if>
								</p>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<p>
								<!-- Start of BG-2 Section -->
								<xsl:if test="cbc:ProfileID!=''">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-23', 'true')"/>
									</b>
									<xsl:if test="$debug='true'">
										<xsl:text>BT-23@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="cbc:ProfileID"/>
									<br/>
								</xsl:if>
								<xsl:if test="cbc:CustomizationID!=''">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-24', 'true')"/>
									</b>
									<xsl:if test="$debug='true'">
										<xsl:text>BT-24@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="cbc:CustomizationID"/>
								</xsl:if>
							</p>
							<!-- END of BG-2 Section -->
							<p>
								<xsl:if test="cac:AdditionalDocumentReference !=''">

									<xsl:apply-templates select="cac:AdditionalDocumentReference[cbc:DocumentTypeCode != '130' and cbc:DocumentTypeCode != '50' or not(exists(cbc:DocumentTypeCode))]" mode="Supporting"/>

								</xsl:if>
								<xsl:if test="cac:AdditionalDocumentReference !=''">

									<xsl:apply-templates select="cac:AdditionalDocumentReference[cbc:DocumentTypeCode='130' or cbc:DocumentTypeCode='50']" mode="InvoicedObject"/>

								</xsl:if>
								<xsl:if test="cac:DespatchDocumentReference/cbc:ID">

									<br/>
									<b>
										<xsl:value-of select="fcn:LabelName('BT-16', 'true')"/>
									</b>
									<!-- Inserting Despatch advice reference  -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-16@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="cac:DespatchDocumentReference/cbc:ID"/>

								</xsl:if>
								<xsl:if test="cac:ReceiptDocumentReference/cbc:ID">

									<br/>
									<b>
										<xsl:value-of select="fcn:LabelName('BT-15', 'true')"/>
									</b>
									<!-- Inserting Receipt advice reference  -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-15@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="cac:ReceiptDocumentReference/cbc:ID"/>

								</xsl:if>
								<xsl:if test="cac:OriginatorDocumentReference/cbc:ID">

									<br/>
									<b>
										<xsl:value-of select="fcn:LabelName('BT-17', 'true')"/>
									</b>
									<!-- Inserting Originator advice reference  -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-17@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="cac:OriginatorDocumentReference/cbc:ID"/>

								</xsl:if>
								<xsl:if test="cac:ProjectReference/cbc:ID">

									<br/>
									<b>
										<xsl:value-of select="fcn:LabelName('BT-11', 'true')"/>
									</b>
									<!-- Inserting Project advice reference  -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-11@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="cac:ProjectReference/cbc:ID"/>

								</xsl:if>
							</p>
						</div>
					</div>
					<!-- End on Aditional Documents -->

					<!-- Start on technical stylesheet footer - for all transactions -->
					<div class="row" id="tablerow">
						<div class="col-12">
							<p>
								<small>
									<!--xsl:value-of select="cbc:UBLVersionID"/>
								<br/>
								<xsl:if test="cbc:UUID !=''">
									<xsl:value-of select="cbc:UUID"/>
									<br/>
								</xsl:if!-->
									<xsl:if test="cac:AccountingSupplierParty/cac:Party/cbc:EndpointID">
										<xsl:value-of select="fcn:LabelName('BT-34', 'true')"/>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-34@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="cac:AccountingSupplierParty/cac:Party/cbc:EndpointID"/>
										<xsl:if test="cac:AccountingSupplierParty/cac:Party/cbc:EndpointID/@schemeID !='' ">
											[<xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cbc:EndpointID/@schemeID"/>]
										</xsl:if>

									</xsl:if>
									<xsl:if test="cac:AccountingCustomerParty/cac:Party/cbc:EndpointID">
										<br/>

										<xsl:value-of select="fcn:LabelName('BT-49', 'true')"/>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-49@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="cac:AccountingCustomerParty/cac:Party/cbc:EndpointID"/>
										<xsl:if test="cac:AccountingCustomerParty/cac:Party/cbc:EndpointID/@schemeID !='' ">
										[<xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cbc:EndpointID/@schemeID"/>]
										</xsl:if>
									</xsl:if>
									<br/>
									<br/>
									<xsl:value-of select="replace(fcn:LabelName('UT-1', 'false'), '%', 'UBL')"/>
									<br/>
									<xsl:value-of select="fcn:LabelName('UT-2', 'false')"/>&#160;<xsl:value-of  select="format-date(current-date(), '[D01]/[M01]/[Y0001]')"/>&#160;
									<xsl:value-of select="fcn:LabelName('UT-3', 'false')"/>&#160;<xsl:value-of select="format-time(current-time(), '[H01]:[m01]:[s01] ([z])')"/>
								</small>
							</p>
						</div>
					</div>
					<!-- End of technical stylesheet footer-->
				</div>
			</body>
		</html>
	</xsl:template>

	<!--++++++++++++++++++++++++++++++++-->
	<!-- START FOR CII TEMPLATES        -->
	<!--++++++++++++++++++++++++++++++++-->
	<xsl:template match="rsm:CrossIndustryInvoice">
		<xsl:variable name="tipoCodigo">
			<xsl:value-of select="rsm:ExchangedDocument/ram:TypeCode"/>
		</xsl:variable>
		<xsl:variable name="isCreditNote">
			<xsl:choose>
				<xsl:when test="contains(concat('|',$tipoCodigo,'|'),'|381|396|81|83|532|')">
					<xsl:text>true</xsl:text>
				</xsl:when>
				<xsl:otherwise>
					<xsl:text>false</xsl:text>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<!-- Start HTML -->
		<html>
			<xsl:call-template name="doc-head"/>
			<head>
				<meta name="viewport" content="width=device-width,initial-scale=1"/>
				<title>Visor HTML (CII), factura europea</title>
			</head>
			<body>
				<div id="wrapper">
					<!-- Start on Header images row -->
					<!--<div class="row">
						<div class="col-4"><img class="left" src="./images/logo_Gob_Espana.jpg"/></div>
						<div class="col-8 right"><img width="60%" class="right" src="./images/logo_FACe.png"/></div>
					</div>
					<- End on Header images row ->
					<br/ -->
					<!-- Start on Invoice Type row-->
					<div class="row" id="bottomrow">
						<div class="col-6">
							<!--<xsl:value-of select="fcn:LabelName('BT-3', 'true')"/>-->
							<xsl:if test="$isCreditNote='false'">
								<!--Type Invoice-->
								<h2 style="margin-bottom:0px">
									<xsl:if test="$debug='true'">
										<xsl:text>BT-3@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="fcn:DocumentHeader('Invoice')"/>
								</h2>
								<xsl:if test="$tipoCodigo!='' and $tipoCodigo!='380'">
									<h3 style="margin-top:0px">
										<xsl:value-of select="fcn:DocumentCode($tipoCodigo)"/>
									</h3>
								</xsl:if>
							</xsl:if>
							<xsl:if test="$isCreditNote='true'">
								<!--Type CreditNote-->
								<h2 style="margin-bottom:0px">
									<xsl:value-of select="fcn:DocumentHeader('CreditNote')"/>
								</h2>
								<xsl:if test="$tipoCodigo!='' and $tipoCodigo!='381'">
									<h3 style="margin-top:0px">
										<xsl:value-of select="fcn:DocumentCode($tipoCodigo)"/>
									</h3>
								</xsl:if>
							</xsl:if>
							<h1>
								<xsl:choose>
									<xsl:when test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerTradeParty/ram:SpecifiedLegalOrganization/ram:TradingBusinessName !=''">
										<xsl:if test="$debug='true'">
											<xsl:text>BT-28@ </xsl:text>
										</xsl:if>
										<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerTradeParty/ram:SpecifiedLegalOrganization/ram:TradingBusinessName"/>
									</xsl:when>
									<xsl:otherwise>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-27@ </xsl:text>
										</xsl:if>
										<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerTradeParty/ram:Name"/>
									</xsl:otherwise>
								</xsl:choose>
							</h1>
						</div>
						<div class="col-6" id="header">
							<div class="col-6">
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-2', 'false')"/>
									</b>
									<br/>
									<!-- Inserting Invoice Date -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-2@ </xsl:text>
									</xsl:if>
									<xsl:apply-templates select="rsm:ExchangedDocument/ram:IssueDateTime/udt2:DateTimeString"/>
									<br/>
								</p>
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradePaymentTerms/ram:DueDateDateTime/udt2:DateTimeString!=''">
									<p align="left">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-9', 'false')"/>
										</b>
										<br/>
										<!-- Inserting Due Date:  -->
										<xsl:if test="$isCreditNote='true'">
											<xsl:variable name="DueDates">
												<xsl:for-each select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradePaymentTerms">
													<xsl:if test="ram:DueDateDateTime/udt2:DateTimeString!=''">
														<item>
															<xsl:if test="$debug='true'">
																<xsl:text>BT-9@ </xsl:text>
															</xsl:if>
															<xsl:apply-templates select="ram:DueDateDateTime/udt2:DateTimeString"/>
														</item>
													</xsl:if>
												</xsl:for-each>
											</xsl:variable>
											<xsl:value-of select="$DueDates[1]"/>
										</xsl:if>
										<xsl:if test="$isCreditNote='false'">
											<xsl:if test="$debug='true'">
												<xsl:text>BT-9@ </xsl:text>
											</xsl:if>
											<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradePaymentTerms/ram:DueDateDateTime/udt2:DateTimeString"/>
										</xsl:if>
										<br/>
									</p>
								</xsl:if>
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:BillingSpecifiedPeriod !=''">
									<p align="left">
										<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:BillingSpecifiedPeriod/ram:StartDateTime/udt2:DateTimeString !=''">
											<xsl:variable name="lbl_bt73">
												<xsl:value-of select="fcn:LabelName('BT-73', 'false')"/>
											</xsl:variable>
											<b>
												<xsl:value-of select="codepoints-to-string(reverse(string-to-codepoints(substring-after(codepoints-to-string(reverse(string-to-codepoints($lbl_bt73))), ' '))))"/>
												<br/>
												<xsl:value-of select="codepoints-to-string(reverse(string-to-codepoints(substring-before(codepoints-to-string(reverse(string-to-codepoints($lbl_bt73))), ' '))))"/>&#160;
											</b>
											<xsl:if test="$debug='true'">
												<xsl:text>BT-73@ </xsl:text>
											</xsl:if>
											<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:BillingSpecifiedPeriod/ram:StartDateTime/udt2:DateTimeString"/>
										</xsl:if>
										<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:BillingSpecifiedPeriod/ram:EndDateTime/udt2:DateTimeString !=''">
											<b>&#160;<xsl:value-of select="fcn:LabelName('BT-74', 'false')"/>&#160;</b>
											<!--br/-->
											<xsl:if test="$debug='true'">
												<xsl:text>BT-74@ </xsl:text>
											</xsl:if>
											<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:BillingSpecifiedPeriod/ram:EndDateTime/udt2:DateTimeString"/>
										</xsl:if>
									</p>
								</xsl:if>
							</div>
							<!--Start of invoice Header Information:-->
							<div class="col-6">
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-1', 'false')"/>
									</b>
									<!-- Inserting Invoice ID -->
									<br/>
									<xsl:if test="$debug='true'">
										<xsl:text>BT-1@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="rsm:ExchangedDocument/ram:ID"/>
									<br/>
								</p>
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-13', 'false')"/>
									</b>
									<br/>
									<!-- Inserting Order reference number  -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-13@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:BuyerOrderReferencedDocument/ram:IssuerAssignedID"/>
									<br/>
								</p>
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-10', 'false')"/>
									</b>
									<br/>
									<!-- Inserting Buyer Reference::  -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-10@ </xsl:text>
									</xsl:if>
									<xsl:for-each select="tokenize(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:BuyerReference, '\|')">
										<xsl:value-of select="fcn:BuyerReferenceTypeCode(.)"/>
										<xsl:if test="position() mod 2 = 0" >
											<br/>
										</xsl:if>
									</xsl:for-each>
									<br/>
								</p>
								<xsl:choose>
									<xsl:when test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:DuePayableAmount &lt; '0'">
										<p align="left" style="color:red">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-115', 'false')"/>
											</b>
											<br/>
											<!-- Inserting Total Payable amount  -->
											<xsl:if test="$debug='true'">
												<xsl:text> BT-115@</xsl:text>
											</xsl:if>
											<xsl:value-of select="fcn:Currency(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:DuePayableAmount)"/>&#160;<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:InvoiceCurrencyCode"/>
											<xsl:if test="$debug='true'">
												<xsl:text> BT-5@</xsl:text>
											</xsl:if>
											<br/>
										</p>
									</xsl:when>
									<xsl:otherwise>
										<p align="left">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-115', 'false')"/>
											</b>
											<br/>
											<!-- Inserting Total Payable amount  -->
											<xsl:if test="$debug='true'">
												<xsl:text> BT-115@</xsl:text>
											</xsl:if>
											<xsl:value-of select="fcn:Currency(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:DuePayableAmount)"/>&#160;<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:InvoiceCurrencyCode"/>
											<xsl:if test="$debug='true'">
												<xsl:text> BT-5@</xsl:text>
											</xsl:if>
											<br/>
										</p>
									</xsl:otherwise>
								</xsl:choose>
							</div>
						</div>
						<!--End of invoice Header Information-->
					</div>


					<div class="row indent" id="headerrow">
						<!-- Seller Row starts here-->
						<div class="row">
							<h3>
								<xsl:value-of select="fcn:LabelName('BG-4', 'false')"/>
							</h3>
						</div>
						<div class="row">
							<div class="col-6">
								<p>
									<!-- Inserting Accounting Supplier Party-->
									<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerTradeParty"/>
								</p>
							</div>
							<div class="col-6">
								<!-- Inserting contact information -->
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerTradeParty/ram:DefinedTradeContact !=''">
									<p style="margin-bottom: 0px;">
										<b>
											<xsl:value-of select="fcn:LabelName('BG-6', 'false')"/>
										</b>
									</p>

									<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerTradeParty" mode="accsupcontact"/>
								</xsl:if>
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerOrderReferencedDocument/ram:IssuerAssignedID">
									<p align="left">
										<b><xsl:value-of select="fcn:LabelName('BT-14', 'true')"/></b>
										<!-- Inserting Sales order reference number  -->
										<xsl:if test="$debug='true'">
											<xsl:text>BT-14@ </xsl:text>
										</xsl:if>
										<xsl:value-of select="rsm:ByChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerOrderReferencedDocument/ram:IssuerAssignedID"/>
										<br/>
									</p>
								</xsl:if>
							</div>
						</div>
					</div>

					<div class="row indent" id="headerrow">
						<!-- Inserting Accounting Customer Party -->
						<div class="row">
							<h3>
								<xsl:value-of select="fcn:LabelName('BG-7', 'false')"/>
							</h3>
						</div>
						<div class="row">
							<div class="col-6">
								<p>
									<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:BuyerTradeParty"/>
								</p>
							</div>
							<div class="col-6">
								<p>
									<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:BuyerTradeParty/ram:DefinedTradeContact !='' or rsm:SupplyChainTradeTransaction/ram:IncludedSupplyChainTradeLineItem/ram:SpecifiedLineTradeSettlement/ram:ReceivableSpecifiedTradeAccountingAccount/ram:ID !=''">
										<p style="margin-bottom: 0px;">
											<!-- Inserting Contact information-->
											<b>
												<xsl:value-of select="fcn:LabelName('BG-9', 'false')"/>
											</b>
										</p>
										<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:BuyerTradeParty" mode="acccuscontact"/>
									</xsl:if>
									<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:ReceivableSpecifiedTradeAccountingAccount/ram:ID !=''">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-19', 'true')"/>
										</b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-19@ </xsl:text>
										</xsl:if>
										<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:ReceivableSpecifiedTradeAccountingAccount/ram:ID"/>
									</xsl:if>
								</p>
							</div>
						</div>
					</div>

					<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:PayeeTradeParty != '' or rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerTaxRepresentativeTradeParty != ''">
						<div class="row indent" id="headerrow">
							<div class="col-6">
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:PayeeTradeParty !=''">
									<!-- Inserting Payee Party -->
									<p>
										<h3>
											<xsl:value-of select="fcn:LabelName('BG-10', 'false')"/>
										</h3>
										<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:PayeeTradeParty"/>
									</p>
								</xsl:if>
							</div>
							<div class="col-6">
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerTaxRepresentativeTradeParty !=''">
									<p>
										<h3>
											<xsl:value-of select="fcn:LabelName('BG-11', 'false')"/>
										</h3>
										<br/>
										<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerTaxRepresentativeTradeParty"/>
									</p>
								</xsl:if>
							</div>
						</div>
					</xsl:if>

					<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeDelivery!=''">
						<div class="row indent" id="headerrow">
							<div class="col-12">
								<!-- Start on DELIVERY BG-13 & BG-14 information -->
								<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeDelivery" mode="DocumentHeader"/>
								<xsl:if test="normalize-space(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeDelivery/ram:ActualDeliverySupplyChainEvent/ram:OccurrenceDateTime/udt2:DateTimeString) !=''">
									<p>
										<b>
											<xsl:value-of select="fcn:LabelName('BT-72', 'true')"/>
										</b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-72@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeDelivery/ram:ActualDeliverySupplyChainEvent/ram:OccurrenceDateTime/udt2:DateTimeString"/>
									</p>
								</xsl:if>
								<!-- End on DELIVERY information -->
							</div>
						</div>
					</xsl:if>
					<br/>
					<!--Start Invoiceline-->
					<div class="row" id="tablerow">
						<div class="col-12">
							<h3>
								<xsl:value-of select="fcn:LabelName('BG-25', 'false')"/>
							</h3>
							<table cellpadding="5px">
								<tr class="UBLInvoiceLineHeader">
									<th align="left" valign="top" width="5%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-126', 'false')"/>
										</b>
									</th>
									<th align="left" valign="top" width="10%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-155', 'false')"/>
										</b>
									</th>
									<th align="left" valign="top" width="35%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-153', 'false')"/>
										</b>
									</th>
									<th valign="top" align="left" width="10%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-129', 'false')"/>
										</b>
									</th>
									<th align="left" valign="top" width="10%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-146', 'false')"/>
										</b>
									</th>
									<th align="left" valign="top" width="10%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-151', 'false')"/>
										</b>
									</th>
									<th align="left" valign="top" width="10%">
										<b>
											<xsl:value-of select="fcn:LabelName('BG-28', 'false')"/>
											<br/>
											<xsl:value-of select="fcn:LabelName('BG-27', 'false')"/>
										</b>
									</th>
									<th align="right" valign="top" width="10%">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-131', 'false')"/>
										</b>
									</th>
								</tr>
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:IncludedSupplyChainTradeLineItem != ''">
									<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:IncludedSupplyChainTradeLineItem"/>
								</xsl:if>
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:IncludedSupplyChainTradeLineItem != ''">
									<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:IncludedSupplyChainTradeLineItem"/>
								</xsl:if>
							</table>
						</div>
					</div>
					<!--End Invoiceline-->
					<!-- Start sum of invoice line net amount: -->
					<div class="row" id="sum">
						<div class="col-6">
							<p align="left">
								<b>
									<xsl:value-of select="fcn:LabelName('BT-106', 'true')"/>
								</b>
							</p>
						</div>
						<div class="col-6">
							<p align="right">
								<b>
									<xsl:if test="$debug='true'">
										<xsl:text>BT-106@ </xsl:text>
									</xsl:if>
									<xsl:apply-templates select="fcn:Currency(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:LineTotalAmount)"/>&#160;<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:InvoiceCurrencyCode"/>
								</b>
							</p>
						</div>
					</div>
					<!-- End Sum of invoice line net amount -->
					<!-- Start AllowanceTotal Amount: -->
					<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:AllowanceTotalAmount !='' ">
						<div class="row" id="sum">
							<div class="col-6">
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-107', 'true')"/>
									</b>
								</p>
							</div>
							<div class="col-6">
								<p align="right">
									<b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-107@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="fcn:Currency(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:AllowanceTotalAmount)"/>&#160;<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:InvoiceCurrencyCode"/>
									</b>
								</p>
							</div>
						</div>
					</xsl:if>
					<!-- End AllowanceTotal Amount -->
					<!--Start Document Charges-->
					<xsl:if test="rsm:SupplyChainTradeTransaction/ram:IncludedSupplyChainTradeLineItem/ram:SpecifiedLineTradeSettlement/ram:SpecifiedTradeAllowanceCharge[rsm:SupplyChainTradeTransaction/ram:IncludedSupplyChainTradeLineItem/ram:SpecifiedLineTradeAgreement/ram:GrossPriceProductTradePrice/ram:AppliedTradeAllowanceCharge/ram:ChargeIndicator ='true']">
						<div class="row" id="tablerow">
							<div class="col-12">
								<h3>
									<xsl:value-of select="fcn:LabelName('BG-21', 'false')"/>
								</h3>
								<table>
									<tr>
										<th align="left" valign="top" colspan="2" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-98', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-97', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-95', 'false')"/>
											</b>
										</th>
										<th align="right" valign="top" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-100', 'false')"/>
											</b>
										</th>
										<th valign="top" align="right" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-92', 'false')"/>
											</b>
										</th>
									</tr>
									<xsl:for-each select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeAllowanceCharge">
										<xsl:if test="rsm:SupplyChainTradeTransaction/ram:IncludedSupplyChainTradeLineItem/ram:SpecifiedLineTradeAgreement/ram:GrossPriceProductTradePrice/ram:AppliedTradeAllowanceCharge/ram:ChargeIndicator ='true'">
											<xsl:call-template name="ChargeCrossII"/>
										</xsl:if>
									</xsl:for-each>
								</table>
							</div>
						</div>
					</xsl:if>
					<!--End Document Charges-->
					<!-- Start ChargeTotal Amount: -->
					<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:ChargeTotalAmount !='' ">
						<div class="row" id="sum">
							<div class="col-6">
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-108', 'true')"/>
									</b>
								</p>
							</div>
							<div class="col-6">
								<p align="right">
									<b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-108@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="fcn:Currency(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:ChargeTotalAmount)"/>&#160;<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:InvoiceCurrencyCode"/>
									</b>
								</p>
							</div>
						</div>
					</xsl:if>
					<!-- End ChargeTotal Amount -->
					<!-- Start Prepaid Amount: -->
					<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:TotalPrepaidAmount !='' ">
						<div class="row" id="headerrow">
							<div class="col-6">
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-113', 'true')"/>
									</b>
								</p>
							</div>
							<div class="col-6">
								<p align="right">
									<xsl:if test="$debug='true'">
										<xsl:text>BT-113@ </xsl:text>
									</xsl:if>
									<xsl:apply-templates select="fcn:Currency(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:TotalPrepaidAmount)"/>&#160;<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:InvoiceCurrencyCode"/>
								</p>
							</div>
						</div>
					</xsl:if>
					<!-- End Prepaid Amount -->
					<!-- Start Rounding Amount: -->
					<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:RoundingAmount !='' ">
						<div class="row" id="headerrow">
							<div class="col-6">
								<p align="left">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-114', 'true')"/>
									</b>
								</p>
							</div>
							<div class="col-6">
								<xsl:if test="$debug='true'">
									<xsl:text>BT-114@ </xsl:text>
								</xsl:if>
								<p align="right">
									<xsl:apply-templates select="fcn:Currency(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:RoundingAmount)"/>
								</p>
							</div>
						</div>
					</xsl:if>
					<!-- End Rounding Amount -->
					<!-- Start Payable Amount: -->
					<div class="row" id="headerrow">
						<xsl:choose>
							<xsl:when test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:DuePayableAmount &lt; '0'">
								<div class="col-6">
									<h2 align="left" style="color:red">
										<xsl:value-of select="fcn:LabelName('BT-115', 'true')"/>
									</h2>
								</div>
								<div class="col-6">
									<h2 align="right" style="color:red">
										<xsl:if test="$debug='true'">
											<xsl:text>BT-115@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="fcn:Currency(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:DuePayableAmount)"/>&#160;<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:InvoiceCurrencyCode"/>
									</h2>
								</div>
							</xsl:when>
							<xsl:otherwise>
								<div class="col-6">
									<h2 align="left">
										<xsl:value-of select="fcn:LabelName('BT-115', 'true')"/>
									</h2>
								</div>
								<div class="col-6">
									<h2 align="right">
										<xsl:if test="$debug='true'">
											<xsl:text>BT-115@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="fcn:Currency(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:DuePayableAmount)"/>&#160;<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:InvoiceCurrencyCode"/>
									</h2>
								</div>
							</xsl:otherwise>
						</xsl:choose>
					</div>
					<!-- End Payable Amount -->
					<!-- Start document totals: -->
					<!-- Start on PAYMENT TERMS information -->
					<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradePaymentTerms !=''">
						<div class="row" id="tablerow">
							<div class="col-12">
								<b>
									<xsl:value-of select="fcn:LabelName('BT-20', 'true')"/>
								</b>
								<p>
									<xsl:if test="$debug='true'">
										<xsl:text>BT-20@ </xsl:text>
									</xsl:if>
									<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradePaymentTerms/ram:Description"/>
								</p>
							</div>
						</div>
					</xsl:if>
					<!-- Start Tax Amount: -->
					<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:TaxCurrencyCode !=''">
						<div class="row">
							<div class="col-12">
								<p>
									<b>
										<xsl:value-of select="fcn:LabelName('BT-6', 'true')"/>
									</b>
									<xsl:if test="$debug='true'">
										<xsl:text>BT-6@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:TaxCurrencyCode"/>
								</p>
							</div>
						</div>
					</xsl:if>
					<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:TaxTotalAmount">
						<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:TaxTotalAmount[@currencyID=../../ram:InvoiceCurrencyCode]">
							<div class="row" id="headerrow">
								<div class="col-6">
									<p>
										<b>
											<xsl:value-of select="fcn:LabelName('BT-110', 'true')"/>
										</b>
									</p>
								</div>
								<div class="col-3">
									<p align="right">
										<xsl:if test="$debug='true'">
											<xsl:text>BT-110@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="fcn:Currency(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:TaxTotalAmount[@currencyID=../../ram:TaxCurrencyCode])"/>&#160;<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:TaxCurrencyCode"/>
									</p>
								</div>
								<div class="col-3">
									<p align="right">
										<b>
											<xsl:if test="$debug='true'">
												<xsl:text>BT-111@ </xsl:text>
											</xsl:if>
											<xsl:apply-templates select="fcn:Currency(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:TaxTotalAmount[@currencyID=../../ram:InvoiceCurrencyCode])"/>&#160;<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:InvoiceCurrencyCode"/>
										</b>
									</p>
								</div>
							</div>
						</xsl:if>
					</xsl:if>
					<!-- End Tax Amount -->
					<!-- Start TaxExclusive Amount: -->
					<div class="row" id="headerrow">
						<div class="col-6">
							<p align="left">
								<b>
									<xsl:value-of select="fcn:LabelName('BT-109', 'true')"/>
								</b>
							</p>
						</div>
						<div class="col-6">
							<p align="right">
								<xsl:if test="$debug='true'">
									<xsl:text>BT-109@ </xsl:text>
								</xsl:if>
								<xsl:apply-templates select="fcn:Currency(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:TaxBasisTotalAmount)"/>&#160;<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:InvoiceCurrencyCode"/>
							</p>
						</div>
					</div>
					<!-- End TaxExclusive Amount -->
					<!-- Start TaxInclusive Amount: -->
					<div class="row" id="headerrow">
						<div class="col-6">
							<p align="left">
								<b>
									<xsl:value-of select="fcn:LabelName('BT-112', 'true')"/>
								</b>
							</p>
						</div>
						<div class="col-6">
							<p align="right">
								<b>
									<xsl:if test="$debug='true'">
										<xsl:text>BT-112@ </xsl:text>
									</xsl:if>
									<xsl:apply-templates select="fcn:Currency(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:GrandTotalAmount)"/>&#160;<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:InvoiceCurrencyCode"/>
								</b>
							</p>
						</div>
					</div>
					<!-- End TaxInclusive Amount -->
					<!-- Start VAT Breakdown: -->
					<div class="row" id="tablerow">
						<div class="col-12">
							<h3>
								<xsl:value-of select="fcn:LabelName('BG-23', 'false')"/>
							</h3>
							<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:ApplicableTradeTax/ram:TaxPointDate/udt2:DateString!='' or rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:ApplicableTradeTax/ram:DueDateTypeCode!=''">
								<p>
									<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:ApplicableTradeTax/ram:TaxPointDate/udt2:DateString !=''">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-7', 'true')"/>
										</b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-7@ </xsl:text>
										</xsl:if>
										<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:ApplicableTradeTax/ram:TaxPointDate/udt2:DateString"/>
									</xsl:if>
									<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:ApplicableTradeTax/ram:DueDateTypeCode != ''">
										<br/>
										<b>
											<xsl:value-of select="fcn:LabelName('BT-8', 'true')"/>
										</b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-8@ </xsl:text>
										</xsl:if>
										<xsl:value-of select="fcn:UBLDescriptionCode(rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:ApplicableTradeTax/ram:DueDateTypeCode)"/> [<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:ApplicableTradeTax/ram:DueDateTypeCode"/>]
										<br/>
									</xsl:if>
								</p>
							</xsl:if>
						</div>
					</div>
					<div class="row" id="tablerow">
						<div class="col-12">
							<table>
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:TaxTotalAmount">
									<tr class="TAXInformationHeader">
										<th align="left" valign="top" colspan="2" width="25%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-118', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2" width="25%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-120', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2" width="25%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-116', 'false')"/>
											</b>
										</th>
										<!--th valign="top" align="right">
										<b>
											<xsl:value-of select="fcn:LabelName('BT-111', 'true')"/>
										</b>
									</th-->
										<th valign="top" align="right" width="25%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-117', 'false')"/>
											</b>
										</th>
									</tr>
									<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:ApplicableTradeTax"/>
								</xsl:if>
							</table>
						</div>
					</div>
					<!--End VAT Breakdown -->
					<!-- Start on PAYMENT MEANS information -->
					<div class="row" id="tablerow">
						<div class="col-12">
							<h3>
								<xsl:value-of select="fcn:LabelName('BG-16', 'false')"/>
							</h3>
							<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementPaymentMeans/ram:PayeePartyCreditorFinancialAccount/ram:IBANID !=''">
								<table>
									<tr>
										<th align="left" valign="top">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-81', 'false')"/>
											</b>&#160;&#160;
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-86', 'false')"/>
											</b>
										</th>

										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-84', 'false')"/>
											</b>
										</th>

										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-85', 'false')"/>
											</b>
										</th>
										<th align="right" valign="top">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-83', 'false')"/>
											</b>
										</th>
									</tr>
									<xsl:for-each select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementPaymentMeans">
										<xsl:if test="ram:PayeePartyCreditorFinancialAccount !=''">
											<xsl:call-template name="ram:SpecifiedTradeSettlementPaymentMeans"/>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementPaymentMeans">
										<xsl:if test="not(ram:PayerPartyDebtorFinancialAccount) and not(ram:ApplicableTradeSettlementFinancialCard) and not(ram:PayeePartyCreditorFinancialAccount)">
											<xsl:call-template name="ram:SpecifiedTradeSettlementPaymentMeans"/>
										</xsl:if>
									</xsl:for-each>
								</table>
							</xsl:if>
							<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementPaymentMeans/ram:ApplicableTradeSettlementFinancialCard !=''">
								<table>
									<tr>
										<th align="left" valign="top">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-81', 'false')"/>
											</b>&#160;&#160;
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-86-1', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-87', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-88', 'false')"/>
											</b>
										</th>
										<th align="right" valign="top">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-83', 'false')"/>
											</b>
										</th>
									</tr>
									<xsl:for-each select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementPaymentMeans">
										<xsl:if test="ram:ApplicableTradeSettlementFinancialCard !=''">
											<xsl:call-template name="ram:SpecifiedTradeSettlementPaymentMeans"/>
										</xsl:if>
									</xsl:for-each>
								</table>
							</xsl:if>
							<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementPaymentMeans/ram:PayerPartyDebtorFinancialAccount !=''">
								<table>
									<tr>
										<th align="left" valign="top">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-81', 'false')"/>
											</b>&#160;&#160;
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-91', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-89', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-90', 'false')"/>
											</b>
										</th>
										<th align="right" valign="top">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-83', 'false')"/>
											</b>
										</th>
									</tr>
									<xsl:for-each select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeSettlementPaymentMeans">
										<xsl:if test="ram:PayerPartyDebtorFinancialAccount !=''">
											<xsl:call-template name="ram:SpecifiedTradeSettlementPaymentMeans"/>
										</xsl:if>
									</xsl:for-each>

								</table>
							</xsl:if>
						</div>
					</div>
					<!-- End of PAYMENT MEANS information -->
					<!-- Start Allowances and charges on document level: -->
					<!--Start Document allowances-->
					<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeAllowanceCharge[udt2:Indicator ='false']">
						<div class="row" id="tablerow">
							<div class="col-12">
								<h3>
									<xsl:value-of select="fcn:LabelName('BG-20', 'false')"/>
								</h3>
								<table>
									<tr>
										<th align="left" valign="top" colspan="2" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-105', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" colspan="2" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-104', 'false')"/>
											</b>
										</th>
										<th align="left" valign="top" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-102', 'false')"/>
											</b>
										</th>
										<th align="right" valign="top" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-93', 'false')"/>
											</b>
										</th>
										<th valign="top" align="right" width="20%">
											<b>
												<xsl:value-of select="fcn:LabelName('BT-99', 'false')"/>
											</b>
										</th>
									</tr>
									<xsl:for-each select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradeAllowanceCharge">
										<xsl:if test="udt2:Indicator ='false'">
											<xsl:call-template name="AllowanceCrossII"/>
										</xsl:if>
									</xsl:for-each>
								</table>
							</div>
						</div>
					</xsl:if>
					<!--End Document allowances-->

					<!-- Start on Aditional Documents -->
					<br/>
					<h3>
						<xsl:value-of select="fcn:LabelName('BG-24', 'false')"/>
					</h3>
					<div class="row">
						<div class="col-12">
							<div class="col-6">
								<p>
									<xsl:if test='rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:InvoiceReferencedDocument'>
										<!-- Start of BG-3 Section -->
										<!--b>
									<xsl:value-of select="fcn:LabelName('BG-3', 'true')"/>
								</b -->
										<b>
											<xsl:value-of select="fcn:LabelName('BT-25', 'true')"/>
										</b>
										<xsl:for-each select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeSettlement/ram:InvoiceReferencedDocument">
											<br/>
											<!-- Inserting Preceding invoice number  -->
											<xsl:if test="$debug='true'">
												<xsl:text>BT-25@ </xsl:text>
											</xsl:if>
											<xsl:value-of select="ram:IssuerAssignedID"/>
											<!-- Inserting Preceding Invoice Issue Date  -->
											<xsl:if test="$debug='true'">
												<xsl:text> BT-26@ </xsl:text>
											</xsl:if>
											<xsl:if test="ram:FormattedIssueDateTime/qdt:DateTimeString != ''">
									 ( <xsl:value-of select="ram:FormattedIssueDateTime/qdt:DateTimeString"/> )
											</xsl:if>
										</xsl:for-each>
										<!-- END of BG-3 Section -->
									</xsl:if>
								</p>
							</div>
							<div class="col-6">	
								<p>
									<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:ContractReferencedDocument !=''">
										<br/>
										<b>
											<xsl:value-of select="fcn:LabelName('BT-12', 'true')"/>
										</b>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-12@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:ContractReferencedDocument"/>
									</xsl:if>

									<xsl:if test="rsm:ExchangedDocument/ram:IncludedNote/ram:Content[.!='']">
										<br/>
										<b>
											<xsl:value-of select="fcn:LabelName('BT-22', 'true')"/>
										</b>
										<xsl:choose>
											<xsl:when test="string-length(rsm:ExchangedDocument/ram:IncludedNote/ram:Content/.)&lt;5">
												<xsl:if test="$debug='true'">
													<xsl:text>BT-21@ </xsl:text>
												</xsl:if>
												<xsl:variable name="descripcion">
													<xsl:value-of select="fcn:InvoiceNoteCode(rsm:ExchangedDocument/ram:IncludedNote/ram:Content)"/>
												</xsl:variable>
												<xsl:call-template name="replace">
													<xsl:with-param name="string" select="$descripcion"/>
												</xsl:call-template>
												<xsl:if test="rsm:ExchangedDocument/ram:IncludedNote/ram:Content!=$descripcion">
													<xsl:value-of select="concat(' [', rsm:ExchangedDocument/ram:IncludedNote/ram:Content, ']')"/>
												</xsl:if>
											</xsl:when>
											<xsl:otherwise>
												<xsl:if test="$debug='true'">
													<xsl:text>BT-22@ </xsl:text>
												</xsl:if>
												<xsl:apply-templates select="rsm:ExchangedDocument/ram:IncludedNote/ram:Content"/>
											</xsl:otherwise>
										</xsl:choose>
									</xsl:if>
								</p>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">	
							<p>
								<!-- Start of BG-2 Section -->
								<xsl:if test="rsm:ExchangedDocumentContext/ram:BusinessProcessSpecifiedDocumentContextParameter/ram:ID!=''">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-23', 'true')"/>
									</b>
									<xsl:if test="$debug='true'">
										<xsl:text>BT-23@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="rsm:ExchangedDocumentContext/ram:BusinessProcessSpecifiedDocumentContextParameter/ram:ID"/>
									<br/>
								</xsl:if>
								<xsl:if test="rsm:ExchangedDocumentContext/ram:GuidelineSpecifiedDocumentContextParameter/ram:ID!=''">
									<b>
										<xsl:value-of select="fcn:LabelName('BT-24', 'true')"/>
									</b>
									<xsl:if test="$debug='true'">
										<xsl:text>BT-24@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="rsm:ExchangedDocumentContext/ram:GuidelineSpecifiedDocumentContextParameter/ram:ID"/>
								</xsl:if>
							</p>
							<!-- END of BG-2 Section -->
							<p>
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:AdditionalReferencedDocument !=''">
									<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:AdditionalReferencedDocument[ram:TypeCode != '130' and ram:TypeCode != '50' or not(exists(ram:TypeCode))]" mode="Supporting"/>
								</xsl:if>
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:AdditionalReferencedDocument !=''">

									<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:AdditionalReferencedDocument[ram:TypeCode='130' or ram:TypeCode='50']" mode="InvoicedObject"/>

								</xsl:if>
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeDelivery/ram:DespatchAdviceReferencedDocument/ram:IssuerAssignedID">

									<br/>
									<b>
										<xsl:value-of select="fcn:LabelName('BT-16', 'true')"/>
									</b>
									<!-- Inserting Despatch advice reference  -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-16@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeDelivery/ram:DespatchAdviceReferencedDocument/ram:IssuerAssignedID"/>

								</xsl:if>
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeDelivery/ram:ReceivingAdviceReferencedDocument/ram:IssuerAssignedID">

									<br/>
									<b>
										<xsl:value-of select="fcn:LabelName('BT-15', 'true')"/>
									</b>
									<!-- Inserting Receipt advice reference  -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-15@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeDelivery/ram:ReceivingAdviceReferencedDocument/ram:IssuerAssignedID"/>

								</xsl:if>
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:AdditionalReferencedDocument/ram:IssuerAssignedID">

									<br/>
									<b>
										<xsl:value-of select="fcn:LabelName('BT-17', 'true')"/>
									</b>
									<!-- Inserting Originator advice reference  -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-17@ </xsl:text>
									</xsl:if>
									<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:AdditionalReferencedDocument/ram:IssuerAssignedID"/>

								</xsl:if>
								<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SpecifiedProcuringProject/ram:ID">

									<br/>
									<b>
										<xsl:value-of select="fcn:LabelName('BT-11', 'true')"/>
									</b>
									<!-- Inserting Project advice reference  -->
									<xsl:if test="$debug='true'">
										<xsl:text>BT-11@ </xsl:text>
									</xsl:if>
									<!-- Use "Project reference" as default value for Name. -->
									<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SpecifiedProcuringProject/ram:ID"/>

								</xsl:if>
							</p>
						</div>
					</div>
					<!-- End on Aditional Documents -->

					<!-- Start on technical stylesheet footer - for all transactions -->
					<div class="row" id="tablerow">
						<div class="col-12">
							<p>
								<small>
									<!-- N/A <xsl:value-of select="cbc:UBLVersionID"/>
								<br/>
								<xsl:if test="cbc:UUID !=''">
									<xsl:value-of select="cbc:UUID"/>
									<br/>
								</xsl:if> -->
									<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerTradeParty/ram:URIUniversalCommunication/ram:URIID">
										<br/>

										<xsl:value-of select="fcn:LabelName('BT-34', 'true')"/>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-34@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerTradeParty/ram:URIUniversalCommunication/ram:URIID"/>
										<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerTradeParty/ram:URIUniversalCommunication/ram:URIID/@schemeID !='' ">
											[<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:SellerTradeParty/ram:URIUniversalCommunication/ram:URIID/@schemeID"/>]
										</xsl:if>

									</xsl:if>
									<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:BuyerTradeParty/ram:URIUniversalCommunication/ram:URIID">
										<br/>

										<xsl:value-of select="fcn:LabelName('BT-49', 'true')"/>
										<xsl:if test="$debug='true'">
											<xsl:text>BT-49@ </xsl:text>
										</xsl:if>
										<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:BuyerTradeParty/ram:URIUniversalCommunication/ram:URIID"/>
										<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:BuyerTradeParty/ram:URIUniversalCommunication/ram:URIID/@schemeID !='' ">
										[<xsl:value-of select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeAgreement/ram:BuyerTradeParty/ram:URIUniversalCommunication/ram:URIID/@schemeID"/>]
										</xsl:if>
									</xsl:if>
									<br/>
									<br/>
									<xsl:value-of select="replace(fcn:LabelName('UT-1', 'false'), '%', 'CII')"/>
									<br/>
									<xsl:value-of select="fcn:LabelName('UT-2', 'false')"/>&#160;<xsl:value-of  select="format-date(current-date(), '[D01]/[M01]/[Y0001]')"/>&#160;
									<xsl:value-of select="fcn:LabelName('UT-3', 'false')"/>&#160;<xsl:value-of select="format-time(current-time(), '[H01]:[m01]:[s01] ([z])')"/>
								</small>
							</p>
						</div>
					</div>
					<!-- End of technical stylesheet footer-->

				</div>
			</body>
		</html>
	</xsl:template>

</xsl:stylesheet>
