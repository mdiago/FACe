﻿<?xml version="1.0" encoding="UTF-8"?>
<!--
******************************************************************************************************************

		Based on PEPPOL Instance Documentation	

		title= CommonTemplates.xml	
		publisher= "SFTI tekniska kansli"
		Adaptor= "SGAD"
		Creator= SFTI/SL
		created= 2014-02-12
		adapted= 2019-04
		conformsTo= UBL-Invoice-2.1.xsd and UBL-CreditNote-2.1.xsd
		description= "Common templates for displaying EN16931 on FACe based on the document	PEPPOL BIS 4A/5A, version 2.0 (Invoice and Credit note)"
		
		For more information about this adaptation see https://administracionelectronica.gob.es/ctt/face
		For more information about the PEPPOL original version see www.sfti.se or email tekniskt.kansli@skl.se
		
******************************************************************************************************************
-->
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:fcn="urn:sfti:se:xsl:functions" xmlns:n1="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2" xmlns:n2="urn:oasis:names:specification:ubl:schema:xsd:CreditNote-2" xmlns:cdl="http://docs.oasis-open.org/codelist/ns/genericode/1.0/" xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2" xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2" xmlns:ccts="urn:oasis:names:specification:ubl:schema:xsd:CoreComponentParameters-2" xmlns:sdt="urn:oasis:names:specification:ubl:schema:xsd:SpecializedDatatypes-2" xmlns:udt="urn:un:unece:uncefact:data:specification:UnqualifiedDataTypesSchemaModule:2" xmlns:qdt="urn:un:unece:uncefact:data:standard:QualifiedDataType:100" xmlns:udt2="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100" xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100" xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100" version="2.0" exclude-result-prefixes="n1 n2 cdl cac cbc ccts sdt udt qdt udt2 rsm ram">
	<xsl:include href="user_config.xsl"/>
	<xsl:variable name="moduleDocBT_en" select="document('Headlines-BT_en.xml')"/>
	<xsl:variable name="moduleDocBT" select="document(concat('Headlines-BT_', $lang, '.xml'))"/>
	<xsl:variable name="invoiceBaseType" select="document(concat('UBLInvoiceBaseType_',$lang, '.xml'))"/>
	<xsl:variable name="UNCL1001" select="document(concat('UNCL1001_', $lang, '.xml'))"/>
	<xsl:variable name="UNCL4461" select="document(concat('UNCL4461_', $lang, '.xml'))"/>
	<xsl:variable name="UNCL7161" select="document(concat('UNCL7161_', $lang, '.xml'))"/>
	<xsl:variable name="UNCL5189" select="document(concat('UNCL5189_', $lang, '.xml'))"/>
	<xsl:variable name="UNCL1153" select="document(concat('UNCL1153_', $lang, '.xml'))"/>
	<xsl:variable name="UNCL4451" select="document(concat('UNCL4451_', $lang, '.xml'))"/>
	<xsl:variable name="UBLDescriptionCode" select="document(concat('UBLPeriodDescriptionCode_', $lang, '.xml'))"/>
	<xsl:variable name="UBLTaxCategoryCode" select="document(concat('UBLTaxCategoryCode_', $lang, '.xml'))"/>
	<xsl:variable name="UBLClassificationCode" select="document(concat('UBLClassificationCode_', $lang, '.xml'))"/>
	<xsl:variable name="UNECE" select="document(concat('UNECE_', $lang, '.xml'))"/>
	<xsl:variable name="UBLBuyerReference" select="document(concat('UBLBuyerReference_', $lang, '.xml'))"/>
	<xsl:variable name="UNCL1001_en" select="document('UNCL1001_en.xml')"/>
	<xsl:variable name="UNCL4461_en" select="document('UNCL4461_en.xml')"/>
	<xsl:variable name="UNCL7161_en" select="document('UNCL7161_en.xml')"/>
	<xsl:variable name="UNCL5189_en" select="document('UNCL5189_en.xml')"/>
	<xsl:variable name="UNCL1153_en" select="document('UNCL1153_en.xml')"/>
	<xsl:variable name="UNCL4451_en" select="document('UNCL4451_en.xml')"/>
	<xsl:variable name="UBLDescriptionCode_en" select="document('UBLPeriodDescriptionCode_en.xml')"/>
	<xsl:variable name="UBLTaxCategoryCode_en" select="document('UBLTaxCategoryCode_en.xml')"/>
	<xsl:variable name="UBLClassificationCode_en" select="document('UBLClassificationCode_en.xml')"/>
	<xsl:variable name="invoiceBaseType_en" select="document('UBLInvoiceBaseType_en.xml')"/>
	<xsl:variable name="UNECE_en" select="document('UNECE_en.xml')"/>
	<xsl:variable name="UBLBuyerReference_en" select="document('UBLBuyerReference_en.xml')"/>
	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>
	<!-- En function som i första hand tar DisplayName och i andra hand Business Termför språk istället för i varje xpath -->
	<xsl:function name="fcn:LabelName">
		<xsl:param name="BT-ID"/>
		<!-- BT inparameter -->
		<xsl:param name="Colon-Suffix"/>
		<!-- true/false om kolon ska läggas till efter business term name-->
		<xsl:variable name="LabelVariable" select="if (exists($moduleDocBT/SemanticModel/BusinessTerm[@id=$BT-ID]/DisplayName)) then ($moduleDocBT/SemanticModel/BusinessTerm[@id=$BT-ID]/DisplayName) else ($moduleDocBT/SemanticModel/BusinessTerm[@id=$BT-ID]/TermName)"/>
		<xsl:value-of select="$LabelVariable"/>
		<xsl:if test="$Colon-Suffix ='true' and $LabelVariable != '' ">: </xsl:if>
	</xsl:function>
	<!--A function to display currencies with spaces as thousand delimiter-->
	<xsl:function name="fcn:Currency">
		<xsl:param name="currencyvalue"/>
		<xsl:variable name="integers" select="substring-before($currencyvalue, '.')"/>
		<xsl:choose>
			<xsl:when test="$integers != ''">
				<xsl:variable name="decimals" select="substring-after($currencyvalue, '.')"/>
				<xsl:variable name="transformedIntegers" select="translate(format-number(number($integers), '#,###'), ',', '.' )"/>
				<xsl:choose>
					<xsl:when test="$transformedIntegers !='NaN'">
						<xsl:value-of select="concat($transformedIntegers,',', $decimals)"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="$currencyvalue"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:otherwise>
				<xsl:variable name="transformedIntegers" select="translate(format-number($currencyvalue, '#,###'), ',', '.' )"/>
				<xsl:choose>
					<xsl:when test="$transformedIntegers !='NaN'">
						<xsl:value-of select="$transformedIntegers"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="$currencyvalue"/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:function>
	<xsl:function name="fcn:getDate">
		<xsl:param name="datevalue"/>
		<!-- Format date from IS0 8601 (YYYY-mm-dd or YYYY/mm/dd) to standard (dd-mm-YYYY)-->
		<xsl:choose>
			<xsl:when test="string-length($datevalue)=10 and translate(concat(substring($datevalue,5,1), substring($datevalue,8,1)),'/','-')='--'">
				<xsl:variable name="date" select="xs:date(concat(substring($datevalue,1,4),'-', substring($datevalue,6,2),'-', substring($datevalue,9,2)))"/>
				<xsl:value-of  select="format-date($date, '[D01]-[M01]-[Y0001]')"/>
			</xsl:when>
			<xsl:otherwise><xsl:value-of select="$datevalue"/></xsl:otherwise>
		</xsl:choose>
	</xsl:function>
	<xsl:function name="fcn:getGenericCode">
		<xsl:param name="documentName"/>
		<xsl:param name="documentName_en"/>
		<xsl:param name="documentCode"/>
		<xsl:variable name="genericCodeValue" select="if (exists($documentName/cdl:CodeList/cdl:SimpleCodeList/cdl:Row/cdl:Value/cdl:SimpleValue[../@ColumnRef='name' and ../../cdl:Value[@ColumnRef='code']/cdl:SimpleValue=$documentCode])) then ($documentName/cdl:CodeList/cdl:SimpleCodeList/cdl:Row/cdl:Value/cdl:SimpleValue[../@ColumnRef='name' and ../../cdl:Value[@ColumnRef='code']/cdl:SimpleValue=$documentCode]) else ($documentName_en/cdl:CodeList/cdl:SimpleCodeList/cdl:Row/cdl:Value/cdl:SimpleValue[../@ColumnRef='name' and ../../cdl:Value[@ColumnRef='code']/cdl:SimpleValue=$documentCode])"/>
		<xsl:choose>
			<xsl:when test="$genericCodeValue !=''">
				<xsl:value-of select="$genericCodeValue"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="$documentCode"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:function>
	<!--Function to pick the Base Type codes for document header-->
	<xsl:function name="fcn:DocumentHeader">
		<xsl:param name="DocumentCode"/>
		<xsl:value-of select="fcn:getGenericCode($invoiceBaseType, $invoiceBaseType_en, $DocumentCode)"/>
	</xsl:function>
	<!--Function to pick the UNCL1001 codes for document header-->
	<xsl:function name="fcn:DocumentCode">
		<xsl:param name="DCode"/>
		<xsl:value-of select="fcn:getGenericCode($UNCL1001, $UNCL1001_en, $DCode)"/>
	</xsl:function>
	<xsl:function name="fcn:UBLDescriptionCode">
		<xsl:param name="Code"/>
		<xsl:value-of select="fcn:getGenericCode($UBLDescriptionCode, $UBLDescriptionCode_en, $Code)"/>
	</xsl:function>
	<xsl:function name="fcn:UBLTaxCategoryCode">
		<xsl:param name="Code"/>
		<xsl:value-of select="fcn:getGenericCode($UBLTaxCategoryCode, $UBLTaxCategoryCode_en, $Code)"/>
	</xsl:function>
	<xsl:function name="fcn:UBLClassificationCode">
		<xsl:param name="Code"/>
		<xsl:value-of select="fcn:getGenericCode($UBLClassificationCode, $UBLClassificationCode_en, $Code)"/>
	</xsl:function>
	<!--Function to pick the AllowanceReasonCodes-->
	<xsl:function name="fcn:AllowanceReasonCode">
		<xsl:param name="AllowanceCode"/>
		<xsl:value-of select="fcn:getGenericCode($UNCL5189, $UNCL5189_en, $AllowanceCode)"/>
	</xsl:function>
	<!--Function to pick the ChargeReasonCodes-->
	<xsl:function name="fcn:ChargeReasonCode">
		<xsl:param name="ChargeCode"/>
		<xsl:value-of select="fcn:getGenericCode($UNCL7161, $UNCL7161_en, $ChargeCode)"/>
	</xsl:function>
	<!--Function to pick up payment means code-->
	<xsl:function name="fcn:PaymentMeansCode">
		<xsl:param name="PaymentCode"/>
		<xsl:value-of select="fcn:getGenericCode($UNCL4461, $UNCL4461_en, $PaymentCode)"/>
	</xsl:function>
	<!--Function to pick up Scheme identifier code-->
	<xsl:function name="fcn:SchemeIdentifierCode">
		<xsl:param name="SchemeID"/>
		<xsl:value-of select="fcn:getGenericCode($UNCL1153, $UNCL1153_en, $SchemeID)"/>
	</xsl:function>
	<!--Function to pick up invoice note code-->
	<xsl:function name="fcn:InvoiceNoteCode">
		<xsl:param name="NoteCode"/>
		<xsl:value-of select="fcn:getGenericCode($UNCL4451, $UNCL4451_en, $NoteCode)"/>
	</xsl:function>
	<!--Function to pick the UNECE codes-->
	<xsl:function name="fcn:UNECECode">
		<xsl:param name="Code"/>
		<xsl:value-of select="fcn:getGenericCode($UNECE, $UNECE_en, $Code)"/>
	</xsl:function>
	<!--Function to pick the FACE Role Type codes-->
	<xsl:function name="fcn:BuyerReferenceTypeCode">
		<xsl:param name="Code"/>
		<xsl:variable name="Name">
			<xsl:value-of select="fcn:getGenericCode($UBLBuyerReference, $UBLBuyerReference_en, $Code)"/>
		</xsl:variable>
		<xsl:choose>
			<xsl:when test="($Code!=$Name)">
				<xsl:value-of select="concat($Name,':')"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="$Code"/>
			</xsl:otherwise>
		</xsl:choose>
		<!--xsl:value-of select="if ($Code!=$Name) then concat($Name,': ') else concat($Code,'&#10;')"/-->
	</xsl:function>
	<xsl:template name="replace">
		<xsl:param name="string"/>
		<xsl:choose>
			<xsl:when test="contains($string,'&#10;')">
				<xsl:value-of select="substring-before($string,'&#10;')"/>
				<br/>
				<xsl:call-template name="replace">
					<xsl:with-param name="string" select="substring-after($string,'&#10;')"/>
				</xsl:call-template>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="$string"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<xsl:template match="cbc:Note">
		<xsl:call-template name="replace">
			<xsl:with-param name="string" select="."/>
		</xsl:call-template>
	</xsl:template>
	<!--Party templates from here:-->
	<xsl:template match=" cac:AccountingSupplierParty">
		<xsl:call-template name="SellerParty"/>
	</xsl:template>
	<xsl:template match=" cac:AccountingCustomerParty">
		<xsl:call-template name="BuyerParty"/>
	</xsl:template>
	<!--SELLER PARTY STARTS HERE-->
	<xsl:template name="SellerParty">
		<p style="margin-bottom: 0px;">
			<!--xsl:value-of select="fcn:LabelName('BT-28', 'true')"/-->
			<b>
				<xsl:choose>
					<xsl:when test="cac:Party/cac:PartyName !=''">
						<xsl:if test="$debug='true'">
							<xsl:text>BT-28@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="cac:Party/cac:PartyName"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:if test="$debug='true'">
							<xsl:text>BT-27@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cbc:RegistrationName"/>
					</xsl:otherwise>
				</xsl:choose>
			</b>
			<br/>
			<b>
				<xsl:value-of select="fcn:LabelName('BG-5', 'false')"/>
			</b>
		</p>
		<xsl:call-template name="SellerPostalAddress"/>
		<xsl:for-each select="cac:Party/cac:PartyIdentification">
			<xsl:if test="cbc:ID">
				<!--small-->
				<b><xsl:value-of select="fcn:LabelName('BT-29', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-29@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cbc:ID"/>
				<xsl:if test="cbc:ID/@schemeID !='' ">
							 [<xsl:apply-templates select="cbc:ID/@schemeID"/>]
				</xsl:if>
					 
				<!--/small-->
			</xsl:if>
		</xsl:for-each>
		<!--Party legal registration: -->
		<xsl:if test="cac:Party/cac:PartyLegalEntity">
			<xsl:if test="cac:Party/cac:PartyLegalEntity/cbc:CompanyID">
				<xsl:if test="cac:Party/cac:PartyIdentification">
					<br/>
				</xsl:if>
				<!--small-->
				<b><xsl:value-of select="fcn:LabelName('BT-30', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-30@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cbc:CompanyID"/>
				<xsl:if test="cac:Party/cac:PartyLegalEntity/cbc:CompanyID/@schemeID !='' ">
							 [<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cbc:CompanyID/@schemeID"/>]
				</xsl:if>
				<!--/small-->
			</xsl:if>
			<xsl:if test="cac:Party/cac:PartyLegalEntity/cbc:RegistrationName !=''">
				<br/>
				<!--small-->
				<b><xsl:value-of select="fcn:LabelName('BT-27', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-27@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cbc:RegistrationName"/>
				<!--/small-->
			</xsl:if>
			<xsl:if test="cac:Party/cac:PartyLegalEntity/cbc:CompanyLegalForm != ''">
				<!--small-->
				<br/>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-33@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cbc:CompanyLegalForm"/>
				<!--/small-->
			</xsl:if>
			<xsl:if test="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress !=''">
				<br/>
				<!--small-->
				<b><xsl:value-of select="fcn:LabelName('BT-33', 'true')"/></b>
				<xsl:choose>
					<xsl:when test="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CityName !='' and          cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:Country !=''">
						<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CityName"/>, 

						<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:Country"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:if test="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CityName !=''">
							<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CityName"/>
						</xsl:if>
						<xsl:if test="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:Country !=''">
							<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:Country"/>
						</xsl:if>
					</xsl:otherwise>
				</xsl:choose>
				<!--/small-->
			</xsl:if>
		</xsl:if>
		<!--Party VAT registration: -->
		<xsl:if test="cac:Party/cac:PartyTaxScheme">
			<!--small-->
			<xsl:for-each select="cac:Party/cac:PartyTaxScheme">
				<br/>
				<xsl:choose>
					<xsl:when test="cac:TaxScheme/cbc:ID = 'VAT'">
						<b><xsl:value-of select="fcn:LabelName('BT-31', 'true')"/></b>
						<xsl:if test="$debug='true'">
							<xsl:text>BT-31@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="cbc:CompanyID"/>
					</xsl:when>
					<xsl:otherwise>
						<b><xsl:value-of select="fcn:LabelName('BT-32', 'true')"/></b>
						<xsl:if test="$debug='true'">
							<xsl:text>BT-32@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="cbc:CompanyID"/> [<xsl:value-of select="cac:TaxScheme/cbc:ID"/>]
					</xsl:otherwise>
				</xsl:choose>
				<!--xsl:if test="cbc:ExemptionReason">
						<br/><xsl:apply-templates select="cbc:ExemptionReason"/>
					</xsl:if-->
			</xsl:for-each>
			<!--/small-->
		</xsl:if>
	</xsl:template>
	<xsl:template name="SellerPartyName">
		<xsl:if test="cac:Party/cbc:Name !=''">
			<xsl:apply-templates select="cbc:Name"/>
		</xsl:if>
	</xsl:template>
	<xsl:template name="SellerPostalAddress">
		<div>
			<!-- class="indent"-->
			<xsl:if test="cac:Party/cac:PostalAddress/cbc:StreetName !=''">
				<span class="UBLStreetName">
					<!-- xsl:value-of select="fcn:LabelName('BT-35', 'true')"/ -->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-35@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:StreetName"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="cac:Party/cac:PostalAddress/cbc:AdditionalStreetName !=''">
				<span class="UBLAdditionalStreetName">
					<!-- xsl:value-of select="fcn:LabelName('BT-36', 'true')"/ -->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-36@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:AdditionalStreetName"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="cac:Party/cac:PostalAddress/cac:AddressLine/cbc:Line !=''">
				<span class="UBLAdditionalStreetName">
					<!-- xsl:value-of select="fcn:LabelName('BT-162', 'true')"/ -->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-162@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:Party/cac:PostalAddress/cac:AddressLine/cbc:Line"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="cac:Party/cac:PostalAddress/cbc:PostalZone !='' or cac:Party/cac:PostalAddress/cbc:CityName !=''">
				<span class="UBLCityName">
					<xsl:choose>
						<xsl:when test="cac:Party/cac:PostalAddress/cbc:PostalZone !=''">
							<!-- xsl:value-of select="fcn:LabelName('BT-38', 'true')"/ -->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-38@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:PostalZone"/> 
							<!-- xsl:value-of select="fcn:LabelName('BT-37', 'true')"/ -->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-37@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:CityName"/>
						</xsl:when>
						<xsl:otherwise>
							<!-- xsl:value-of select="fcn:LabelName('BT-37', 'true')"/ -->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-37@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:CityName"/>
						</xsl:otherwise>
					</xsl:choose>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="cac:Party/cac:PostalAddress/cbc:CountrySubentity !='' or cac:Party/cac:PostalAddress/cac:Country !=''">
				<xsl:choose>
					<xsl:when test="cac:Party/cac:PostalAddress/cbc:CountrySubentity !='' and cac:Party/cac:PostalAddress/cac:Country !=''">
						<!-- xsl:value-of select="fcn:LabelName('BT-39', 'true')"/-->
						<xsl:if test="$debug='true'">
							<xsl:text>BT-39@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:CountrySubentity"/>, 
						<!-- xsl:value-of select="fcn:LabelName('BT-40', 'true')"/ -->
						<xsl:if test="$debug='true'">
							<xsl:text>BT-40@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="cac:Party/cac:PostalAddress/cac:Country"/>
						<br/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:if test="cac:Party/cac:PostalAddress/cbc:CountrySubentity !=''">
							<!-- xsl:value-of select="fcn:LabelName('BT-39', 'true')"/-->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-39@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:CountrySubentity"/>
						</xsl:if>
						<xsl:if test="cac:Party/cac:PostalAddress/cac:Country !=''">
							<!-- xsl:value-of select="fcn:LabelName('BT-40', 'true')"/ -->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-40@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="cac:Party/cac:PostalAddress/cac:Country/cbc:IdentificationCode"/>
						</xsl:if>
						<br/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:if>
		</div>
	</xsl:template>
	<xsl:template name="SellerContact">
		<div>
			<!-- class="indent"-->
			<xsl:if test="cac:AccountingSupplierParty/cac:Party/cac:Contact/cbc:Name !=''">
				<!--xsl:value-of select="fcn:LabelName('BT-41', 'true')"/-->
				<xsl:if test="$debug='true'">
					<xsl:text>BT-41@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cac:AccountingSupplierParty/cac:Party/cac:Contact/cbc:Name"/>
				<br/>
			</xsl:if>
			<xsl:if test="cac:AccountingSupplierParty/cac:Party/cac:Contact/cbc:Telephone !=''">
				<span class="UBLTelephone">
					<!--xsl:value-of select="fcn:LabelName('BT-42', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-42@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:AccountingSupplierParty/cac:Party/cac:Contact/cbc:Telephone"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="cac:AccountingSupplierParty/cac:Party/cac:Contact/cbc:Telefax !=''">
				<span class="UBLTelefax">
					<!--xsl:value-of select="fcn:LabelName('BT-22', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-22@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:AccountingSupplierParty/cac:Party/cac:Contact/cbc:Telefax"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="cac:AccountingSupplierParty/cac:Party/cac:Contact/cbc:ElectronicMail !=''">
				<span class="UBLElectronicMail">
					<!--xsl:value-of select="fcn:LabelName('BT-43', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-43@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:AccountingSupplierParty/cac:Party/cac:Contact/cbc:ElectronicMail"/>
				</span>
			</xsl:if>
		</div>
	</xsl:template>
	<!--BUYER PARTY STARTS HERE-->
	<xsl:template name="BuyerParty">
		<p style="margin-bottom: 0px;">
			<b>
				<!--xsl:value-of select="fcn:LabelName('BT-45', 'true')"/-->
				<xsl:choose>
					<xsl:when test="cac:Party/cac:PartyName">
						<xsl:if test="$debug='true'">
							<xsl:text>BT-45@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="cac:Party/cac:PartyName"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:if test="$debug='true'">
							<xsl:text>BT-44@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cbc:RegistrationName"/>
					</xsl:otherwise>
				</xsl:choose>
			</b>
			<br/>
			<b>
				<xsl:value-of select="fcn:LabelName('BG-8', 'false')"/>
			</b>
		</p>
		<xsl:call-template name="BuyerPostalAddress"/>
		<xsl:if test="cac:Party/cac:PartyIdentification/cbc:ID">
			<!--small-->
			<b><xsl:value-of select="fcn:LabelName('BT-46', 'true')"/></b>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-46@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="cac:Party/cac:PartyIdentification/cbc:ID"/>
			<xsl:if test="cac:Party/cac:PartyIdentification/cbc:ID/@schemeID !='' ">

						 [<xsl:apply-templates select="cac:Party/cac:PartyIdentification/cbc:ID/@schemeID"/>]

			</xsl:if>
			<!--/small-->
		</xsl:if>
		<!--Party legal registration: -->
		<xsl:if test="cac:Party/cac:PartyLegalEntity">
			<xsl:if test="cac:Party/cac:PartyLegalEntity/cbc:CompanyID">
				<br/>
				<!--small-->
				<b><xsl:value-of select="fcn:LabelName('BT-47', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-47@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cbc:CompanyID"/>
				<xsl:if test="cac:Party/cac:PartyLegalEntity/cbc:CompanyID/@schemeID !='' ">

						 [<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cbc:CompanyID/@schemeID"/>]

				</xsl:if>
				<!--/small-->
			</xsl:if>
			<xsl:if test="cac:Party/cac:PartyLegalEntity/cbc:RegistrationName !=''">
				<br/>
				<!--small-->
				<b><xsl:value-of select="fcn:LabelName('BT-44', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-44@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cbc:RegistrationName"/>
				<!--/small-->
			</xsl:if>
		</xsl:if>
		<!--Party VAT registration: -->
		<xsl:if test="cac:Party/cac:PartyTaxScheme">
			<!--small-->
			<xsl:if test="cac:Party/cac:PartyTaxScheme">
				<br/>
				<b><xsl:value-of select="fcn:LabelName('BT-48', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-48@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cac:Party/cac:PartyTaxScheme/cbc:CompanyID"/>
				<xsl:if test="cac:Party/cac:PartyTaxScheme/cbc:CompanyID/@schemeID !='' ">
						 [<xsl:apply-templates select="cac:Party/cac:PartyTaxScheme/cbc:CompanyID/@schemeID"/>]
				</xsl:if>
			</xsl:if>
			<!--xsl:if test="cac:Party/cac:PartyTaxScheme/cbc:ExemptionReason">
					<br/><xsl:apply-templates select="cac:Party/cac:PartyTaxScheme/cbc:ExemptionReason"/>
				</xsl:if-->
			<!--/small-->
		</xsl:if>
	</xsl:template>
	<xsl:template name="BuyerPartyName">
		<xsl:if test="cac:Party/cbc:Name !=''">
			<xsl:apply-templates select="cbc:Name"/>
		</xsl:if>
	</xsl:template>
	<xsl:template name="BuyerPostalAddress">
		<div>
			<!-- class="indent"-->
			<xsl:if test="cac:Party/cac:PostalAddress/cbc:StreetName !=''">
				<span class="UBLStreetName">
					<!--xsl:value-of select="fcn:LabelName('BT-50', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-50@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:StreetName"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="cac:Party/cac:PostalAddress/cbc:AdditionalStreetName !=''">
				<span class="UBLAdditionalStreetName">
					<!--xsl:value-of select="fcn:LabelName('BT-51', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-51@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:AdditionalStreetName"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="cac:Party/cac:PostalAddress/cac:AddressLine/cbc:Line !=''">
				<span class="UBLAdditionalStreetName">
					<!--xsl:value-of select="fcn:LabelName('BT-163', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-163@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:Party/cac:PostalAddress/cac:AddressLine/cbc:Line"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="cac:Party/cac:PostalAddress/cbc:PostalZone !='' or cac:Party/cac:PostalAddress/cbc:CityName !=''">
				<span class="UBLCityName">
					<xsl:choose>
						<xsl:when test="cac:Party/cac:PostalAddress/cbc:PostalZone !=''">
							<!--xsl:value-of select="fcn:LabelName('BT-53', 'true')"/-->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-53@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:PostalZone"/>  
							<!--xsl:value-of select="fcn:LabelName('BT-52', 'true')"/-->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-52@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:CityName"/>
							<br/>
						</xsl:when>
						<xsl:otherwise>
							<!--xsl:value-of select="fcn:LabelName('BT-52', 'true')"/-->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-52@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:CityName"/>
							<br/>
						</xsl:otherwise>
					</xsl:choose>
				</span>
			</xsl:if>
			<xsl:if test="cac:Party/cac:PostalAddress/cbc:CountrySubentity !='' or cac:Party/cac:PostalAddress/cac:Country !=''">
				<xsl:choose>
					<xsl:when test="cac:Party/cac:PostalAddress/cbc:CountrySubentity !='' and cac:Party/cac:PostalAddress/cac:Country !=''">
						<!--xsl:value-of select="fcn:LabelName('BT-54', 'true')"/-->
						<xsl:if test="$debug='true'">
							<xsl:text>BT-54@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:CountrySubentity"/>, 
						<!--xsl:value-of select="fcn:LabelName('BT-55', 'true')"/-->
						<xsl:if test="$debug='true'">
							<xsl:text>BT-55@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="cac:Party/cac:PostalAddress/cac:Country"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:if test="cac:Party/cac:PostalAddress/cbc:CountrySubentity !=''">
							<!--xsl:value-of select="fcn:LabelName('BT-54', 'true')"/-->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-54@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="cac:Party/cac:PostalAddress/cbc:CountrySubentity"/>
						</xsl:if>
						<xsl:if test="cac:Party/cac:PostalAddress/cac:Country !=''">
							<!--xsl:value-of select="fcn:LabelName('BT-55', 'true')"/-->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-55@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="cac:Party/cac:PostalAddress/cac:Country/cbc:IdentificationCode"/>
						</xsl:if>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:if>
		</div>
	</xsl:template>
	<xsl:template name="BuyerContact">
		<div>
			<!-- class="indent"-->
			<xsl:if test="cac:AccountingCustomerParty/cac:Party/cac:Contact/cbc:Name !=''">
				<!--xsl:value-of select="fcn:LabelName('BT-56', 'true')"/-->
				<xsl:if test="$debug='true'">
					<xsl:text>BT-56@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cac:AccountingCustomerParty/cac:Party/cac:Contact/cbc:Name"/>
				<br/>
			</xsl:if>
			<xsl:if test="cac:AccountingCustomerParty/cac:Party/cac:Contact/cbc:Telephone !=''">
				<span class="UBLTelephone">
					<!--xsl:value-of select="fcn:LabelName('BT-57', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-57@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:AccountingCustomerParty/cac:Party/cac:Contact/cbc:Telephone"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="cac:AccountingCustomerParty/cac:Party/cac:Contact/cbc:Telefax !=''">
				<span class="UBLTelefax">
					<!--xsl:value-of select="fcn:LabelName('BT-22', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-22@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:AccountingCustomerParty/cac:Party/cac:Contact/cbc:Telefax"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="cac:AccountingCustomerParty/cac:Party/cac:Contact/cbc:ElectronicMail !=''">
				<span class="UBLElectronicMail">
					<!--xsl:value-of select="fcn:LabelName('BT-58', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-58@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:AccountingCustomerParty/cac:Party/cac:Contact/cbc:ElectronicMail"/>
				</span>
				<br/>
			</xsl:if>
		</div>
	</xsl:template>
	<!-- PAYEE PARTY STARTS HERE-->
	<xsl:template name="PayeeParty">
		<!--xsl:value-of select="fcn:LabelName('BT-59', 'true')"/-->
		<xsl:if test="$debug='true'">
			<xsl:text>BT-59@ </xsl:text>
		</xsl:if>
		<b><xsl:apply-templates select="cac:PayeeParty/cac:PartyName"/></b>
		<xsl:if test="cac:PayeeParty/cac:PartyIdentification/cbc:ID">
			<br/>
			<!--small-->
			<b><xsl:value-of select="fcn:LabelName('BT-60', 'true')"/></b>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-60@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="cac:PayeeParty/cac:PartyIdentification/cbc:ID"/>
			<xsl:if test="cac:PayeeParty/cac:PartyIdentification/cbc:ID/@schemeID !='' ">
						 [<xsl:apply-templates select="cac:PayeeParty/cac:PartyIdentification/cbc:ID/@schemeID"/>]
			</xsl:if>
			<!--/small-->
		</xsl:if>
		<!--Party legal registration: -->
		<xsl:if test="cac:PayeeParty/cac:PartyLegalEntity">
			<xsl:if test="cac:PayeeParty/cac:PartyLegalEntity">
				<br/>
				<!--small-->
				<b><xsl:value-of select="fcn:LabelName('BT-61', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-61@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cac:PayeeParty/cac:PartyLegalEntity/cbc:CompanyID"/>
				<xsl:if test="cac:PayeeParty/cac:PartyLegalEntity/cbc:CompanyID/@schemeID !='' ">
						 [<xsl:apply-templates select="cac:PayeeParty/cac:PartyLegalEntity/cbc:CompanyID/@schemeID"/>]
				</xsl:if>
				<!--/small-->
			</xsl:if>
		</xsl:if>
		<!--Party VAT registration: -->
		<xsl:if test="cac:PayeeParty/cac:PartyTaxScheme">
			<!--small-->
			<xsl:if test="cac:PayeeParty/cac:PartyTaxScheme">
				<br/>
				<b><xsl:value-of select="fcn:LabelName('BT-63', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-63@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cac:PayeeParty/cac:PartyTaxScheme/cbc:CompanyID"/>
				<xsl:if test="cac:PayeeParty/cac:PartyTaxScheme/cbc:CompanyID/@schemeID !='' ">
						 [<xsl:apply-templates select="cac:PayeeParty/cac:PartyTaxScheme/cbc:CompanyID/@schemeID"/>]
				</xsl:if>
			</xsl:if>
			<!--/small-->
		</xsl:if>
	</xsl:template>
	<xsl:template name="PayeePartyName">
		<xsl:if test="cac:PayeeParty/cbc:Name !=''">
			<xsl:apply-templates select="cbc:Name"/>
		</xsl:if>
	</xsl:template>
	<xsl:template match="cac:PartyName">
		<xsl:if test="cbc:Name !=''">
			<xsl:apply-templates select="cbc:Name"/>
		</xsl:if>
	</xsl:template>
	<xsl:template match="cac:PostalAddress | cac:DeliveryAddress | cac:Address ">
		<xsl:if test="cbc:StreetName !=''">
			<br/>
			<span class="UBLStreetName">
				<xsl:apply-templates select="cbc:StreetName"/>
			</span>
		</xsl:if>
		<xsl:if test="cbc:AdditionalStreetName !=''">
			<br/>
			<span class="UBLAdditionalStreetName">
				<xsl:apply-templates select="cbc:AdditionalStreetName"/>
			</span>
		</xsl:if>
		<xsl:if test="cac:AddressLine/cbc:Line !=''">
			<br/>
			<span class="UBLAdditionalStreetName">
				<xsl:apply-templates select="cac:AddressLine/cbc:Line"/>
			</span>
		</xsl:if>
		<xsl:if test="cbc:PostalZone !='' or cbc:CityName !=''">
			<br/>
			<span class="UBLCityName">
				<xsl:choose>
					<xsl:when test="cbc:PostalZone !=''">
						<xsl:apply-templates select="cbc:PostalZone"/> 
						<xsl:apply-templates select="cbc:CityName"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:apply-templates select="cbc:CityName"/>
					</xsl:otherwise>
				</xsl:choose>
			</span>
		</xsl:if>
		<xsl:if test="cbc:CountrySubentity !='' or cac:Country !=''">
			<xsl:choose>
				<xsl:when test="cbc:CountrySubentity !='' and cac:Country !=''">
					<br/>
					<xsl:apply-templates select="cbc:CountrySubentity"/>,
					<xsl:apply-templates select="cac:Country"/>
					<br/>
				</xsl:when>
				<xsl:otherwise>
					<br/>
					<xsl:if test="cbc:CountrySubentity !=''">
						<xsl:apply-templates select="cbc:CountrySubentity"/>
					</xsl:if>
					<xsl:if test="cac:Country !=''">
						<xsl:apply-templates select="cac:Country/cbc:IdentificationCode"/>
					</xsl:if>
					<br/>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:if>
	</xsl:template>
	<xsl:template match="cac:Country">
		<span>
			<xsl:apply-templates select="cbc:IdentificationCode"/>
			<!-- Checking of listID (normally NOT a function of a stylesheet): -->
			<xsl:if test="cbc:IdentificationCode/@listID !=''">
				<xsl:if test="cbc:IdentificationCode/@listID !='ISO3166-1:Alpha2'">
					 <!--small-->
					<em>[<xsl:apply-templates select="cbc:IdentificationCode/@listID"/>
					 -invalid listID]</em>
					<!--/small-->
				</xsl:if>
			</xsl:if>
		</span>
	</xsl:template>
	<!--TaxRepresentativeParty Starts here:-->
	<xsl:template match="cac:TaxRepresentativeParty">
		<xsl:if test="cac:PartyName/cbc:Name !=''">
			<xsl:if test="$debug='true'">
				<xsl:text>BT-62@ </xsl:text>
			</xsl:if>
			<b><xsl:value-of select="cac:PartyName/cbc:Name"/></b>
			<br/>
		</xsl:if>
		<xsl:if test="cac:PostalAddress">
			<p style="margin-bottom: 0px;">
				<b>
					<xsl:value-of select="fcn:LabelName('BG-12', 'false')"/>
				</b>
			</p>
		</xsl:if>
		<xsl:if test="cac:PostalAddress/cbc:StreetName !=''">
			<xsl:if test="$debug='true'">
				<xsl:text>BT-64@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="cac:PostalAddress/cbc:StreetName"/>
			<br/>
		</xsl:if>
		<xsl:if test="cac:PostalAddress/cbc:AdditionalStreetName !=''">
			<xsl:if test="$debug='true'">
				<xsl:text>BT-65@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="cac:PostalAddress/cbc:AdditionalStreetName"/>
			<br/>
		</xsl:if>
		<xsl:if test="cac:PostalAddress/cac:AddressLine/cbc:Line !=''">
			<xsl:if test="$debug='true'">
				<xsl:text>BT-164@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="cac:PostalAddress/cac:AddressLine/cbc:Line"/>
			<br/>
		</xsl:if>
		<xsl:if test="cac:PostalAddress/cbc:PostalZone !='' or cac:PostalAddress/cbc:CityName !=''">
			<xsl:choose>
				<xsl:when test="cac:PostalAddress/cbc:PostalZone !=''">
					<xsl:if test="$debug='true'">
						<xsl:text>BT-67@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:PostalAddress/cbc:PostalZone"/> 
					<xsl:if test="$debug='true'">
						<xsl:text>BT-66@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:PostalAddress/cbc:CityName"/>
					<br/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-66@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:PostalAddress/cbc:CityName"/>
					<br/>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:if>
		<xsl:if test="cac:PostalAddress/cbc:CountrySubentity !='' or cac:PostalAddress/cac:Country !=''">
			<xsl:choose>
				<xsl:when test="cac:PostalAddress/cbc:CountrySubentity !='' and cac:PostalAddress/cac:Country !=''">
					<xsl:if test="$debug='true'">
						<xsl:text>BT-68@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:PostalAddress/cbc:CountrySubentity"/>,
					<xsl:if test="$debug='true'">
						<xsl:text>BT-69@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:PostalAddress/cac:Country"/>
					<br/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:if test="cac:PostalAddress/cbc:CountrySubentity !=''">
						<xsl:if test="$debug='true'">
							<xsl:text>BT-68@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="cac:PostalAddress/cbc:CountrySubentity"/>
						<br/>
					</xsl:if>
					<xsl:if test="cac:PostalAddress/cac:Country !=''">
						<xsl:if test="$debug='true'">
							<xsl:text>BT-69@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="cac:PostalAddress/cac:Country/cbc:IdentificationCode"/>
						<br/>
					</xsl:if>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:if>
		<xsl:if test="cac:PartyTaxScheme/cbc:CompanyID !=''">
			<!--small-->
			<b><xsl:value-of select="fcn:LabelName('BT-63', 'true')"/></b>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-63@ </xsl:text>
			</xsl:if>
			<xsl:value-of select="cac:PartyTaxScheme/cbc:CompanyID"/>
			<!--/small-->
		</xsl:if>
	</xsl:template>
	<!--Delivery templates start: -->
	<xsl:template match="cac:Delivery" mode="DocumentHeader">
		<p>
			<xsl:if test="cac:DeliveryLocation !=''">
				<h3>
					<xsl:value-of select="fcn:LabelName('BG-13', 'false')"/>
				</h3>
				<xsl:if test="cac:DeliveryParty/cac:PartyName/cbc:Name != ''">
					<xsl:if test="$debug='true'">
						<xsl:text>BT-70@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:DeliveryParty/cac:PartyName/cbc:Name"/>
					<br/>
				</xsl:if>
				<xsl:apply-templates select="cac:DeliveryLocation"/>
			</xsl:if>
		</p>
	</xsl:template>
	<xsl:template match="cac:DeliveryLocation">
		<xsl:if test="cbc:ID !=''">
			<xsl:value-of select="fcn:LabelName('BT-71', 'true')"/>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-71@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="cbc:ID"/>
			<xsl:choose>
				<xsl:when test="cbc:ID/@schemeID !=''">
							 [<xsl:apply-templates select="cbc:ID/@schemeID"/>]
				</xsl:when>
				<xsl:otherwise>
							 [No schemeID]
				</xsl:otherwise>
			</xsl:choose>
		</xsl:if>
		<xsl:if test="cac:Address !=''">
			<br/>
			<xsl:call-template name="DeliveryAddress"/>
		</xsl:if>
	</xsl:template>
	<xsl:template name="DeliveryAddress">
		<b>
			<xsl:value-of select="fcn:LabelName('BG-15', 'false')"/>
		</b>
		<xsl:if test="cac:Address/cbc:StreetName !=''">
			<span class="UBLStreetName">
				<br/>
				<!--xsl:value-of select="fcn:LabelName('BT-75', 'true')"/-->
				<xsl:if test="$debug='true'"><xsl:text>BT-75@ </xsl:text></xsl:if>
				<xsl:apply-templates select="cac:Address/cbc:StreetName"/>
			</span>
		</xsl:if>
		<xsl:if test="cac:Address/cbc:AdditionalStreetName !=''">
			<span class="UBLAdditionalStreetName">
				<br/>
				<!-- xsl:value-of select="fcn:LabelName('BT-76', 'true')"/-->
				<xsl:if test="$debug='true'"><xsl:text>BT-76@ </xsl:text></xsl:if>
				<xsl:apply-templates select="cac:Address/cbc:AdditionalStreetName"/>
			</span>
		</xsl:if>
		<xsl:if test="cac:Address/cac:AddressLine/cbc:Line !=''">
			<span class="UBLAdditionalStreetName">
				<br/>
				<!--xsl:value-of select="fcn:LabelName('BT-165', 'true')"/-->
				<xsl:if test="$debug='true'"><xsl:text>BT-165@ </xsl:text></xsl:if>
				<xsl:apply-templates select="cac:Address/cac:AddressLine/cbc:Line"/>
			</span>
		</xsl:if>
		<xsl:if test="cac:Address/cbc:PostalZone !='' or cac:Address/cbc:CityName !=''">
			<br/>
			<span class="UBLCityName">
				<xsl:choose>
					<xsl:when test="cac:Address/cbc:PostalZone !=''">
						<!--xsl:value-of select="fcn:LabelName('BT-78', 'true')"/-->
						<xsl:if test="$debug='true'"><xsl:text>BT-78@ </xsl:text></xsl:if>
						<xsl:apply-templates select="cac:Address/cbc:PostalZone"/> 
						<!--xsl:value-of select="fcn:LabelName('BT-77', 'true')"/-->
						<xsl:if test="$debug='true'"><xsl:text>BT-77@ </xsl:text></xsl:if>
						<xsl:apply-templates select="cac:Address/cbc:CityName"/>
					</xsl:when>
					<xsl:otherwise>
						<!--xsl:value-of select="fcn:LabelName('BT-77', 'true')"/-->
						<xsl:if test="$debug='true'"><xsl:text>BT-77@ </xsl:text></xsl:if>
						<xsl:apply-templates select="cac:Address/cbc:CityName"/>
					</xsl:otherwise>
				</xsl:choose>
			</span>
		</xsl:if>
		<xsl:if test="cac:Address/cbc:CountrySubentity !='' or cac:Address/cac:Country !=''">
			<xsl:choose>
				<xsl:when test="cac:Address/cbc:CountrySubentity !='' and cac:Address/cac:Country !=''">
					<br/>
					<!--xsl:value-of select="fcn:LabelName('BT-79', 'true')"/-->
					<xsl:if test="$debug='true'"><xsl:text>BT-79@ </xsl:text></xsl:if>
					<xsl:apply-templates select="cac:Address/cbc:CountrySubentity"/>,

					<!--xsl:value-of select="fcn:LabelName('BT-80', 'true')"/-->
					<xsl:if test="$debug='true'"><xsl:text>BT-80@ </xsl:text></xsl:if>
					<xsl:apply-templates select="cac:Address/cac:Country"/>
				</xsl:when>
				<xsl:otherwise>
					<br/>
					<xsl:if test="cac:Address/cbc:CountrySubentity !=''">
						<!--xsl:value-of select="fcn:LabelName('BT-79', 'true')"/-->
						<xsl:if test="$debug='true'"><xsl:text>BT-79@ </xsl:text></xsl:if>
						<xsl:apply-templates select="cac:Address/cbc:CountrySubentity"/>
					</xsl:if>
					<xsl:if test="cac:Address/cac:Country !=''">
						<!--xsl:value-of select="fcn:LabelName('BT-80', 'true')"/-->
						<xsl:if test="$debug='true'"><xsl:text>BT-80@ </xsl:text></xsl:if>
						<xsl:apply-templates select="cac:Address/cac:Country/cbc:IdentificationCode"/>
					</xsl:if>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:if>
	</xsl:template>
	<!--Contact from here: -->
	<xsl:template match="cac:AccountingSupplierParty/cac:Party" mode="accsupcontact">
		<xsl:apply-templates select="cac:Contact"/>
	</xsl:template>
	<xsl:template match="cac:AccountingCustomerParty/cac:Party" mode="acccuscontact">
		<xsl:apply-templates select="cac:Contact"/>
	</xsl:template>
	<!--Invoiceline start: -->
	<xsl:template match="cac:InvoiceLine | cac:CreditNoteLine">
		<tr>
			<td>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-126@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cbc:ID"/>
			</td>
			<td>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-155@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cac:Item/cac:SellersItemIdentification"/>
			</td>
			<td>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-153@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="cac:Item/cbc:Name"/>
				<br/>
				<br/>
				<!--small-->
				<xsl:if test="cac:Item/cac:StandardItemIdentification/cbc:ID !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-157', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-157@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:Item/cac:StandardItemIdentification/cbc:ID"/>
					<xsl:choose>
						<xsl:when test="cac:Item/cac:StandardItemIdentification/cbc:ID/@schemeID !=''">
							<!--small--> [<xsl:if test="$debug='true'">
								<xsl:text>BT-157-1@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="cac:Item/cac:StandardItemIdentification/cbc:ID/@schemeID"/>]<!--/small-->
						</xsl:when>
						<xsl:otherwise>
							<!--small--> [No schemeID]<!--/small-->
						</xsl:otherwise>
					</xsl:choose>
					<br/>
				</xsl:if>
				<xsl:if test="cac:Item/cbc:Description !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-154', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-154@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:Item/cbc:Description"/>
					<br/>
				</xsl:if>
				<xsl:if test="cac:Item/cac:AdditionalItemProperty !=''">
					<xsl:if test="$debug='true'">
						<xsl:text>BT-160@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:Item/cac:AdditionalItemProperty"/>
				</xsl:if>
				<xsl:if test="cbc:Note !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-127', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-127@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cbc:Note"/>
					<br/>
				</xsl:if>
				<xsl:if test="cac:Item/cac:CommodityClassification !=''">
					<xsl:apply-templates select="cac:Item/cac:CommodityClassification"/>
				</xsl:if>
				<xsl:if test="cac:Item/cac:BuyersItemIdentification/cbc:ID != ''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-156', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-156@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:Item/cac:BuyersItemIdentification/cbc:ID"/>
					<br/>
				</xsl:if>
				<xsl:if test="cbc:AccountingCost !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-19', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-19@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cbc:AccountingCost"/>
					<br/>
				</xsl:if>
				<xsl:if test="cac:InvoicePeriod !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BG-14', 'true')"/>
					</b>
					<xsl:apply-templates select="cac:InvoicePeriod"/>
					<br/>
				</xsl:if>
				<xsl:if test="cac:Price/cac:AllowanceCharge !=''">
					<xsl:apply-templates select="cac:Price/cac:AllowanceCharge" mode="PriceUnit-new"/>
				</xsl:if>
				<xsl:if test="cac:Item/cac:OriginCountry/cbc:IdentificationCode !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-159', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-159@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:Item/cac:OriginCountry/cbc:IdentificationCode"/>
					<xsl:if test="cac:Item/cac:OriginCountry/cbc:IdentificationCode/@listID !=''">
						<!--small--> [<xsl:apply-templates select="cac:Item/cac:OriginCountry/cbc:IdentificationCode/@listID"/>]<!--/small-->
					</xsl:if>
					<br/>
				</xsl:if>
				<xsl:if test="cac:OrderLineReference/cbc:LineID !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-132', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-132@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:OrderLineReference/cbc:LineID"/>
					<br/>
				</xsl:if>
				<xsl:if test="cac:DocumentReference/cbc:ID !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-128', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-128@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:DocumentReference/cbc:ID"/> [<xsl:apply-templates select="cac:DocumentReference/cbc:ID/@schemeID"/>]
					<br/>
				</xsl:if>
				<!--/small-->
			</td>
			<td align="left">
				<xsl:if test="cbc:InvoicedQuantity !=''">
					<xsl:if test="$debug='true'">
						<xsl:text>BT-129@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cbc:InvoicedQuantity"/> 
					<xsl:if test="cbc:InvoicedQuantity/@unitCode !=''">
						<xsl:if test="$debug='true'">
							<xsl:text>BT-130@ </xsl:text>
						</xsl:if>
						<xsl:value-of select="cbc:InvoicedQuantity/@unitCode"/>
						<br/>
						<!--small>(<xsl:value-of select="fcn:LabelName('BT-130', 'true')"/><xsl:value-of select="fcn:UNECECode(cbc:InvoicedQuantity/@unitCode)"/>)</small-->
					</xsl:if>
				</xsl:if>
				<xsl:if test="cbc:CreditedQuantity !=''">
					<xsl:apply-templates select="cbc:CreditedQuantity"/> 
					<xsl:if test="cbc:CreditedQuantity/@unitCode !=''">
						<xsl:value-of select="cbc:CreditedQuantity/@unitCode"/>
						<!--br/ -->
						<!--small>(<xsl:value-of select="fcn:LabelName('BT-130', 'true')"/><xsl:value-of select="fcn:UNECECode(cbc:CreditedQuantity/@unitCode)"/>)</small-->
					</xsl:if>
				</xsl:if>
			</td>
			<td>
				<xsl:apply-templates select="cac:Price"/>
				<xsl:if test="cac:Price/cbc:BaseQuantity">
					<!--small-->
					<br/>
					<b>
						<xsl:value-of select="fcn:LabelName('BT-149', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-149@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:Price/cbc:BaseQuantity"/>
					<!--/small-->
				</xsl:if>
			</td>
			<td>
				<xsl:if test="cac:Item/cac:ClassifiedTaxCategory !='' ">
					<xsl:choose>
						<xsl:when test="cac:Item/cac:ClassifiedTaxCategory/cbc:Percent !=''">
							<xsl:if test="$debug='true'">
								<xsl:text>BT-151@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="cac:Item/cac:ClassifiedTaxCategory/cbc:ID"/>, 

							<xsl:if test="$debug='true'">
								<xsl:text>BT-152@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="fcn:Currency(cac:Item/cac:ClassifiedTaxCategory/cbc:Percent)"/>%

						</xsl:when>
						<xsl:otherwise>
							<xsl:apply-templates select="cac:Item/cac:ClassifiedTaxCategory/cac:TaxScheme/cbc:ID"/>: 
							<xsl:apply-templates select="cac:Item/cac:ClassifiedTaxCategory/cbc:ID"/>
						</xsl:otherwise>
					</xsl:choose>
				</xsl:if>
				<xsl:if test="cac:TaxTotal/cbc:TaxAmount">
					<!--small-->
					<xsl:choose>
						<xsl:when test="cac:Item/cac:ClassifiedTaxCategory/cbc:Percent !=''">
							<br/>(<xsl:if test="$debug='true'">
								<xsl:text>BT-110@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="fcn:Currency(cac:TaxTotal/cbc:TaxAmount)"/>)
						</xsl:when>
						<xsl:otherwise>
							(<xsl:if test="$debug='true'">
								<xsl:text>BT-110@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="fcn:Currency(cac:TaxTotal/cbc:TaxAmount)"/>)
						</xsl:otherwise>
					</xsl:choose>
					<!--/small-->
				</xsl:if>
			</td>
			<td>
				<xsl:if test="cac:AllowanceCharge !=''">
					<xsl:apply-templates select="cac:AllowanceCharge" mode="LineLevel-new"/>
				</xsl:if>
			</td>
			<td align="right">
				<xsl:if test="$debug='true'">
					<xsl:text>BT-131@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="fcn:Currency(cbc:LineExtensionAmount)"/> <xsl:apply-templates select="cbc:LineExtensionAmount/@currencyID"/>
			</td>
		</tr>
		<!-- Invoice line/part 3: -->
		<xsl:if test="cac:Delivery !=''">
			<tr>
				<td>
				</td>
				<td>
				</td>
				<td class="UBLName">
					<table border="0" width="90%" cellspacing="0" cellpadding="2">
						<xsl:apply-templates select="cac:Delivery" mode="line-new"/>
					</table>
				</td>
			</tr>
		</xsl:if>
	</xsl:template>
	<xsl:template match="cac:CommodityClassification">
		<xsl:if test="cbc:CommodityCode !=''">
			<b>
				<xsl:value-of select="fcn:LabelName('BT-158', 'true')"/>
			</b>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-158@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="cbc:CommodityCode"/>
			<xsl:choose>
				<xsl:when test="cbc:CommodityCode/@listID !=''">
					<!--small--> [<xsl:value-of select="fcn:UBLClassificationCode(cbc:CommodityCode/@listID)"/>]<!--/small-->
				</xsl:when>
				<xsl:otherwise>
					<!--small--> [No listID]<!--/small-->
				</xsl:otherwise>
			</xsl:choose>
			<xsl:if test="cbc:CommodityCode/@listVersionID !=''">
				 [<xsl:apply-templates select="cbc:CommodityCode/@listVersionID"/>]
			</xsl:if>
			<br/>
		</xsl:if>
		<xsl:if test="cbc:ItemClassificationCode !=''">
			<b>
				<xsl:value-of select="fcn:LabelName('BT-158', 'true')"/>
			</b>
			<xsl:apply-templates select="cbc:ItemClassificationCode"/>
			<xsl:choose>
				<xsl:when test="cbc:ItemClassificationCode/@listID !=''">
					<!--small--> [<xsl:value-of select="fcn:UBLClassificationCode(cbc:ItemClassificationCode/@listID)"/>]<!--/small-->
				</xsl:when>
				<xsl:otherwise>
					<!--small--> [No listID]<!--/small-->
				</xsl:otherwise>
			</xsl:choose>
			<xsl:if test="cbc:ItemClassificationCode/@listVersionID !=''">
				 [<xsl:apply-templates select="cbc:ItemClassificationCode/@listVersionID"/>]
			</xsl:if>
			<br/>
		</xsl:if>
	</xsl:template>
	<xsl:template match="cac:AdditionalItemProperty">
		<b>
			<xsl:value-of select="fcn:LabelName('BT-160', 'true')"/>
		</b>
		<xsl:apply-templates select="cbc:Name"/> = 
		<xsl:apply-templates select="cbc:Value"/>
		<xsl:if test="$debug='true'">
			<xsl:text> BT-161@</xsl:text>
		</xsl:if>
		<br/>
	</xsl:template>
	<xsl:template match="cac:SellersItemIdentification">
		<xsl:apply-templates select="cbc:ID"/>
	</xsl:template>
	<xsl:template match="cac:Price">
		<xsl:if test="$debug='true'">
			<xsl:text> BT-146@</xsl:text>
		</xsl:if>
		<xsl:apply-templates select="fcn:Currency(cbc:PriceAmount)"/> <xsl:apply-templates select="cbc:PriceAmount/@currencyID"/>
	</xsl:template>
	<!--Invoiceline end-->
	<!-- Document legal totals from here-->
	<!-- Document legal totals until here-->
	<!--Allowance/Charge from here-->
	<!-- 1) A/C on document level -->
	<xsl:template match="cac:AllowanceCharge" mode="DocumentLevel-new">
		<tr>
			<td valign="top" colspan="2">
				<xsl:choose>
					<xsl:when test="cbc:ChargeIndicator ='true'">
						<xsl:value-of select="fcn:LabelName('BG-21', 'true')"/>
					</xsl:when>
					<xsl:when test="cbc:ChargeIndicator ='false'">
						<xsl:value-of select="fcn:LabelName('BG-20', 'true')"/>
					</xsl:when>
					<xsl:otherwise/>
				</xsl:choose>
			</td>
			<td valign="top" colspan="2">
				<xsl:if test="cbc:AllowanceChargeReasonCode !=''">
					<xsl:apply-templates select="cbc:AllowanceChargeReasonCode"/>
				</xsl:if>
			</td>
			<td valign="top" colspan="2">
				<xsl:apply-templates select="cbc:AllowanceChargeReason"/>
			</td>
			<td>
				<xsl:if test="cac:TaxCategory !='' ">
					<xsl:choose>
						<xsl:when test="cac:TaxCategory/cbc:Percent !=''">
							<xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/>: 

							<xsl:apply-templates select="cac:TaxCategory/cbc:ID"/>,
							<xsl:if test="$debug='true'"><xsl:text> BT-103@</xsl:text></xsl:if>
							 <xsl:apply-templates select="fcn:Currency(cac:TaxCategory/cbc:Percent)"/>%

						</xsl:when>
						<xsl:otherwise>
							<xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/>: 

							<xsl:apply-templates select="cac:TaxCategory/cbc:ID"/>
						</xsl:otherwise>
					</xsl:choose>
				</xsl:if>
			</td>
			<td valign="top" align="right">
				<xsl:apply-templates select="fcn:Currency(cbc:Amount)"/>
			</td>
		</tr>
	</xsl:template>
	<xsl:template name="Allowance">
		<tr>
			<td valign="top" colspan="2">
				<xsl:if test="$debug='true'"><xsl:text> BT-98@ </xsl:text></xsl:if>
				<xsl:apply-templates select="cbc:AllowanceChargeReasonCode"/>
				<!--xsl:value-of select="fcn:AllowanceReasonCode(cbc:AllowanceChargeReasonCode)"/-->
			</td>
			<td valign="top" colspan="2">
				<xsl:if test="$debug='true'"><xsl:text> BT-97@ </xsl:text></xsl:if>
				<xsl:apply-templates select="cbc:AllowanceChargeReason"/>
			</td>
			<td>
				<xsl:if test="cac:TaxCategory !='' ">
					<xsl:choose>
						<xsl:when test="cac:TaxCategory/cbc:Percent !=''">
							<xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/>: 
							<xsl:if test="$debug='true'"><xsl:text>BT-95@ </xsl:text></xsl:if>
							<xsl:apply-templates select="cac:TaxCategory/cbc:ID"/>,
							<xsl:if test="$debug='true'"><xsl:text>BT-103@ </xsl:text></xsl:if>
							<xsl:apply-templates select="fcn:Currency(cac:TaxCategory/cbc:Percent)"/>%

						</xsl:when>
						<xsl:otherwise>
							<xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/>: 
							<xsl:if test="$debug='true'"><xsl:text>BT-95@ </xsl:text></xsl:if>
							<xsl:apply-templates select="cac:TaxCategory/cbc:ID"/>
						</xsl:otherwise>
					</xsl:choose>
				</xsl:if>
			</td>
			<td valign="top" align="right">
				<xsl:if test="cbc:MultiplierFactorNumeric != ''">
					<xsl:if test="$debug='true'"><xsl:text>BT-101@ </xsl:text></xsl:if>
					<xsl:apply-templates select="fcn:Currency(cbc:MultiplierFactorNumeric)"/>%&#160;<xsl:value-of select="fcn:LabelName('UT-4', 'false')"/>&#160;
				</xsl:if>
				<xsl:if test="$debug='true'"><xsl:text>BT-100@ </xsl:text></xsl:if>
				<xsl:apply-templates select="fcn:Currency(cbc:BaseAmount)"/>&#160;<xsl:apply-templates select="cbc:BaseAmount/@currencyID"/>
			</td>
			<td valign="top" align="right">
				<xsl:if test="$debug='true'"><xsl:text>BT-99@ </xsl:text></xsl:if>
				<xsl:apply-templates select="fcn:Currency(cbc:Amount)"/>&#160;<xsl:apply-templates select="cbc:Amount/@currencyID"/>
			</td>
		</tr>
	</xsl:template>
	<xsl:template name="Charge">
		<tr>
			<td valign="top" colspan="2">
				<xsl:if test="$debug='true'"><xsl:text>BT-140@ </xsl:text></xsl:if>
				<xsl:apply-templates select="cbc:AllowanceChargeReasonCode"/>
			</td>
			<td valign="top" colspan="2">
				<xsl:if test="$debug='true'"><xsl:text>BT-139@ </xsl:text></xsl:if>
				<xsl:apply-templates select="cbc:AllowanceChargeReason"/>
			</td>
			<td>
				<xsl:if test="cac:TaxCategory!=''">
					<xsl:choose>
						<xsl:when test="cac:TaxCategory/cbc:Percent !=''">
							<xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/>: 
							<xsl:if test="$debug='true'"><xsl:text>BT-118@ </xsl:text></xsl:if>
							<xsl:apply-templates select="cac:TaxCategory/cbc:ID"/>,
							<xsl:if test="$debug='true'"><xsl:text>BT-119@ </xsl:text></xsl:if>
							<xsl:apply-templates select="fcn:Currency(cac:TaxCategory/cbc:Percent)"/>%

						</xsl:when>
						<xsl:otherwise>
							<xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/>: 
							<xsl:if test="$debug='true'"><xsl:text>BT-118@ </xsl:text></xsl:if>
							<xsl:apply-templates select="cac:TaxCategory/cbc:ID"/>
						</xsl:otherwise>
					</xsl:choose>
				</xsl:if>
			</td>
			<td valign="top" align="right">
				<xsl:if test="cbc:MultiplierFactorNumeric != ''">
					<xsl:if test="$debug='true'"><xsl:text>BT-101@ </xsl:text></xsl:if>
					<xsl:apply-templates select="fcn:Currency(cbc:MultiplierFactorNumeric)"/>%&#160;<xsl:value-of select="fcn:LabelName('UT-4', 'false')"/>&#160;
				</xsl:if>
				<xsl:if test="$debug='true'"><xsl:text>BT-100@ </xsl:text></xsl:if>
				<xsl:apply-templates select="fcn:Currency(cbc:BaseAmount)"/>&#160;<xsl:apply-templates select="cbc:BaseAmount/@currencyID"/>
			</td>
			<td valign="top" align="right">
				<xsl:if test="$debug='true'"><xsl:text>BT-99@ </xsl:text></xsl:if>
				<xsl:apply-templates select="fcn:Currency(cbc:Amount)"/>&#160;<xsl:apply-templates select="cbc:Amount/@currencyID"/>
			</td>
		</tr>
	</xsl:template>
	<!-- 2) A/C on line level -->
	<xsl:template match="cac:AllowanceCharge" mode="LineLevel-new">
		<xsl:choose>
			<xsl:when test="cbc:ChargeIndicator ='true'">
				<xsl:value-of select="fcn:LabelName('BG-28', 'true')"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="fcn:LabelName('BG-27', 'true')"/>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:if test="$debug='true'"><xsl:text>BT-141@ </xsl:text></xsl:if>
		<xsl:apply-templates select="fcn:Currency(cbc:Amount)"/>
		<!--small-->
		<br/>
		<xsl:if test="$debug='true'"><xsl:text>BT-144@ </xsl:text></xsl:if>
		<xsl:apply-templates select="cbc:AllowanceChargeReason"/> (<xsl:if test="$debug='true'"><xsl:text>BT-145@ </xsl:text></xsl:if>
		<xsl:apply-templates select="cbc:AllowanceChargeReasonCode"/>) 
		<xsl:if test="$debug='true'"><xsl:text>BT-143@ </xsl:text></xsl:if>
		<xsl:apply-templates select="fcn:Currency(cbc:MultiplierFactorNumeric)"/>%
		<br/>

		<!--/small-->

	</xsl:template>
	<!-- 3) A/C on price unit level (for information only) -->
	<xsl:template match="cac:AllowanceCharge" mode="PriceUnit-new">
		<b>
			<xsl:choose>
				<xsl:when test="cbc:ChargeIndicator ='true'">
					<xsl:value-of select="fcn:LabelName('BT-147', 'true')"/>
				</xsl:when>
				<xsl:when test="cbc:ChargeIndicator ='false'">
					<xsl:value-of select="fcn:LabelName('BT-147', 'true')"/>
				</xsl:when>
			</xsl:choose>
		</b>
		<xsl:choose>
			<xsl:when test="cbc:BaseAmount !='' ">
				<xsl:if test="$debug='true'"><xsl:text>BT-147@ </xsl:text></xsl:if>
				<xsl:apply-templates select="fcn:Currency(cbc:Amount)"/>&#160;<xsl:apply-templates select="cbc:Amount/@currencyID"/>
				<br/>
				<b>
					<xsl:value-of select="fcn:LabelName('BT-148', 'true')"/>
				</b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-148@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="fcn:Currency(cbc:BaseAmount)"/>&#160;<xsl:apply-templates select="cbc:BaseAmount/@currencyID"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-147@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="fcn:Currency(cbc:Amount)"/>&#160;<xsl:apply-templates select="cbc:Amount/@currencyID"/>
			</xsl:otherwise>
		</xsl:choose>
		<br/>
	</xsl:template>
	<!-- AllowanceCharge end -->
	<!-- Tax (VAT) totals from here: -->
	<xsl:template match="cac:TaxTotal/cac:TaxSubtotal">
		<tr class="TAXInformation">
			<td colspan="2">
				<xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/>
				: 	<xsl:if test="$debug='true'"><xsl:text>BT-118@ </xsl:text></xsl:if><xsl:apply-templates select="cac:TaxCategory/cbc:ID"/> 
				<!--small-->(<xsl:value-of select="fcn:UBLTaxCategoryCode(cac:TaxCategory/cbc:ID)"/>),<!--/small-->
				<xsl:choose>
					<xsl:when test="cac:TaxCategory/cbc:Percent !=''">
						 <xsl:if test="$debug='true'"><xsl:text>BT-119@ </xsl:text></xsl:if><xsl:apply-templates select="fcn:Currency(cac:TaxCategory/cbc:Percent)"/>%
					</xsl:when>
					<xsl:otherwise>
						%
					</xsl:otherwise>
				</xsl:choose>
			</td>
			<td colspan="2">
				<xsl:if test="cac:TaxCategory/cbc:TaxExemptionReason !=''">
					<xsl:if test="$debug='true'">
						<xsl:text>BT-120@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="cac:TaxCategory/cbc:TaxExemptionReason"/>
					<xsl:if test="cac:TaxCategory/cbc:TaxExemptionReasonCode !=''">
						<xsl:if test="$debug='true'">
							<xsl:text>BT-121@ </xsl:text>
						</xsl:if> [<xsl:apply-templates select="cac:TaxCategory/cbc:TaxExemptionReasonCode"/>] </xsl:if>
				</xsl:if>
			</td>
			<td colspan="2">
				<xsl:if test="$debug='true'"><xsl:text>BT-116@ </xsl:text></xsl:if>
				<xsl:apply-templates select="fcn:Currency(cbc:TaxableAmount)"/> <xsl:apply-templates select="cbc:TaxableAmount/@currencyID"/>
			</td>
			<td align="right">
				<xsl:if test="$debug='true'"><xsl:text>BT-117@ </xsl:text></xsl:if>
				<xsl:apply-templates select="fcn:Currency(cbc:TaxAmount)"/> <xsl:apply-templates select="cbc:TaxableAmount/@currencyID"/>
			</td>
		</tr>
	</xsl:template>
	<!--TaxTotal until here-->
	<!--PaymentMeans from here-->
	<xsl:template name="cac:PaymentMeans">
		<tr>
			<td valign="top">
				<xsl:if test="$debug='true'"><xsl:text>BT-81@ </xsl:text></xsl:if>
				<xsl:apply-templates select="cbc:PaymentMeansCode"/>
				<smaller> (<xsl:choose>
						<xsl:when test="cbc:PaymentMeansCode/@name != ''">
							<xsl:if test="$debug='true'"><xsl:text>BT-82@ </xsl:text></xsl:if>
							<xsl:apply-templates select="cbc:PaymentMeansCode/@name"/>
						</xsl:when>
						<xsl:otherwise>
							<xsl:if test="$debug='true'"><xsl:text>BT-81@ </xsl:text></xsl:if>
							<xsl:value-of select="fcn:PaymentMeansCode(cbc:PaymentMeansCode)"/>
						</xsl:otherwise>
					</xsl:choose>) 
				</smaller>
			</td>
			<td valign="top" colspan="2">
				<xsl:if test="cac:CardAccount/cbc:PrimaryAccountNumberID !='' or cac:CardAccount/cbc:NetworkID !=''">
					<xsl:apply-templates select="cac:CardAccount/cbc:NetworkID"/>
				</xsl:if>
				<xsl:if test="cac:PayeeFinancialAccount/cac:FinancialInstitutionBranch/cac:FinancialInstitution/cbc:ID">
					<xsl:if test="cac:CardAccount/cbc:PrimaryAccountNumberID !='' or cac:CardAccount/cbc:NetworkID !=''">
						<br/>
					</xsl:if>
					<xsl:apply-templates select="cac:PayeeFinancialAccount/cac:FinancialInstitutionBranch/cac:FinancialInstitution/cbc:ID"/> 
				</xsl:if>
				<xsl:if test="cac:PayeeFinancialAccount/cac:FinancialInstitutionBranch/cbc:ID !='' ">
					<xsl:if test="$debug='true'"><xsl:text>BT-86@ </xsl:text></xsl:if>
					<xsl:apply-templates select="cac:PayeeFinancialAccount/cac:FinancialInstitutionBranch/cbc:ID"/> 
				</xsl:if>
				<xsl:if test="cac:PaymentMandate/cbc:ID !='' or cac:PaymentMandate/cac:PayerFinancialAccount !=''">
					<xsl:if test="$debug='true'"><xsl:text>BT-91@ </xsl:text></xsl:if>
					<xsl:apply-templates select="cac:PaymentMandate/cac:PayerFinancialAccount/cbc:ID"/>
				</xsl:if>
			</td>
			<td valign="top" colspan="2">
				<xsl:if test="cac:CardAccount/cbc:PrimaryAccountNumberID !='' or cac:CardAccount/cbc:NetworkID !=''">
					<xsl:if test="$debug='true'"><xsl:text>BT-87@ </xsl:text></xsl:if>
					***<xsl:apply-templates select="cac:CardAccount/cbc:PrimaryAccountNumberID"/> 
				</xsl:if>
				<xsl:if test="cac:PayeeFinancialAccount/cbc:ID !='' or         cac:PayeeFinancialAccount/cac:FinancialInstitutionBranch/cac:FinancialInstitution/cbc:ID !=''">
					<xsl:if test="cac:CardAccount/cbc:PrimaryAccountNumberID !='' or cac:CardAccount/cbc:NetworkID !=''">
						<br/>
					</xsl:if>
					<xsl:if test="$debug='true'"><xsl:text>BT-84@ </xsl:text></xsl:if>
					<xsl:apply-templates select="cac:PayeeFinancialAccount/cbc:ID"/> 

				</xsl:if>
				<xsl:if test="cac:PaymentMandate/cbc:ID !='' or cac:PaymentMandate/cac:PayerFinancialAccount !=''">
					<xsl:if test="$debug='true'"><xsl:text>BT-89@ </xsl:text></xsl:if>
					<xsl:apply-templates select="cac:PaymentMandate/cbc:ID"/>
				</xsl:if>
			</td>
			<xsl:if test="cac:PaymentMandate != ''">
				<td valign="top" colspan="2">
					<xsl:if test="../cac:AccountingSupplierParty/cac:Party/cac:PartyIdentification/cbc:ID/@schemeID = 'SEPA'">
						<xsl:if test="$debug='true'"><xsl:text>BT-90@ </xsl:text></xsl:if>
						<xsl:value-of select="../cac:AccountingSupplierParty/cac:Party/cac:PartyIdentification/cbc:ID"/>
					</xsl:if>
					<xsl:if test="../cac:PayeeParty/cac:PartyIdentification/cbc:ID/@schemeID = 'SEPA'">
						<xsl:if test="$debug='true'"><xsl:text>BT-90@ </xsl:text></xsl:if>
						<xsl:value-of select="../cac:PayeeParty/cac:PartyIdentification/cbc:ID"/>
					</xsl:if>
				</td>
			</xsl:if>
			<xsl:if test="cac:PayeeFinancialAccount !=''">
				<td valign="top" colspan="2">
					<xsl:if test="$debug='true'"><xsl:text>BT-85@ </xsl:text></xsl:if>
					<xsl:apply-templates select="cac:PayeeFinancialAccount/cbc:Name"/>
				</td>
			</xsl:if>
			<xsl:if test="not(cac:PaymentMandate) and not(cac:CardAccount) and not(cac:PayeeFinancialAccount)">
				<td valign="top" colspan="2">
				</td>
			</xsl:if>
			<xsl:if test="cac:CardAccount !=''">
				<td valign="top" colspan="2">
					<xsl:if test="$debug='true'"><xsl:text>BT-88@ </xsl:text></xsl:if>
					<xsl:apply-templates select="cac:CardAccount/cbc:HolderName"/>
				</td>
			</xsl:if>
			<td valign="top" align="right">
				<xsl:if test="cbc:PaymentID !=''">
					<xsl:if test="$debug='true'"><xsl:text>BT-83@ </xsl:text></xsl:if>
					<xsl:apply-templates select="cbc:PaymentID"/>
				</xsl:if>
			</td>
			<!--td valign="top" align="right">
			
			</td-->
		</tr>
	</xsl:template>
	<!--PaymentMeans template until here-->
	<!-- PaymentTerms from here: -->
	<xsl:template match="cac:PaymentTerms">
		<xsl:if test="cbc:Note !=''">
			<xsl:if test="$debug='true'">
				<xsl:text>BT-20@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="cbc:Note"/>
		</xsl:if>
	</xsl:template>
	<!-- Document references from here: -->
	<xsl:template match="cac:AdditionalDocumentReference" mode="InvoicedObject">
		<xsl:if test="cbc:DocumentTypeCode='130'">
			<br/>
			<b>
				<xsl:value-of select="fcn:LabelName('BT-18', 'true')"/>
			</b>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-18@ </xsl:text>
			</xsl:if>
			<xsl:value-of select="cbc:ID"/>
			<xsl:if test="cbc:ID/@schemeID != ''">
				<xsl:if test="$debug='true'">
					<xsl:text> BT-18-1@ </xsl:text>
				</xsl:if>
				<xsl:value-of select="fcn:SchemeIdentifierCode(cbc:ID/@schemeID)"/> [<xsl:value-of select="cbc:ID/@schemeID"/>]</xsl:if>
		</xsl:if>
		<xsl:if test="cbc:DocumentTypeCode='50'">
			<br/>
			<b>
				<xsl:value-of select="fcn:LabelName('BT-11', 'true')"/>
			</b>
			<xsl:if test="$debug='true'"><xsl:text>BT-11@ </xsl:text></xsl:if>
			<xsl:value-of select="cbc:ID"/>
			<xsl:if test="cbc:ID/@schemeID != ''"> [<xsl:value-of select="cbc:ID/@schemeID"/>]</xsl:if>
		</xsl:if>
	</xsl:template>
	<xsl:template match="cac:AdditionalDocumentReference" mode="Supporting">
		<xsl:if test="cbc:ID !=''">
			<xsl:value-of select="fcn:LabelName('BT-122', 'true')"/>
			<xsl:if test="$debug='true'"><xsl:text>BT-122@ </xsl:text></xsl:if>
			<xsl:apply-templates select="cbc:ID"/>
			<xsl:if test="cbc:ID/@schemeID != ''"> [<xsl:apply-templates select="cbc:ID/@schemeID"/>]</xsl:if>
		</xsl:if>
		<!--small-->
		<!--xsl:if test="cbc:DocumentType !='' or cbc:DocumentTypeCode !=''">
			<br/>
			- <xsl:value-of select="fcn:LabelName('BT-122', 'true')"/>
			<xsl:if test="$debug='true'"><xsl:text> BT-122@ </xsl:text></xsl:if>
			<xsl:apply-templates select="cbc:DocumentType"/>
			<xsl:if test="cbc:DocumentTypeCode !=''"> [<xsl:apply-templates select="cbc:DocumentTypeCode"/>]</xsl:if>
		</xsl:if-->
		<xsl:if test="cbc:DocumentDescription">	
			- <xsl:if test="$debug='true'"><xsl:text> BT-123@ </xsl:text></xsl:if>
			<xsl:value-of select="fcn:LabelName('BT-123', 'true')"/>
			<xsl:apply-templates select="cbc:DocumentDescription"/>	
		</xsl:if>
		<br/>
		<xsl:apply-templates select="cac:Attachment"/>
		<!--/small-->
	</xsl:template>
	<xsl:template match="cac:Attachment">
		<!-- No processing of attached document, just info: -->
		<xsl:if test="cbc:EmbeddedDocumentBinaryObject/@mimeCode !=''">
				- <xsl:value-of select="fcn:LabelName('BT-125-1', 'true')"/>
			<xsl:apply-templates select="cbc:EmbeddedDocumentBinaryObject/@mimeCode"/>
			<br/>
		</xsl:if>
		<xsl:if test="cbc:EmbeddedDocumentBinaryObject/@format !=''">
				- <xsl:value-of select="fcn:LabelName('BT-125-1', 'true')"/>
			<xsl:apply-templates select="cbc:EmbeddedDocumentBinaryObject/@format"/>
			<br/>
		</xsl:if>
		<xsl:if test="cbc:EmbeddedDocumentBinaryObject/@filename !=''">
				- <xsl:value-of select="fcn:LabelName('BT-125-2', 'true')"/>
			<xsl:apply-templates select="cbc:EmbeddedDocumentBinaryObject/@filename"/>
			<br/>
		</xsl:if>
		<xsl:if test="cac:ExternalReference !=''">
			- <xsl:apply-templates select="cac:ExternalReference"/>
			<br/>
		</xsl:if>
	</xsl:template>
	<xsl:template match="cac:ExternalReference">
		<xsl:if test="cbc:URI !=''">
			<xsl:value-of select="fcn:LabelName('BT-124', 'true')"/>
			<xsl:apply-templates select="cbc:URI"/>
		</xsl:if>
	</xsl:template>
	<xsl:template match="cac:BillingReference">
		<br/>
		<xsl:if test="cac:CreditNoteDocumentReference !=''">
			<xsl:apply-templates select="cac:CreditNoteDocumentReference/cbc:ID"/> 
		</xsl:if>
		<xsl:if test="cac:InvoiceDocumentReference !=''">
			<xsl:if test="cac:CreditNoteDocumentReference !=''">
				<br/>
			</xsl:if>
			<xsl:apply-templates select="cac:InvoiceDocumentReference/cbc:ID"/> 
		</xsl:if>
	</xsl:template>
	<!-- Document references end -->
	<!--Periods from here-->
	<xsl:template match="cac:InvoicePeriod">
		<xsl:if test="cbc:StartDate !=''">
			<xsl:if test="$debug='true'">
				<xsl:text> BT-134@</xsl:text>
			</xsl:if>
			<xsl:apply-templates select="fcn:getDate(normalize-space(cbc:StartDate))"/> - 
		</xsl:if>
		<xsl:if test="cbc:EndDate !='' ">
			<xsl:if test="$debug='true'">
				<xsl:text> BT-135@</xsl:text>
			</xsl:if>
			<xsl:apply-templates select="fcn:getDate(normalize-space(cbc:EndDate))"/> 
		</xsl:if>
	</xsl:template>
	<!--Periods end-->
	
	<!--++++++++++++++++++++++++++++++++-->
	<!-- START FOR CII TEMPLATES        -->
	<!--++++++++++++++++++++++++++++++++-->
	<xsl:template match="ram:Content">
		<xsl:call-template name="replace">
			<xsl:with-param name="string" select="."/>
		</xsl:call-template>
	</xsl:template>
	<!--Party templates from here:-->
	<xsl:template match="ram:SellerTradeParty">
		<xsl:call-template name="SellerPartyCrossII"/>
	</xsl:template>
	<xsl:template match="ram:BuyerTradeParty">
		<xsl:call-template name="BuyerPartyCrossII"/>
	</xsl:template>
	<xsl:template match="ram:PayeeTradeParty">
		<xsl:call-template name="PayeePartyCrossII"/>
	</xsl:template>
	<!--SELLER PARTY STARTS HERE-->
	<xsl:template name="SellerPartyCrossII">
		<p style="margin-bottom: 0px;">
			<!--xsl:value-of select="fcn:LabelName('BT-28', 'true')"/-->
			<b>
				<xsl:choose>
					<xsl:when test="ram:SpecifiedLegalOrganization/ram:TradingBusinessName !=''">
						<xsl:if test="$debug='true'">
							<xsl:text>BT-28@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="ram:SpecifiedLegalOrganization/ram:TradingBusinessName"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:if test="$debug='true'">
							<xsl:text>BT-27@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="ram:Name"/>
					</xsl:otherwise>
				</xsl:choose>
			</b>
			<br/>
			<b>
				<xsl:value-of select="fcn:LabelName('BG-5', 'false')"/>
			</b>
		</p>
		<xsl:call-template name="SellerPostalAddressCrossII"/>
		<xsl:for-each select="ram:ID">
			<!--small-->
			<b><xsl:value-of select="fcn:LabelName('BT-29', 'true')"/></b>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-29@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="."/>
			<xsl:if test="ram:GlobalID/@schemeID !='' ">
							 [<xsl:apply-templates select="ram:GlobalID/@schemeID"/>]
					 
				<!--/small-->
			</xsl:if>
		</xsl:for-each>
		<!--Party legal registration: -->
		<xsl:if test="ram:SpecifiedLegalOrganization">
			<xsl:if test="ram:SpecifiedLegalOrganization/ram:ID">
				<!--xsl:if test="cac:Party/cac:PartyIdentification"-->
				<br/>
				<!--/xsl:if-->
				<!--small-->
				<b><xsl:value-of select="fcn:LabelName('BT-30', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-30@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="ram:SpecifiedLegalOrganization/ram:ID"/>
				<xsl:if test="ram:SpecifiedLegalOrganization/ram:ID/@schemeID !='' ">
							 [<xsl:apply-templates select="ram:SpecifiedLegalOrganization/ram:ID/@schemeID"/>]
				</xsl:if>
				<!--/small-->
			</xsl:if>
			<xsl:if test="ram:Name !=''">
				<br/>
				<!--small-->
				<b><xsl:value-of select="fcn:LabelName('BT-27', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-27@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="ram:Name"/>
				<!--/small-->
			</xsl:if>
			<xsl:if test="ram:Description != ''">
				<!--small-->
				<br/>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-33@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="ram:Description"/>
				<!--/small-->
			</xsl:if>
			<!--xsl:if test="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress !=''">
        <br/>
        <-small->
        <xsl:value-of select="fcn:LabelName('BT-33', 'true')"/>
        <xsl:choose>
          <xsl:when test="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CityName !='' and          cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:Country !=''"><xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CityName"/>, 

							<xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:Country"/>
						</xsl:when>
          <xsl:otherwise>
            <xsl:if test="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CityName !=''">
              <xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cbc:CityName"/>
            </xsl:if>
            <xsl:if test="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:Country !=''">
              <xsl:apply-templates select="cac:Party/cac:PartyLegalEntity/cac:RegistrationAddress/cac:Country"/>
            </xsl:if>
          </xsl:otherwise>
        </xsl:choose>
        <-/small->
      </xsl:if-->
		</xsl:if>
		<!--Party VAT registration: -->
		<!--xsl:if test="cac:Party/cac:PartyTaxScheme"-->
		<!--small-->
		<xsl:for-each select="ram:SpecifiedTaxRegistration">
			<br/>
			<xsl:choose>
				<xsl:when test="ram:ID/@schemeID = 'VAT'">
					<b><xsl:value-of select="fcn:LabelName('BT-31', 'true')"/></b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-31@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:ID"/>
				</xsl:when>
				<xsl:otherwise>
					<b><xsl:value-of select="fcn:LabelName('BT-32', 'true')"/></b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-32@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:ID"/> [<xsl:value-of select="ram:ID/@schemeID"/>]
				</xsl:otherwise>
			</xsl:choose>
			<!--xsl:if test="cbc:ExemptionReason">
						<br/><xsl:apply-templates select="cbc:ExemptionReason"/>
					</xsl:if-->
		</xsl:for-each>
		<!--/small-->
		<!--/xsl:if-->
	</xsl:template>
	<xsl:template name="SellerPartyNameCrossII">
		<xsl:if test="ram:SellerTradeParty/ram:Name !=''">
			<xsl:apply-templates select="ram:Name"/>
		</xsl:if>
	</xsl:template>
	<xsl:template name="SellerPostalAddressCrossII">
		<div>
			<!-- class="indent"-->
			<xsl:if test="ram:PostalTradeAddress/ram:LineOne !=''">
				<span class="UBLStreetName">
					<!-- xsl:value-of select="fcn:LabelName('BT-35', 'true')"/ -->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-35@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:LineOne"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="ram:PostalTradeAddress/ram:LineTwo !=''">
				<span class="UBLAdditionalStreetName">
					<!-- xsl:value-of select="fcn:LabelName('BT-36', 'true')"/ -->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-36@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:LineTwo"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="ram:PostalTradeAddress/ram:LineThree !=''">
				<span class="UBLAdditionalStreetName">
					<!-- xsl:value-of select="fcn:LabelName('BT-162', 'true')"/ -->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-162@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:LineThree"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="ram:PostalTradeAddress/ram:PostcodeCode !='' or ram:PostalTradeAddress/ram:CityName !=''">
				<span class="UBLCityName">
					<xsl:choose>
						<xsl:when test="ram:PostalTradeAddress/ram:PostcodeCode !=''">
							<!-- xsl:value-of select="fcn:LabelName('BT-38', 'true')"/ -->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-38@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="ram:PostalTradeAddress/ram:PostcodeCode"/> 
							<!-- xsl:value-of select="fcn:LabelName('BT-37', 'true')"/ -->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-37@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="ram:PostalTradeAddress/ram:CityName"/>
						</xsl:when>
						<xsl:otherwise>
							<!-- xsl:value-of select="fcn:LabelName('BT-37', 'true')"/ -->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-37@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="ram:PostalTradeAddress/ram:CityName"/>
						</xsl:otherwise>
					</xsl:choose>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="ram:PostalTradeAddress/ram:CountrySubDivisionName !='' or ram:PostalTradeAddress/ram:CountryID !=''">
				<xsl:choose>
					<xsl:when test="ram:PostalTradeAddress/ram:CountrySubDivisionName !='' and ram:PostalTradeAddress/ram:CountryID !=''">
						<!-- xsl:value-of select="fcn:LabelName('BT-39', 'true')"/-->
						<xsl:if test="$debug='true'">
							<xsl:text>BT-39@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountrySubDivisionName"/>, 
						<!-- xsl:value-of select="fcn:LabelName('BT-40', 'true')"/ -->
						<xsl:if test="$debug='true'">
							<xsl:text>BT-40@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountryID"/>
						<br/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:if test="ram:PostalTradeAddress/ram:CountrySubDivisionName !=''">
							<!-- xsl:value-of select="fcn:LabelName('BT-39', 'true')"/-->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-39@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountrySubDivisionName"/>
						</xsl:if>
						<xsl:if test="ram:PostalTradeAddress/ram:CountryID !=''">
							<!-- xsl:value-of select="fcn:LabelName('BT-40', 'true')"/ -->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-40@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountryID"/>
						</xsl:if>
						<br/>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:if>
		</div>
	</xsl:template>
	<xsl:template name="SellerContactCrossII">
		<div>
			<!-- class="indent"-->
			<xsl:if test="ram:DefinedTradeContact/ram:PersonName !=''">
				<!--xsl:value-of select="fcn:LabelName('BT-41', 'true')"/-->
				<xsl:if test="$debug='true'">
					<xsl:text>BT-41@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="ram:DefinedTradeContact/ram:PersonName"/>
				<br/>
			</xsl:if>
			<xsl:if test="ram:DefinedTradeContact/ram:TelephoneUniversalCommunication/ram:CompleteNumber !=''">
				<span class="UBLTelephone">
					<!--xsl:value-of select="fcn:LabelName('BT-42', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-42@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:DefinedTradeContact/ram:TelephoneUniversalCommunication/ram:CompleteNumber"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="ram:DefinedTradeContact/ram:TelefaxUniversalCommunication/ram:CompleteNumber !=''">
				<span class="UBLTelefax">
					<!--xsl:value-of select="fcn:LabelName('BT-22', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-22@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:DefinedTradeContact/ram:TelefaxUniversalCommunication/ram:CompleteNumber"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="ram:DefinedTradeContact/ram:EmailURIUniversalCommunication/ram:URIID !=''">
				<span class="UBLElectronicMail">
					<!--xsl:value-of select="fcn:LabelName('BT-43', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-43@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:DefinedTradeContact/ram:EmailURIUniversalCommunication/ram:URIID"/>
				</span>
			</xsl:if>
		</div>
	</xsl:template>
	<!--BUYER PARTY STARTS HERE-->
	<xsl:template name="BuyerPartyCrossII">
		<p style="margin-bottom: 0px;">
		<b>
			<!--xsl:value-of select="fcn:LabelName('BT-45', 'true')"/-->
			<xsl:choose>
				<xsl:when test="ram:SpecifiedLegalOrganization/ram:TradingBusinessName">
					<xsl:if test="$debug='true'">
						<xsl:text>BT-45@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:SpecifiedLegalOrganization/ram:TradingBusinessName"/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-44@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:Name"/>
				</xsl:otherwise>
			</xsl:choose>
			</b>
			<br/>
			<b>
				<xsl:value-of select="fcn:LabelName('BG-8', 'false')"/>
			</b>
		</p>
		<xsl:call-template name="BuyerPostalAddressCrossII"/>
		<xsl:if test="ram:ID">
			<!--small-->
			<b><xsl:value-of select="fcn:LabelName('BT-46', 'true')"/></b>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-46@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:ID"/>
			<xsl:if test="ram:GlobalID/@schemeID !='' ">

						 [<xsl:apply-templates select="ram:GlobalID/@schemeID"/>
				<xsl:if test="$debug='true'">
					<xsl:text> BT-46-1@ </xsl:text>
				</xsl:if>]

			</xsl:if>
			<!--/small-->
		</xsl:if>
		<!--Party legal registration: -->
		<xsl:if test="ram:SpecifiedLegalOrganization">
			<xsl:if test="ram:SpecifiedLegalOrganization/ram:ID">
				<br/>
				<!--small-->
				<b><xsl:value-of select="fcn:LabelName('BT-47', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-47@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="ram:SpecifiedLegalOrganization/ram:ID"/>
				<xsl:if test="ram:GlobalID/@schemeID !='' ">

						 [<xsl:apply-templates select="ram:GlobalID/@schemeID"/>
					<xsl:if test="$debug='true'">
						<xsl:text> BT-46-1@ </xsl:text>
					</xsl:if>]

				</xsl:if>
				<!--/small-->
			</xsl:if>
			<xsl:if test="ram:Name !=''">
				<br/>
				<!--small-->
				<b><xsl:value-of select="fcn:LabelName('BT-44', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-44@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="ram:Name"/>
				<!--/small-->
			</xsl:if>
		</xsl:if>
		<!--Party VAT registration: -->
		<xsl:if test="ram:SpecifiedTaxRegistration">
			<!--small-->
			<xsl:if test="ram:SpecifiedTaxRegistration">
				<br/>
				<b><xsl:value-of select="fcn:LabelName('BT-48', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-48@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="ram:SpecifiedTaxRegistration/ram:ID"/>
				<xsl:if test="ram:SpecifiedTaxRegistration/ram:ID/@schemeID !='' ">
						 [<xsl:apply-templates select="ram:SpecifiedTaxRegistration/ram:ID/@schemeID"/>]
				</xsl:if>
			</xsl:if>
			<!--xsl:if test="cac:Party/cac:PartyTaxScheme/cbc:ExemptionReason">
					<br/><xsl:apply-templates select="cac:Party/cac:PartyTaxScheme/cbc:ExemptionReason"/>
				</xsl:if-->
			<!--/small-->
		</xsl:if>
	</xsl:template>
	<xsl:template name="BuyerPartyNameCrossII">
		<xsl:if test="ram:Name !=''">
			<xsl:apply-templates select="ram:Name"/>
		</xsl:if>
	</xsl:template>
	<xsl:template name="BuyerPostalAddressCrossII">
		<div>
			<!-- class="indent"-->
			<xsl:if test="ram:PostalTradeAddress/ram:LineOne !=''">
				<span class="UBLStreetName">
					<!--xsl:value-of select="fcn:LabelName('BT-50', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-50@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:LineOne"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="ram:PostalTradeAddress/ram:LineTwo !=''">
				<span class="UBLAdditionalStreetName">
					<!--xsl:value-of select="fcn:LabelName('BT-51', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-51@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:LineTwo"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="ram:PostalTradeAddress/ram:LineThree !=''">
				<span class="UBLAdditionalStreetName">
					<!--xsl:value-of select="fcn:LabelName('BT-163', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-163@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:LineThree"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="ram:PostalTradeAddress/ram:PostcodeCode !='' or ram:BuyerTradeParty/ram:PostalTradeAddress/ram:CityName !=''">
				<span class="UBLCityName">
					<xsl:choose>
						<xsl:when test="ram:PostalTradeAddress/ram:PostcodeCode !=''">
							<!--xsl:value-of select="fcn:LabelName('BT-53', 'true')"/-->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-53@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="ram:PostalTradeAddress/ram:PostcodeCode"/>  
							<!--xsl:value-of select="fcn:LabelName('BT-52', 'true')"/-->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-52@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="ram:PostalTradeAddress/ram:CityName"/>
							<br/>
						</xsl:when>
						<xsl:otherwise>
							<!--xsl:value-of select="fcn:LabelName('BT-52', 'true')"/-->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-52@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="ram:PostalTradeAddress/ram:CityName"/>
							<br/>
						</xsl:otherwise>
					</xsl:choose>
				</span>
			</xsl:if>
			<xsl:if test="ram:PostalTradeAddress/ram:CountrySubDivisionName !='' or ram:BuyerTradeParty/ram:PostalTradeAddress/ram:CountryID !=''">
				<xsl:choose>
					<xsl:when test="ram:PostalTradeAddress/ram:CountrySubDivisionName !='' and ram:BuyerTradeParty/ram:PostalTradeAddress/ram:CountryID !=''">
						<!--xsl:value-of select="fcn:LabelName('BT-54', 'true')"/-->
						<xsl:if test="$debug='true'">
							<xsl:text>BT-54@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountrySubDivisionName"/>, 
						<!--xsl:value-of select="fcn:LabelName('BT-55', 'true')"/-->
						<xsl:if test="$debug='true'">
							<xsl:text>BT-55@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountryID"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:if test="ram:PostalTradeAddress/ram:CountrySubDivisionName !=''">
							<!--xsl:value-of select="fcn:LabelName('BT-54', 'true')"/-->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-54@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountrySubDivisionName"/>
						</xsl:if>
						<xsl:if test="ram:PostalTradeAddress/ram:CountryID !=''">
							<!--xsl:value-of select="fcn:LabelName('BT-55', 'true')"/-->
							<xsl:if test="$debug='true'">
								<xsl:text>BT-55@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountryID"/>
						</xsl:if>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:if>
		</div>
	</xsl:template>
	<xsl:template name="BuyerContactCrossII">
		<div>
			<!-- class="indent"-->
			<xsl:if test="ram:DefinedTradeContact/ram:PersonName !=''">
				<!--xsl:value-of select="fcn:LabelName('BT-56', 'true')"/-->
				<xsl:if test="$debug='true'">
					<xsl:text>BT-56@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="ram:DefinedTradeContact/ram:PersonName"/>
				<br/>
			</xsl:if>
			<xsl:if test="ram:DefinedTradeContact/ram:TelephoneUniversalCommunication/ram:CompleteNumber !=''">
				<span class="UBLTelephone">
					<!--xsl:value-of select="fcn:LabelName('BT-57', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-57@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:DefinedTradeContact/ram:TelephoneUniversalCommunication/ram:CompleteNumber"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="ram:DefinedTradeContact/ram:TelefaxUniversalCommunication/ram:CompleteNumber !=''">
				<span class="UBLTelefax">
					<!--xsl:value-of select="fcn:LabelName('BT-22', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-22@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:DefinedTradeContact/ram:TelefaxUniversalCommunication/ram:CompleteNumber"/>
				</span>
				<br/>
			</xsl:if>
			<xsl:if test="ram:DefinedTradeContact/ram:EmailURIUniversalCommunication/ram:URIID !=''">
				<span class="UBLElectronicMail">
					<!--xsl:value-of select="fcn:LabelName('BT-58', 'true')"/-->
					<xsl:if test="$debug='true'">
						<xsl:text>BT-58@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:DefinedTradeContact/ram:EmailURIUniversalCommunication/ram:URIID"/>
				</span>
				<br/>
			</xsl:if>
		</div>
	</xsl:template>
	<!-- PAYEE PARTY STARTS HERE-->
	<xsl:template name="PayeePartyCrossII">
		<!--xsl:value-of select="fcn:LabelName('BT-59', 'true')"/-->
		<xsl:if test="$debug='true'">
			<xsl:text>BT-59@ </xsl:text>
		</xsl:if>
		<b><xsl:apply-templates select="ram:Name"/></b>
		<xsl:if test="ram:ID">
			<br/>
			<!--small-->
			<b><xsl:value-of select="fcn:LabelName('BT-60', 'true')"/></b>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-60@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:ID"/>
			<xsl:if test="ram:ID/@schemeID !='' ">
						 [<xsl:apply-templates select="ram:ID/@schemeID"/>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-57@60-1 </xsl:text>
				</xsl:if>]
			</xsl:if>
			<!--/small-->
		</xsl:if>
		<!--Party legal registration: -->
		<xsl:if test="ram:SpecifiedLegalOrganization">
			<xsl:if test="ram:SpecifiedLegalOrganization">
				<br/>
				<!--small-->
				<b><xsl:value-of select="fcn:LabelName('BT-61', 'true')"/></b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-61@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="ram:SpecifiedLegalOrganization/ram:ID"/>
				<xsl:if test="ram:SpecifiedLegalOrganization/ram:ID/@schemeID !='' ">
						 [<xsl:apply-templates select="ram:SpecifiedLegalOrganization/ram:ID/@schemeID"/>]
				</xsl:if>
				<!--/small-->
			</xsl:if>
		</xsl:if>
		<!--Party VAT registration: -->
		<!--xsl:if test="cac:PartyTaxScheme">
      <-small->
      <xsl:if test="cac:PartyTaxScheme">
        <br/>
        <xsl:value-of select="fcn:LabelName('BT-63', 'true')"/>
        <xsl:if test="$debug='true'">
          <xsl:text>BT-63@ </xsl:text>
        </xsl:if>
        <xsl:apply-templates select="cac:PartyTaxScheme/cbc:CompanyID"/>
        <xsl:if test="cac:PartyTaxScheme/cbc:CompanyID/@schemeID !='' ">
						 [<xsl:apply-templates select="cac:PartyTaxScheme/cbc:CompanyID/@schemeID"/>]
					</xsl:if>
      </xsl:if>
      <-/small->
    </xsl:if-->
	</xsl:template>
	<xsl:template name="PayeePartyNameCrossII">
		<xsl:if test="ram:PayeeTradeParty/ram:Name !=''">
			<xsl:apply-templates select="ram:PayeeTradeParty/ram:Name"/>
		</xsl:if>
	</xsl:template>
	<!--xsl:template match="ram:BuyerTradeParty">
		<xsl:if test="ram:Name !=''">
			<xsl:apply-templates select="ram:Name"/>
		</xsl:if>
	</xsl:template-->
	<xsl:template match="ram:PostalTradeAddress">
		<xsl:if test="ram:LineOne !=''">
			<br/>
			<span class="UBLStreetName">
				<xsl:apply-templates select="ram:LineOne"/>
			</span>
		</xsl:if>
		<xsl:if test="ram:LineTwo !=''">
			<br/>
			<span class="UBLAdditionalStreetName">
				<xsl:apply-templates select="ram:LineTwo"/>
			</span>
		</xsl:if>
		<xsl:if test="ram:LineThree !=''">
			<br/>
			<span class="UBLAdditionalStreetName">
				<xsl:apply-templates select="ram:LineThree"/>
			</span>
		</xsl:if>
		<xsl:if test="ram:PostcodeCode !='' or ram:CityName !=''">
			<br/>
			<span class="UBLCityName">
				<xsl:choose>
					<xsl:when test="ram:PostcodeCode !=''">
						<xsl:apply-templates select="ram:PostcodeCode"/> 
						<xsl:apply-templates select="ram:CityName"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:apply-templates select="ram:CityName"/>
					</xsl:otherwise>
				</xsl:choose>
			</span>
		</xsl:if>
		<xsl:if test="ram:PostalTradeAddress/ram:CountrySubDivisionName !='' or ram:PostalTradeAddress/ram:CountryID !=''">
			<xsl:choose>
				<xsl:when test="ram:PostalTradeAddress/ram:CountrySubDivisionName !='' and ram:PostalTradeAddress/ram:CountryID !=''">
					<br/>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountrySubDivisionName"/>,
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountryID"/>
					<br/>
				</xsl:when>
				<xsl:otherwise>
					<br/>
					<xsl:if test="ram:PostalTradeAddress/ram:CountrySubDivisionName !=''">
						<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountrySubDivisionName"/>
					</xsl:if>
					<xsl:if test="ram:PostalTradeAddress/ram:CountryID !=''">
						<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountryID"/>
					</xsl:if>
					<br/>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:if>
	</xsl:template>
	<xsl:template match="ram:CountryID">
		<span>
			<xsl:value-of select="."/>
			<!-- Checking of listID (normally NOT a function of a stylesheet): -->
			<xsl:if test="@listID !=''">
				<xsl:if test="@listID !='ISO3166-1:Alpha2'">
					 <!--small-->
					<em>[<xsl:apply-templates select="@listID"/>
					 -invalid listID]</em>
					<!--/small-->
				</xsl:if>
			</xsl:if>
		</span>
	</xsl:template>
	<!--TaxRepresentativeParty Starts here:-->
	<xsl:template match="ram:SellerTaxRepresentativeTradeParty">
		<xsl:if test="ram:Name !=''">
			<xsl:if test="$debug='true'">
				<xsl:text>BT-62@ </xsl:text>
			</xsl:if>
			<b><xsl:value-of select="ram:Name"/></b>
			<br/>
		</xsl:if>
		<xsl:if test="ram:PostalTradeAddress">
			<p style="margin-bottom: 0px;">
				<b>
					<xsl:value-of select="fcn:LabelName('BG-12', 'false')"/>
				</b>
			</p>
		</xsl:if>
		<xsl:if test="ram:PostalTradeAddress/ram:LineOne !=''">
			<xsl:if test="$debug='true'">
				<xsl:text>BT-63@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:PostalTradeAddress/ram:LineOne"/>
			<br/>
		</xsl:if>
		<xsl:if test="ram:PostalTradeAddress/ram:LineTwo !=''">
			<xsl:if test="$debug='true'">
				<xsl:text>BT-65@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:PostalTradeAddress/ram:LineTwo"/>
			<br/>
		</xsl:if>
		<xsl:if test="ram:PostalTradeAddress/ram:LineThree !=''">
			<xsl:if test="$debug='true'">
				<xsl:text>BT-164@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:PostalTradeAddress/ram:LineThree"/>
			<br/>
		</xsl:if>
		<xsl:if test="ram:PostalTradeAddress/ram:PostcodeCode !='' or ram:PostalTradeAddress/ram:CityName !=''">
			<xsl:choose>
				<xsl:when test="ram:PostalTradeAddress/ram:PostcodeCode !=''">
					<xsl:if test="$debug='true'">
						<xsl:text>BT-67@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:PostcodeCode"/> 
					<xsl:if test="$debug='true'">
						<xsl:text>BT-66@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:CityName"/>
					<br/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-66@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:CityName"/>
					<br/>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:if>
		<xsl:if test="ram:PostalTradeAddress/ram:CountrySubDivisionName !='' or ram:PostalTradeAddress/ram:CountryID !=''">
			<xsl:choose>
				<xsl:when test="ram:PostalTradeAddress/ram:CountrySubDivisionName !='' and ram:PostalTradeAddress/ram:CountryID !=''">
					<xsl:if test="$debug='true'">
						<xsl:text>BT-68@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountrySubDivisionName"/>,
					<xsl:if test="$debug='true'">
						<xsl:text>BT-69@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountryID"/>
					<br/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:if test="ram:PostalTradeAddress/ram:CountrySubDivisionName !=''">
						<xsl:if test="$debug='true'">
							<xsl:text>BT-68@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountrySubDivisionName"/>
						<br/>
					</xsl:if>
					<xsl:if test="ram:PostalTradeAddress/ram:CountryID !=''">
						<xsl:if test="$debug='true'">
							<xsl:text>BT-69@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountryID"/>
						<br/>
					</xsl:if>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:if>
		<xsl:if test="ram:SpecifiedTaxRegistration/ram:ID !=''">
			<!--small-->
			<b><xsl:value-of select="fcn:LabelName('BT-63', 'true')"/></b>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-63@ </xsl:text>
			</xsl:if>
			<xsl:value-of select="ram:SpecifiedTaxRegistration/ram:ID"/>
			<!--/small-->
		</xsl:if>
	</xsl:template>
	<!--Delivery templates start: -->
	<xsl:template match="ram:ApplicableHeaderTradeDelivery" mode="DocumentHeader">
		<p>
			<xsl:if test="ram:ShipToTradeParty !=''">
				<h3>
					<xsl:value-of select="fcn:LabelName('BG-13', 'false')"/>
				</h3>
				<xsl:if test="ram:ShipToTradeParty/ram:Name != ''">
					<xsl:if test="$debug='true'">
						<xsl:text>BT-70@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:ShipToTradeParty/ram:Name"/>
					<br/>
				</xsl:if>
				<xsl:apply-templates select="ram:ShipToTradeParty/ram:ID"/>
			</xsl:if>
		</p>
	</xsl:template>
	<xsl:template match="ram:ShipToTradeParty">
		<xsl:if test="ram:ID !=''">
			<xsl:value-of select="fcn:LabelName('BT-71', 'true')"/>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-71@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:ID"/>
			<xsl:choose>
				<xsl:when test="ram:ID/@schemeID !=''">
							 [<xsl:apply-templates select="ram:ID/@schemeID"/>]
				</xsl:when>
				<xsl:otherwise>
							 [No schemeID]
				</xsl:otherwise>
			</xsl:choose>
		</xsl:if>
		<xsl:if test="ram:ShipToTradeParty/ram:PostalTradeAddress !=''">
			<br/>
			<xsl:call-template name="DeliveryAddressCrossII"/>
		</xsl:if>
	</xsl:template>
	<xsl:template name="DeliveryAddressCrossII">
		<b>
			<xsl:value-of select="fcn:LabelName('BG-15', 'false')"/>
		</b>
		<xsl:if test="ram:PostalTradeAddress/ram:LineOne !=''">
			<span class="UBLStreetName">
				<br/>
				<!--xsl:value-of select="fcn:LabelName('BT-75', 'true')"/-->
				<xsl:if test="$debug='true'"><xsl:text>BT-75@ </xsl:text></xsl:if>
				<xsl:apply-templates select="ram:PostalTradeAddress/ram:LineOne"/>
			</span>
		</xsl:if>
		<xsl:if test="ram:PostalTradeAddress/ram:LineTwo !=''">
			<span class="UBLAdditionalStreetName">
				<br/>
				<!--xsl:value-of select="fcn:LabelName('BT-76', 'true')"/-->
				<xsl:if test="$debug='true'"><xsl:text>BT-76@ </xsl:text></xsl:if>
				<xsl:apply-templates select="ram:PostalTradeAddress/ram:LineTwo"/>
			</span>
		</xsl:if>
		<xsl:if test="ram:PostalTradeAddress/ram:LineThree !=''">
			<span class="UBLAdditionalStreetName">
				<br/>
				<!--xsl:value-of select="fcn:LabelName('BT-165', 'true')"/-->
				<xsl:if test="$debug='true'"><xsl:text>BT-165@ </xsl:text></xsl:if>
				<xsl:apply-templates select="ram:PostalTradeAddress/ram:LineThree"/>
			</span>
		</xsl:if>
		<xsl:if test="ram:PostalTradeAddress/ram:PostcodeCode !='' or ram:PostalTradeAddress/ram:CityName !=''">
			<br/>
			<span class="UBLCityName">
				<xsl:choose>
					<xsl:when test="ram:PostalTradeAddress/ram:PostcodeCode !=''">
						<!--xsl:value-of select="fcn:LabelName('BT-78', 'true')"/-->
						<xsl:if test="$debug='true'"><xsl:text>BT-78@ </xsl:text></xsl:if>
						<xsl:apply-templates select="ram:PostalTradeAddress/ram:PostcodeCode"/> 
						<!--xsl:value-of select="fcn:LabelName('BT-77', 'true')"/-->
						<xsl:if test="$debug='true'"><xsl:text>BT-77@ </xsl:text></xsl:if>
						<xsl:apply-templates select="ram:PostalTradeAddress/ram:CityName"/>
					</xsl:when>
					<xsl:otherwise>
						<!--xsl:value-of select="fcn:LabelName('BT-77', 'true')"/-->
						<xsl:if test="$debug='true'"><xsl:text>BT-77@ </xsl:text></xsl:if>
						<xsl:apply-templates select="ram:PostalTradeAddress/ram:CityName"/>
					</xsl:otherwise>
				</xsl:choose>
			</span>
		</xsl:if>
		<xsl:if test="ram:PostalTradeAddress/ram:CountrySubDivisionName !='' or ram:PostalTradeAddress/ram:CountryID !=''">
			<xsl:choose>
				<xsl:when test="ram:PostalTradeAddress/ram:CountrySubDivisionName !='' and ram:PostalTradeAddress/ram:CountryID !=''">
					<br/>
					<!--xsl:value-of select="fcn:LabelName('BT-79', 'true')"/-->
					<xsl:if test="$debug='true'"><xsl:text>BT-79@ </xsl:text></xsl:if>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountrySubDivisionName"/>,

					<!--xsl:value-of select="fcn:LabelName('BT-80', 'true')"/-->
					<xsl:if test="$debug='true'"><xsl:text>BT-80@ </xsl:text></xsl:if>
					<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountryID"/>
				</xsl:when>
				<xsl:otherwise>
					<br/>
					<xsl:if test="ram:PostalTradeAddress/ram:CountrySubDivisionName !=''">
						<!--xsl:value-of select="fcn:LabelName('BT-79', 'true')"/-->
						<xsl:if test="$debug='true'"><xsl:text>BT-79@ </xsl:text></xsl:if>
						<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountrySubDivisionName"/>
					</xsl:if>
					<xsl:if test="ram:PostalTradeAddress/ram:CountryID !=''">
						<!--xsl:value-of select="fcn:LabelName('BT-80', 'true')"/-->
						<xsl:if test="$debug='true'"><xsl:text>BT-80@ </xsl:text></xsl:if>
						<xsl:apply-templates select="ram:PostalTradeAddress/ram:CountryID"/>
					</xsl:if>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:if>
	</xsl:template>
	<!--Contact from here: -->
	<xsl:template match="ram:SellerTradeParty" mode="accsupcontact">
		<!--xsl:apply-templates select="ram:DefinedTradeContact"/-->
		<xsl:call-template name="SellerContactCrossII"/>
	</xsl:template>
	<xsl:template match="ram:BuyerTradeParty" mode="acccuscontact">
		<!--xsl:apply-templates select="ram:DefinedTradeContact"/-->
		<xsl:call-template name="BuyerContactCrossII"/>
	</xsl:template>
	<!--Invoiceline start: -->
	<xsl:template match="ram:IncludedSupplyChainTradeLineItem">
		<tr>
			<td>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-126@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="ram:AssociatedDocumentLineDocument/ram:LineID"/>
			</td>
			<td>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-155@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="ram:SpecifiedTradeProduct/ram:SellerAssignedID"/>
			</td>
			<td>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-153@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="ram:SpecifiedTradeProduct/ram:Name"/>
				<br/>
				<br/>
				<!--small-->
				<xsl:if test="ram:SpecifiedTradeProduct/ram:GlobalID !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-157', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-157@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:SpecifiedTradeProduct/ram:GlobalID"/>
					<xsl:choose>
						<xsl:when test="ram:SpecifiedTradeProduct/ram:GlobalID/@schemeID !=''">
							<!--small--> [<xsl:if test="$debug='true'">
								<xsl:text>BT-157-1@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="ram:SpecifiedTradeProduct/ram:GlobalID/@schemeID"/>]<!--/small-->
						</xsl:when>
						<xsl:otherwise>
							<!--small--> [No schemeID]<!--/small-->
						</xsl:otherwise>
					</xsl:choose>
					<br/>
				</xsl:if>
				<xsl:if test="ram:SpecifiedTradeProduct/ram:Description !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-154', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-154@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:SpecifiedTradeProduct/ram:Description"/>
					<br/>
				</xsl:if>
				<xsl:if test="ram:SpecifiedTradeProduct/ram:ApplicableProductCharacteristic !=''">
					<xsl:if test="$debug='true'">
						<xsl:text>BT-160@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:SpecifiedTradeProduct/ram:ApplicableProductCharacteristic"/>
				</xsl:if>
				<xsl:if test="ram:AssociatedDocumentLineDocument/ram:IncludedNote/ram:Content !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-127', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-127@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:AssociatedDocumentLineDocument/ram:IncludedNote/ram:Content"/>
					<br/>
				</xsl:if>
				<xsl:if test="ram:SpecifiedTradeProduct/ram:DesignatedProductClassification/ram:ClassCode !=''">
					<xsl:apply-templates select="ram:SpecifiedTradeProduct/ram:DesignatedProductClassification/ram:ClassCode"/>
				</xsl:if>
				<xsl:if test="ram:SpecifiedTradeProduct/ram:GlobalID != ''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-156', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-156@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:SpecifiedTradeProduct/ram:GlobalID"/>
					<br/>
				</xsl:if>
				<xsl:if test="ram:SpecifiedLineTradeSettlement/ram:ReceivableSpecifiedTradeAccountingAccount/ram:ID !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-19', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-19@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:SpecifiedLineTradeSettlement/ram:ReceivableSpecifiedTradeAccountingAccount/ram:ID"/>
					<br/>
				</xsl:if>
				<xsl:if test="ram:SpecifiedLineTradeSettlement/ram:BillingSpecifiedPeriod !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BG-14', 'true')"/>
					</b>
					<xsl:apply-templates select="ram:SpecifiedLineTradeSettlement/ram:BillingSpecifiedPeriod"/>
					<br/>
				</xsl:if>
				<xsl:if test="ram:SpecifiedLineTradeAgreement/ram:GrossPriceProductTradePrice !=''">
					<xsl:apply-templates select="ram:SpecifiedLineTradeAgreement/ram:GrossPriceProductTradePrice" mode="PriceUnit-new"/>
				</xsl:if>
				<xsl:if test="ram:SpecifiedTradeProduct/ram:OriginTradeCountry/ram:ID !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-159', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-159@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:SpecifiedTradeProduct/ram:OriginTradeCountry/ram:ID"/>
					<xsl:if test="ram:SpecifiedTradeProduct/ram:OriginTradeCountry/ram:ID/@listID !=''">
						<!--small--> [<xsl:apply-templates select="ram:SpecifiedTradeProduct/ram:OriginTradeCountry/ram:ID/@listID"/>]<!--/small-->
					</xsl:if>
					<br/>
				</xsl:if>
				<xsl:if test="ram:SpecifiedLineTradeAgreement/ram:BuyerOrderReferencedDocument/ram:LineID !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-132', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-132@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:SpecifiedLineTradeAgreement/ram:BuyerOrderReferencedDocument/ram:LineID"/>
					<br/>
				</xsl:if>
				<xsl:if test="ram:SpecifiedLineTradeSettlement/ram:AdditionalReferencedDocument/ram:IssuerAssignedID !=''">
					<b>
						<xsl:value-of select="fcn:LabelName('BT-128', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-128@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:SpecifiedLineTradeSettlement/ram:AdditionalReferencedDocument/ram:IssuerAssignedID"/> [<xsl:apply-templates select="ram:SpecifiedLineTradeSettlement/ram:AdditionalReferencedDocument/ram:TypeCode"/>]
					<br/>
				</xsl:if>
				<!--/small-->
			</td>
			<td align="left">
				<xsl:if test="ram:SpecifiedLineTradeDelivery/ram:BilledQuantity !=''">
					<xsl:if test="$debug='true'">
						<xsl:text>BT-129@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:SpecifiedLineTradeDelivery/ram:BilledQuantity"/> 
					<xsl:if test="ram:SpecifiedLineTradeDelivery/ram:BilledQuantity/@unitCode !=''">
						<xsl:if test="$debug='true'">
							<xsl:text>BT-130@ </xsl:text>
						</xsl:if>
						<xsl:value-of select="ram:SpecifiedLineTradeDelivery/ram:BilledQuantity/@unitCode"/>
						<br/>
						<!--small>(<xsl:value-of select="fcn:LabelName('BT-130', 'true')"/><xsl:value-of select="fcn:UNECECode(ram:SpecifiedLineTradeDelivery/ram:BilledQuantity/@unitCode)"/>)</small-->
					</xsl:if>
				</xsl:if>
				<xsl:if test="ram:SpecifiedLineTradeDelivery/ram:CreditedQuantity !=''">
					<xsl:apply-templates select="ram:SpecifiedLineTradeDelivery/ram:CreditedQuantity"/> 
					<xsl:if test="ram:SpecifiedLineTradeDelivery/ram:CreditedQuantity/@unitCode !=''">
						<xsl:value-of select="ram:SpecifiedLineTradeDelivery/ram:CreditedQuantity/@unitCode"/>
						<!--br/ -->
						<!--small>(<xsl:value-of select="fcn:LabelName('BT-130', 'true')"/><xsl:value-of select="fcn:UNECECode(cbc:CreditedQuantity/@unitCode)"/>)</small-->
					</xsl:if>
				</xsl:if>
			</td>
			<td>
				<xsl:apply-templates select="ram:SpecifiedLineTradeAgreement"/>
				<xsl:if test="ram:SpecifiedLineTradeAgreement/ram:GrossPriceProductTradePrice/ram:BasisQuantity">
					<!--small-->
					<br/>
					<b>
						<xsl:value-of select="fcn:LabelName('BT-149', 'true')"/>
					</b>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-149@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:SpecifiedLineTradeAgreement/ram:GrossPriceProductTradePrice/ram:BasisQuantity"/>
					<!--/small-->
				</xsl:if>
			</td>
			<td>
				<xsl:if test="ram:SpecifiedLineTradeSettlement/ram:ApplicableTradeTax !='' ">
					<xsl:choose>
						<xsl:when test="ram:SpecifiedLineTradeSettlement/ram:ApplicableTradeTax/ram:RateApplicablePercent !=''">
							<xsl:if test="$debug='true'">
								<xsl:text>BT-151@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="ram:SpecifiedLineTradeSettlement/ram:ApplicableTradeTax/ram:TypeCode"/>, 

							<xsl:if test="$debug='true'">
								<xsl:text>BT-152@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="fcn:Currency(ram:SpecifiedLineTradeSettlement/ram:ApplicableTradeTax/ram:RateApplicablePercent)"/>%

						</xsl:when>
						<xsl:otherwise>
							<xsl:apply-templates select="ram:SpecifiedLineTradeSettlement/ram:ApplicableTradeTax/ram:TypeCode"/>: 
							<xsl:apply-templates select="ram:SpecifiedLineTradeSettlement/ram:ApplicableTradeTax/ram:CategoryCode"/>
						</xsl:otherwise>
					</xsl:choose>
				</xsl:if>
				<xsl:if test="ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:TaxTotalAmount">
					<!--small-->
					<xsl:choose>
						<xsl:when test="ram:SpecifiedLineTradeSettlement/ ram:ApplicableTradeTax/ram:RateApplicablePercent !=''">
							<br/>(<xsl:if test="$debug='true'">
								<xsl:text>BT-110@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="fcn:Currency(ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:TaxTotalAmount)"/>)

						</xsl:when>
						<xsl:otherwise>
							(<xsl:if test="$debug='true'">
								<xsl:text>BT-110@ </xsl:text>
							</xsl:if>
							<xsl:apply-templates select="fcn:Currency(ram:SpecifiedTradeSettlementHeaderMonetarySummation/ram:TaxTotalAmount)"/>)
						</xsl:otherwise>
					</xsl:choose>
					<!--/small-->
				</xsl:if>
			</td>
			<td>
				<xsl:if test="ram:SpecifiedLineTradeSettlement/ram:SpecifiedTradeAllowanceCharge !=''">
					<xsl:apply-templates select="ram:SpecifiedLineTradeSettlement/ ram:SpecifiedTradeAllowanceCharge" mode="LineLevel-new"/>
				</xsl:if>
			</td>
			<td align="right">
				<xsl:if test="$debug='true'">
					<xsl:text>BT-131@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="fcn:Currency(ram:SpecifiedLineTradeSettlement/ram:SpecifiedTradeSettlementLineMonetarySummation/ram:LineTotalAmount)"/> <xsl:apply-templates select="../ram:ApplicableHeaderTradeSettlement/ram:InvoiceCurrencyCode"/>
			</td>
		</tr>
		<!-- Invoice line/part 3: -->
		<xsl:if test="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeDelivery/ram:ShipToTradeParty !=''">
			<tr>
				<td>
				</td>
				<td>
				</td>
				<td class="UBLName">
					<table border="0" width="90%" cellspacing="0" cellpadding="2">
						<xsl:apply-templates select="rsm:SupplyChainTradeTransaction/ram:ApplicableHeaderTradeDelivery/ram:ShipToTradeParty" mode="line-new"/>
					</table>
				</td>
			</tr>
		</xsl:if>
	</xsl:template>
	<xsl:template match="ram:DesignatedProductClassification">
		<xsl:if test="ram:ClassCode !=''">
			<b>
				<xsl:value-of select="fcn:LabelName('BT-158', 'true')"/>
			</b>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-158@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:ClassCode"/>
			<xsl:choose>
				<xsl:when test="ram:ClassCode/@listID !=''">
					<!--small--> [<xsl:value-of select="fcn:UBLClassificationCode(ram:ClassCode/@listID)"/>
					<xsl:if test="$debug='true'">
						<xsl:text>BT-158-1@ </xsl:text>
					</xsl:if>]<!--/small-->
				</xsl:when>
				<xsl:otherwise>
					<!--small--> [No listID]<!--/small-->
				</xsl:otherwise>
			</xsl:choose>
			<xsl:if test="ram:ClassCode/@listVersionID !=''">
				 [<xsl:apply-templates select="ram:ClassCode/@listVersionID"/>]
			</xsl:if>
			<br/>
		</xsl:if>
		<!--xsl:if test="cbc:ItemClassificationCode !=''">
      <b>
        <xsl:value-of select="fcn:LabelName('BT-158', 'true')"/>
      </b>
      <xsl:apply-templates select="cbc:ItemClassificationCode"/>
      <xsl:choose>
        <xsl:when test="cbc:ItemClassificationCode/@listID !=''"><-small-> [<xsl:value-of select="fcn:UBLClassificationCode(cbc:ItemClassificationCode/@listID)"/>]<-/small->
				</xsl:when>
        <xsl:otherwise><-small-> [No listID]<-/small->
				</xsl:otherwise>
      </xsl:choose>
      <xsl:if test="cbc:ItemClassificationCode/@listVersionID !=''">
				 [<xsl:apply-templates select="cbc:ItemClassificationCode/@listVersionID"/>]
			</xsl:if>
      <br/>
    </xsl:if-->
	</xsl:template>
	<xsl:template match="ram:ApplicableProductCharacteristic">
		<b>
			<xsl:value-of select="fcn:LabelName('BT-160', 'true')"/>
		</b>
		<xsl:apply-templates select="ram:Description"/> = 
		<xsl:apply-templates select="ram:Value"/>
		<xsl:if test="$debug='true'">
			<xsl:text> BT-161@</xsl:text>
		</xsl:if>
		<br/>
	</xsl:template>
	<xsl:template match="ram:SpecifiedTradeProduct">
		<xsl:apply-templates select="ram:SellerAssignedID"/>
	</xsl:template>
	<xsl:template match="ram:SpecifiedLineTradeAgreement">
		<xsl:if test="$debug='true'">
			<xsl:text> BT-146@</xsl:text>
		</xsl:if>
		<xsl:apply-templates select="fcn:Currency(ram:NetPriceProductTradePrice/ram:ChargeAmount)"/>
		<xsl:apply-templates select="../../ram:ApplicableHeaderTradeSettlement/ram:InvoiceCurrencyCode"/>
	</xsl:template>
	<!--Invoiceline end-->
	<!-- Document legal totals from here-->
	<!-- Document legal totals until here-->
	<!--Allowance/Charge from here-->
	<!-- 1) A/C on document level -->
	<xsl:template match="ram:AppliedTradeAllowanceCharge" mode="DocumentLevel-new">
		<tr>
			<td valign="top" colspan="2">
				<xsl:choose>
					<xsl:when test="ram:ChargeIndicator/udt2:Indicator ='true'">
						<xsl:value-of select="fcn:LabelName('BG-21', 'true')"/>
					</xsl:when>
					<xsl:when test="ram:ChargeIndicator/udt2:Indicator ='false'">
						<xsl:value-of select="fcn:LabelName('BG-20', 'true')"/>
					</xsl:when>
					<xsl:otherwise/>
				</xsl:choose>
			</td>
			<td valign="top" colspan="2">
				<xsl:if test="ram:ReasonCode !=''">
					<xsl:apply-templates select="ram:ReasonCode"/>
				</xsl:if>
			</td>
			<td valign="top" colspan="2">
				<xsl:apply-templates select="ram:Reason"/>
			</td>
			<td>
				<xsl:if test="ram:CategoryTradeTax !='' ">
					<xsl:choose>
						<xsl:when test="ram:CategoryTradeTax/ram:RateApplicablePercent !=''">
							<!-- N/A xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/>Auto-complete with default value -->VAT: 

							<xsl:apply-templates select="ram:CategoryTradeTax/ram:TypeCode"/>,
							 <xsl:apply-templates select="fcn:Currency(ram:CategoryTradeTax/ram:RateApplicablePercent)"/>%
						</xsl:when>
						<xsl:otherwise>
							<!-- N/A xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/>Auto-complete with default value -->VAT: 
							<xsl:apply-templates select="ram:CategoryTradeTax/ram:TypeCode"/>
						</xsl:otherwise>
					</xsl:choose>
				</xsl:if>
			</td>
			<td valign="top" align="right">
				<xsl:apply-templates select="fcn:Currency(ram:ActualAmount)"/>
			</td>
		</tr>
	</xsl:template>
	<xsl:template name="AllowanceCrossII">
		<tr>
			<td valign="top" colspan="2">
				<xsl:if test="$debug='true'"><xsl:text> BT-98@ </xsl:text></xsl:if>
				<xsl:apply-templates select="ram:ReasonCode"/>
				<!--xsl:value-of select="fcn:AllowanceReasonCode(cbc:AllowanceChargeReasonCode)"/-->
			</td>
			<td valign="top" colspan="2">
				<xsl:if test="$debug='true'"><xsl:text> BT-97@ </xsl:text></xsl:if>
				<xsl:apply-templates select="ram:Reason"/>
			</td>
			<td>
				<xsl:if test="ram:CategoryTradeTax/ram:CategoryCode !='' ">
					<xsl:choose>
						<xsl:when test="ram:CategoryTradeTax/ram:RateApplicablePercent !=''">
							<!-- xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/> Auto-complete with default value -->VAT: 
							<xsl:if test="$debug='true'"><xsl:text> BT-95@ </xsl:text></xsl:if>
							<xsl:apply-templates select="ram:CategoryTradeTax/ram:CategoryCode"/>,
							<xsl:if test="$debug='true'"><xsl:text> BT-103@ </xsl:text></xsl:if>
							<xsl:apply-templates select="fcn:Currency(ram:CategoryTradeTax/ram:RateApplicablePercent)"/>%

						</xsl:when>
						<xsl:otherwise>
							<!--xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/> Auto-complete with default value -->VAT:
							<xsl:if test="$debug='true'"><xsl:text> BT-95@ </xsl:text></xsl:if>
							<xsl:apply-templates select="ram:CategoryTradeTax/ram:CategoryCode"/>
						</xsl:otherwise>
					</xsl:choose>
				</xsl:if>
			</td>
			<td valign="top" align="right">
				<xsl:if test="ram:CalculationPercent != ''">
					<xsl:if test="$debug='true'"><xsl:text> BT-101@ </xsl:text></xsl:if>
					<xsl:apply-templates select="fcn:Currency(ram:CalculationPercent)"/>%&#160;<xsl:value-of select="fcn:LabelName('UT-4', 'false')"/>&#160;
				</xsl:if>
				<xsl:if test="$debug='true'"><xsl:text> BT-100@ </xsl:text></xsl:if>
				<xsl:apply-templates select="fcn:Currency(ram:BasisAmount)"/>
			</td>
			<td valign="top" align="right">
				<xsl:if test="$debug='true'"><xsl:text> BT-99@ </xsl:text></xsl:if>
				<xsl:apply-templates select="fcn:Currency(ram:ActualAmount)"/>
			</td>
		</tr>
	</xsl:template>
	<xsl:template name="ChargeCrossII">
		<tr>
			<td valign="top" colspan="2">
				<xsl:if test="$debug='true'"><xsl:text>BT-140@ </xsl:text></xsl:if>
				<xsl:apply-templates select="ram:ReasonCode"/>
			</td>
			<td valign="top" colspan="2">
				<xsl:if test="$debug='true'"><xsl:text>BT-139@ </xsl:text></xsl:if>
				<xsl:apply-templates select="ram:Reason"/>
			</td>
			<td>
				<xsl:if test="ram:CategoryTradeTax !='' ">
					<xsl:choose>
						<xsl:when test="ram:CategoryTradeTax/ram:RateApplicablePercent !=''">
							<!--xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/> Auto-complete with default value -->VAT: 
							<xsl:if test="$debug='true'"><xsl:text>BT-118@ </xsl:text></xsl:if>
							<xsl:apply-templates select="ram:CategoryTradeTax/ram:TypeCode"/>,
							<xsl:if test="$debug='true'"><xsl:text>BT-119@ </xsl:text></xsl:if>
							<xsl:apply-templates select="fcn:Currency(ram:CategoryTradeTax/ram:RateApplicablePercent)"/>%
						</xsl:when>
						<xsl:otherwise>
							<!--xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/> Auto-complete with default value -->VAT: 
							<xsl:if test="$debug='true'"><xsl:text>BT-118@ </xsl:text></xsl:if>
							<xsl:apply-templates select="ram:CategoryTradeTax/ram:TypeCode"/>
						</xsl:otherwise>
					</xsl:choose>
				</xsl:if>
			</td>
			<td valign="top" align="right">
				<xsl:if test="ram:CalculationPercent != ''">
					<xsl:if test="$debug='true'"><xsl:text>BT-101@ </xsl:text></xsl:if>
					<xsl:apply-templates select="fcn:Currency(ram:CalculationPercent)"/>%&#160;<xsl:value-of select="fcn:LabelName('UT-4', 'false')"/>&#160;
				</xsl:if>
				<xsl:if test="$debug='true'"><xsl:text>BT-100@ </xsl:text></xsl:if>
				<xsl:apply-templates select="fcn:Currency(ram:BasisAmount)"/>
			</td>
			<td valign="top" align="right">
				<xsl:if test="$debug='true'"><xsl:text>BT-99@ </xsl:text></xsl:if>
				<xsl:apply-templates select="fcn:Currency(ram:ActualAmount)"/>
			</td>
		</tr>
	</xsl:template>
	<!-- 2) A/C on line level -->
	<xsl:template match="ram:SpecifiedTradeAllowanceCharge" mode="LineLevel-new">
		<xsl:choose>
			<xsl:when test="ram:ChargeIndicator ='true'">
				<xsl:value-of select="fcn:LabelName('BG-28', 'true')"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="fcn:LabelName('BG-27', 'true')"/>
			</xsl:otherwise>
		</xsl:choose>
		<xsl:if test="$debug='true'">
			<xsl:text>BT-141@ </xsl:text>
		</xsl:if>
		<xsl:apply-templates select="fcn:Currency(ram:ActualAmount)"/>
		<!--small-->
		<br/>
		<xsl:if test="$debug='true'">
			<xsl:text>BT-144@ </xsl:text>
		</xsl:if>
		<xsl:apply-templates select="ram:Reason"/> (<xsl:if test="$debug='true'">
			<xsl:text>BT-145@ </xsl:text>
		</xsl:if>
		<xsl:apply-templates select="ram:ReasonCode"/>) 
		<xsl:if test="$debug='true'">
			<xsl:text>BT-143@ </xsl:text>
		</xsl:if>
		<xsl:apply-templates select="fcn:Currency(ram:CalculationPercent)"/>%
		<br/>

		<!--/small-->

	</xsl:template>
	<!-- 3) A/C on price unit level (for information only) -->
	<xsl:template match="ram:GrossPriceProductTradePrice" mode="PriceUnit-new">
		<b>
			<xsl:choose>
				<xsl:when test="ram:AppliedTradeAllowanceCharge/ram:ChargeIndicator ='true'">
					<xsl:value-of select="fcn:LabelName('BT-147', 'true')"/>
				</xsl:when>
				<xsl:when test="ram:AppliedTradeAllowanceCharge/ram:ChargeIndicator ='false'">
					<xsl:value-of select="fcn:LabelName('BT-147', 'true')"/>
				</xsl:when>
			</xsl:choose>
		</b>
		<xsl:choose>
			<xsl:when test="ram:AppliedTradeAllowanceCharge/ram:ActualAmount !='' ">
				<xsl:if test="$debug='true'">
					<xsl:text>BT-147@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="fcn:Currency(ram:AppliedTradeAllowanceCharge/ram:ActualAmount)"/>
				<br/>
				<b>
					<xsl:value-of select="fcn:LabelName('BT-148', 'true')"/>
				</b>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-148@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="fcn:Currency(ram:ChargeAmount)"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:if test="$debug='true'">
					<xsl:text>BT-147@ </xsl:text>
				</xsl:if>
				<xsl:apply-templates select="fcn:Currency(ram:AppliedTradeAllowanceCharge/ram:ActualAmount)"/>
			</xsl:otherwise>
		</xsl:choose>
		<br/>
	</xsl:template>
	<!-- AllowanceCharge end -->
	<!-- Tax (VAT) totals from here: -->
	<xsl:template match="ram:ApplicableHeaderTradeSettlement/ram:ApplicableTradeTax">
		<tr class="TAXInformation">
			<td colspan="2">
				<!-- N/A <xsl:apply-templates select="cac:TaxCategory/cac:TaxScheme/cbc:ID"/>
				: -->
				<xsl:if test="$debug='true'"><xsl:text>BT-118@ </xsl:text></xsl:if>
				<xsl:apply-templates select="ram:TypeCode"/> 
				<!--small-->(<xsl:value-of select="fcn:UBLTaxCategoryCode(ram:TypeCode)"/>),<!--/small-->
				<xsl:choose>
					<xsl:when test="ram:RateApplicablePercent !=''">
						 <xsl:if test="$debug='true'">
							<xsl:text> BT-119@ </xsl:text>
						</xsl:if>
						<xsl:apply-templates select="fcn:Currency(ram:RateApplicablePercent)"/>%
					</xsl:when>
					<xsl:otherwise>
						%
					</xsl:otherwise>
				</xsl:choose>
			</td>
			<td colspan="2">
				<xsl:if test="ram:ExemptionReasonCode !=''">
					<xsl:if test="$debug='true'">
						<xsl:text>BT-120@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:ExemptionReason"/>
					<xsl:if test="ram:ExemptionReasonCode !=''">
						<xsl:if test="$debug='true'">
							<xsl:text>BT-121@ </xsl:text>
						</xsl:if> [<xsl:apply-templates select="ram:ExemptionReasonCode"/>] </xsl:if>
				</xsl:if>
			</td>
			<td colspan="2">
				<xsl:if test="$debug='true'"><xsl:text>BT-116@ </xsl:text></xsl:if>
				<xsl:apply-templates select="fcn:Currency(ram:BasisAmount)"/>&#160;<xsl:apply-templates select="../ram:InvoiceCurrencyCode"/>
			</td>
			<td align="right">
				<xsl:if test="$debug='true'"><xsl:text>BT-117@ </xsl:text></xsl:if>
				<xsl:apply-templates select="fcn:Currency(ram:CalculatedAmount)"/>&#160;<xsl:apply-templates select="../ram:InvoiceCurrencyCode"/>
			</td>
		</tr>
	</xsl:template>
	<!--TaxTotal until here-->
	<!--PaymentMeans from here-->
	<xsl:template name="ram:SpecifiedTradeSettlementPaymentMeans">
		<tr>
			<td valign="top">
				<xsl:if test="$debug='true'"><xsl:text> BT-81@</xsl:text></xsl:if>
				<xsl:apply-templates select="ram:TypeCode"/>
				<smaller> (<xsl:choose>
						<xsl:when test="ram:Information != ''">
							<xsl:if test="$debug='true'"><xsl:text> BT-82@</xsl:text></xsl:if>
							<xsl:apply-templates select="ram:Information"/>
						</xsl:when>
						<xsl:otherwise>
							<xsl:if test="$debug='true'"><xsl:text> BT-81@</xsl:text></xsl:if>
							<xsl:value-of select="fcn:PaymentMeansCode(ram:TypeCode)"/>
						</xsl:otherwise>
					</xsl:choose>) 
				</smaller>
			</td>
			<td valign="top" colspan="2">
				<!--xsl:if test="ram:ApplicableTradeSettlementFinancialCard/ram:ID !='' or cac:CardAccount/cbc:NetworkID !=''">
					N/A <xsl:apply-templates select="cac:CardAccount/cbc:NetworkID"/>
				</xsl:if-->
				<!--xsl:if test="cac:PayeeFinancialAccount/cac:FinancialInstitutionBranch/cac:FinancialInstitution/cbc:ID"><xsl:if 				test="ram:ApplicableTradeSettlementFinancialCard/ram:ID !='' or cac:CardAccount/cbc:NetworkID !=''"><br/></xsl:if>
					N/A <xsl:apply-templates select="cac:PayeeFinancialAccount/cac:FinancialInstitutionBranch/cac:FinancialInstitution/cbc:ID"/> 
				</xsl:if-->
				<xsl:if test="ram:PayeeSpecifiedCreditorFinancialInstitution/ram:BICID !='' ">
					<xsl:if test="$debug='true'">
						<xsl:text> BT-86@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PayeeSpecifiedCreditorFinancialInstitution/ram:BICID"/> 
				</xsl:if>
				<xsl:if test="../ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradePaymentTerms/ram:DirectDebitMandateID !='' or ram:PayerPartyDebtorFinancialAccount !=''">
					<xsl:if test="$debug='true'">
						<xsl:text> BT-91@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PayerPartyDebtorFinancialAccount/ram:IBANID"/>
				</xsl:if>
			</td>
			<td valign="top" colspan="2">
				<xsl:if test="ram:ApplicableTradeSettlementFinancialCard/ram:ID !=''">
					***<xsl:apply-templates select="ram:ApplicableTradeSettlementFinancialCard/ram:ID"/> <xsl:if test="$debug='true'">
						<xsl:text> BT-87@ </xsl:text>
					</xsl:if>
				</xsl:if>
				<xsl:if test="ram:PayeePartyCreditorFinancialAccount/ram:IBANID !=''">
					<xsl:if test="ram:ApplicableTradeSettlementFinancialCard/ram:ID !=''">
					</xsl:if>
					<xsl:if test="$debug='true'">
						<xsl:text> BT-84@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PayeePartyCreditorFinancialAccount/ram:IBANID"/> 

				</xsl:if>
				<xsl:if test="../ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradePaymentTerms/ram:DirectDebitMandateID !='' or ram:PayerPartyDebtorFinancialAccount !=''">
					<xsl:if test="$debug='true'">
						<xsl:text> BT-89@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="../ram:ApplicableHeaderTradeSettlement/ram:SpecifiedTradePaymentTerms/ram:DirectDebitMandateID"/>
				</xsl:if>
			</td>
			<xsl:if test="ram:PayerPartyDebtorFinancialAccount != ''">
				<td valign="top" colspan="2">
					<xsl:if test="../../ram:ApplicableHeaderTradeAgreement/ram:SellerTradeParty/ram:GlobalID/@schemeID = 'SEPA'">
					<xsl:if test="$debug='true'"><xsl:text> BT-29@ </xsl:text></xsl:if><xsl:value-of select="../../ram:ApplicableHeaderTradeAgreement/ram:SellerTradeParty/ram:ID"/>
				  </xsl:if>
				  <xsl:if test="../ram:PayeeTradeParty/ram:GlobalID/@schemeID = 'SEPA'">
					<xsl:if test="$debug='true'"><xsl:text> BT-60@ </xsl:text></xsl:if><xsl:value-of select="../ram:PayeeTradeParty/ram:ID"/>
				  </xsl:if>
				</td>
			</xsl:if>
			<xsl:if test="ram:PayeePartyCreditorFinancialAccount !=''">
				<td valign="top" colspan="2">
					<xsl:if test="$debug='true'">
						<xsl:text> BT-85@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:PayeePartyCreditorFinancialAccount/ram:AccountName"/>
				</td>
			</xsl:if>
			<xsl:if test="not(ram:ApplicableTradeSettlementFinancialCard) and not(ram:PayeeSpecifiedCreditorFinancialInstitution)">
				<td valign="top" colspan="2">
				</td>
			</xsl:if>
			<xsl:if test="ram:ApplicableTradeSettlementFinancialCard !=''">
				<td valign="top" colspan="2">
					<xsl:if test="$debug='true'">
						<xsl:text> BT-88@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="ram:ApplicableTradeSettlementFinancialCard/ram:CardholderName"/>
				</td>
			</xsl:if>
			<td valign="top" align="right">
				<xsl:if test="../ram:ApplicableHeaderTradeSettlement/ram:PaymentReference !=''">
					<xsl:if test="$debug='true'">
						<xsl:text> BT-83@ </xsl:text>
					</xsl:if>
					<xsl:apply-templates select="../ram:ApplicableHeaderTradeSettlement/ram:PaymentReference"/>
				</xsl:if>
			</td>
			<!--td valign="top" align="right">
			
			</td-->
		</tr>
	</xsl:template>
	<!--PaymentMeans template until here-->
	<!-- PaymentTerms from here: -->
	<xsl:template match="ram:SpecifiedTradePaymentTerms">
		<xsl:if test="ram:Description !=''">
			<xsl:if test="$debug='true'">
				<xsl:text>BT-20@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:Description"/>
		</xsl:if>
	</xsl:template>
	<!-- Document references from here: -->
	<xsl:template match="ram:AdditionalReferencedDocument" mode="InvoicedObject">
		<xsl:if test="ram:TypeCode='130' and ram:ReferenceTypeCode!=''">
			<br/>
			<b>
				<xsl:value-of select="fcn:LabelName('BT-18', 'true')"/>
			</b>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-18@ </xsl:text>
			</xsl:if>
			<xsl:value-of select="ram:IssuerAssignedID"/>
			<xsl:if test="ram:ReferenceTypeCode != ''">
				<xsl:if test="$debug='true'">
					<xsl:text> BT-18-1@ </xsl:text>
				</xsl:if>
				<xsl:value-of select="fcn:SchemeIdentifierCode(ram:ReferenceTypeCode)"/> [<xsl:value-of select="ram:ReferenceTypeCode"/>]</xsl:if>
		</xsl:if>
		<xsl:if test="ram:TypeCode='50'">
			<br/>
			<b>
				<xsl:value-of select="fcn:LabelName('BT-11', 'true')"/>
			</b>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-17@ </xsl:text>
			</xsl:if>
			<xsl:value-of select="ram:IssuerAssignedID"/>
			<xsl:if test="ram:ReferenceTypeCode != ''">
				<xsl:if test="$debug='true'">
					<xsl:text> BT-17-1@ </xsl:text>
				</xsl:if> [<xsl:value-of select="ram:ReferenceTypeCode"/>]</xsl:if>
		</xsl:if>
	</xsl:template>
	<xsl:template match="ram:AdditionalReferencedDocument" mode="Supporting">
		<xsl:if test="ram:IssuerAssignedID !='' and ram:TypeCode = '916'">
			<xsl:value-of select="fcn:LabelName('BT-122', 'true')"/>
			<xsl:if test="$debug='true'">
				<xsl:text> BT-122@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:IssuerAssignedID"/>&#160;[<xsl:apply-templates select="ram:TypeCode"/>]
		</xsl:if>
		<!--small-->
		<!--xsl:if test="ram:IssuerAssignedID !=''">
			<br/>
			- <xsl:value-of select="fcn:LabelName('BT-123', 'true')"/>
			<xsl:if test="$debug='true'"><xsl:text> BT-122@ </xsl:text></xsl:if>
			<xsl:apply-templates select="ram:IssuerAssignedID"/>
			<xsl:if test="ram:TypeCode !=''"> [<xsl:apply-templates select="ram:TypeCode"/>]</xsl:if>
		</xsl:if-->
		<xsl:if test="ram:Name">	
			- <xsl:if test="$debug='true'"><xsl:text> BT-123@ </xsl:text></xsl:if>
			<xsl:value-of select="fcn:LabelName('BT-123', 'true')"/>
			<xsl:apply-templates select="ram:Name"/>	
		</xsl:if>
		<br/>
		<xsl:apply-templates select="ram:AdditionalReferencedDocument"/>
		<!--/small-->
	</xsl:template>
	<xsl:template match="ram:AdditionalReferencedDocument">
		<!-- No processing of attached document, just info: -->
		<xsl:if test="ram:AttachmentBinaryObject/@mimeCode !=''">
				- <xsl:value-of select="fcn:LabelName('BT-125-1', 'true')"/>
			<xsl:if test="$debug='true'">
				<xsl:text> BT-125-1@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:AttachmentBinaryObject/@mimeCode"/>
			<br/>
		</xsl:if>
		<xsl:if test="ram:AttachmentBinaryObject/@format !=''">
				- <xsl:value-of select="fcn:LabelName('BT-125-1', 'true')"/>
			<xsl:if test="$debug='true'">
				<xsl:text> BT-125-1@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:AttachmentBinaryObject/@format"/>
			<br/>
		</xsl:if>
		<xsl:if test="ram:AttachmentBinaryObject/@filename !=''">
				- <xsl:value-of select="fcn:LabelName('BT-125-2', 'true')"/>
			<xsl:if test="$debug='true'">
				<xsl:text> BT-125-2@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:AttachmentBinaryObject/@filename"/>
			<br/>
		</xsl:if>
		<xsl:if test="ram:AdditionalReferencedDocument !=''">
			- <xsl:apply-templates select="ram:AdditionalReferencedDocument"/>
			<br/>
		</xsl:if>
	</xsl:template>
	<xsl:template match="ram:AdditionalReferencedDocument">
		<xsl:if test="ram:URIID !=''">
			<xsl:value-of select="fcn:LabelName('BT-124', 'true')"/>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-124@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:URIID"/>
		</xsl:if>
	</xsl:template>
	<xsl:template match="ram:ApplicableHeaderTradeSettlement">
		<br/>
		<xsl:if test="ram:CreditNoteReferencedDocument !=''">
			<xsl:apply-templates select="ram:CreditNoteReferencedDocument/ram:IssuerAssignedID"/> 
		</xsl:if>
		<xsl:if test="ram:InvoiceReferencedDocument !=''">
			<xsl:if test="ram:CreditNoteReferencedDocument !=''">
				<br/>
			</xsl:if>
			<xsl:if test="$debug='true'">
				<xsl:text>BT-25@ </xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:InvoiceReferencedDocument/ram:IssuerAssignedID"/> 
		</xsl:if>
	</xsl:template>
	<!-- Document references end -->
	<!--Periods from here-->
	<xsl:template match="ram:BillingSpecifiedPeriod">
		<xsl:if test="ram:StartDateTime/udt2:DateTimeString !=''">
			<xsl:if test="$debug='true'">
				<xsl:text> BT-134@</xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:StartDateTime/udt2:DateTimeString"/> - 
		</xsl:if>
		<xsl:if test="ram:EndDateTime/udt2:DateTimeString !='' ">
			<xsl:if test="$debug='true'">
				<xsl:text> BT-135@</xsl:text>
			</xsl:if>
			<xsl:apply-templates select="ram:EndDateTime/udt2:DateTimeString"/> 
		</xsl:if>
	</xsl:template>
	<xsl:template match="udt2:DateTimeString">
		<!-- Only value "102" format is supported -->
		<xsl:choose>
			<xsl:when test="@format='102' and text()!=''">
			<xsl:variable name="date" select="xs:date(concat(substring(text(),1,4),'-', substring(text(),5,2),'-', substring(text(),7,2)))"/>
				<xsl:value-of  select="format-date($date, '[D01]-[M01]-[Y0001]')"/>
			</xsl:when>
			<xsl:otherwise><xsl:value-of select="."/></xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	<!--Periods end-->
</xsl:stylesheet>
