﻿/*
    This file is part of the FACe (R) project.
    Copyright (c) 2025-2026 Irene Solutions SL
    Authors: Irene Solutions SL.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License version 3
    as published by the Free Software Foundation with the addition of the
    following permission added to Section 15 as permitted in Section 7(a):
    FOR ANY PART OF THE COVERED WORK IN WHICH THE COPYRIGHT IS OWNED BY
    IRENE SOLUTIONS SL. IRENE SOLUTIONS SL DISCLAIMS THE WARRANTY OF NON INFRINGEMENT
    OF THIRD PARTY RIGHTS
    
    This program is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
    or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU Affero General Public License for more details.
    You should have received a copy of the GNU Affero General Public License
    along with this program; if not, see http://www.gnu.org/licenses or write to
    the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
    Boston, MA, 02110-1301 USA, or download the license from the following URL:
        http://www.irenesolutions.com/terms-of-use.pdf
    
    The interactive user interfaces in modified source and object code versions
    of this program must display Appropriate Legal Notices, as required under
    Section 5 of the GNU Affero General Public License.
    
    You can be released from the requirements of the license by purchasing
    a commercial license. Buying such a license is mandatory as soon as you
    develop commercial activities involving the Facturae software without
    disclosing the source code of your own applications.
    These activities include: offering paid services to customers as an ASP,
    serving FACe XML data on the fly in a web application, shipping FACe
    with a closed source product.
    
    For more information, please contact Irene Solutions SL. at this
    address: info@irenesolutions.com
 */

using System.Xml.Serialization;

namespace FACe.Xml.Ubl.Cbc
{

    /// <summary>
    /// Código UBL.
    /// </summary>
    public class Code
    {

        #region Propiedades Públicas

        /// <summary>
        /// Identificador de la lista de códigos.
        /// </summary>
        [XmlAttribute("listID")]
        public string ListID { get; set; }

        /// <summary>
        /// Identificador de la agencia responsable de la lista.
        /// </summary>
        [XmlAttribute("listAgencyID")]
        public string ListAgencyID { get; set; }

        /// <summary>
        /// Nombre de la agencia responsable de la lista.
        /// </summary>
        [XmlAttribute("listAgencyName")]
        public string ListAgencyName { get; set; }

        /// <summary>
        /// Nombre de la lista de códigos.
        /// </summary>
        [XmlAttribute("listName")]
        public string ListName { get; set; }

        /// <summary>
        /// Versión de la lista de códigos.
        /// </summary>
        [XmlAttribute("listVersionID")]
        public string ListVersionID { get; set; }

        /// <summary>
        /// Nombre correspondiente al código.
        /// </summary>
        [XmlAttribute("name")]
        public string Name { get; set; }

        /// <summary>
        /// Identificador del idioma.
        /// </summary>
        [XmlAttribute("languageID")]
        public string LanguageID { get; set; }

        /// <summary>
        /// URI de la lista de códigos.
        /// </summary>
        [XmlAttribute("listURI")]
        public string ListURI { get; set; }

        /// <summary>
        /// URI de la lista de códigos canónica.
        /// </summary>
        [XmlAttribute("listSchemeURI")]
        public string ListSchemeURI { get; set; }

        /// <summary>
        /// Valor del código.
        /// </summary>
        [XmlText]
        public string Value { get; set; }

        #endregion

        #region Constructores

        /// <summary>
        /// Constructor.
        /// </summary>
        public Code()
        {
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="value">Valor del código.</param>
        public Code(string value)
        {
            Value = value;
        }

        #endregion

        #region Operadores Públicos Estáticos

        /// <summary>
        /// Convierte implícitamente una cadena en un código.
        /// </summary>
        /// <param name="value">Valor del código.</param>
        public static implicit operator Code(string value)
        {
            return value == null ? null : new Code(value);
        }

        #endregion

    }

}